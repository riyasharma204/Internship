## Basic structure copied from Material minimal UI and CSS

## Customized by Sunfox Team
- Added axios module for api request (GET, POST), 
    1. Note: use axios insted of fetch.
- 