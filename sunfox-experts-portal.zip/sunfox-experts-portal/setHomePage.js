const fs = require('fs');
const dotenv = require('dotenv');

// Determine the environment (development or production)
const envFilePath = process.env.NODE_ENV ? `.env.${process.env.NODE_ENV}` : '.env.local';
console.log("Environment is: ", process.env.NODE_ENV || 'local');

// Load environment variables from the corresponding file
dotenv.config({ path: envFilePath });

// Get the homepage URL from the environment variable
const homepage = process.env.REACT_APP_HOMEPAGE;

// Modify package.json to set the homepage
const packageJsonPath = './package.json';
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));

packageJson.homepage = homepage;

fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2));

console.log(`Homepage set to: ${homepage}`);
