// ----------------------------------------------------------------------

const accountDummy = {
  displayName: 'Pankaj',
  email: 'support@sunfox.in',
  photoURL: `${process.env.REACT_APP_HOMEPAGE}assets/images/avatars/avatar_default.jpg`,
};

const account = localStorage.getItem("TokenDetails") && JSON.parse(localStorage.getItem("TokenDetails"))?.authorization ? JSON.parse(localStorage.getItem("TokenDetails")) : {}

export default account;
