import { faker } from '@faker-js/faker';
import { sample } from 'lodash';

// ----------------------------------------------------------------------

const users = [...Array(24)].map((_, index) => ({
  id: faker.datatype.uuid(),
  avatarUrl: `${process.env.REACT_APP_HOMEPAGE}assets/images/avatars/avatar_${index + 1}.jpg`,
  name: faker.name.fullName(),
  client: sample([
    'Lal Path Lab',
    'B2C',
  ]),
  isSubscribed: sample([
    'Subscribed',
    'Paid Online',
  ]),
  status: sample([
    'Requested',
    'Completed',
    'In-Progress',
  ]),
  date: sample([
    '10/10/2023',
    '12/10/2023',
  ])
}));

export default users;
