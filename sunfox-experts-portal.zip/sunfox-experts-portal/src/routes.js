import { Navigate, useRoutes } from 'react-router-dom';
// layouts
import DashboardLayout from './layouts/dashboard';
//
import AllReports from './pages/AllReports';
import AllTests from './pages/AllTests';
import LoginPage from './pages/LoginPage';
import Page404 from './pages/Page404';
import DashboardAppPage from './pages/DashboardAppPage';
import DashboardUserPage from './pages/DashboardUserPage';
import DashboardSuperUserPage from './pages/DashboardSuperUserPage';
import InterpretationUtility from './pages/InterpretationUtility';
import Interpretation from './layouts/manual-Interpretation';
import Custominterpretation from './pages/customInterpretation';
import Profile from 'pages/Profile';
import Finance from 'pages/Finance';
import ManageInternalUsers from 'pages/ManageInternalUsers';
import ManageB2BUsers from 'pages/ManageB2BUsers';
import ManageAssociatedUsers from 'pages/ManageAssociatedUsers';
import UserOrder from 'pages/UserOrder';
import DeviceReports from 'pages/DeviceReports';
import InvoiceHistory from 'pages/InvoiceHistory';
import ProcuredDevices from 'pages/ProcuredDevices';
import Managebusinessuser from 'pages/ManageBusinessUsers';
import ViewB2BDashboard from 'pages/ViewB2BDashboard';

import { useAuthDispatch } from 'components/AuthStateProvider';
import DeviceUsage from 'pages/DeviceUsage';

// ----------------------------------------------------------------------
export default function Router({  }) {
  const { account } = useAuthDispatch(); 
  let children = [];
  switch (account?.userType) {
    case 'expert':
      children = [
        { path: 'expertDashboard', element: <DashboardAppPage /> },
        { path: 'allReports', element: <AllReports /> },
        { path: 'interpretationUtility', element: <InterpretationUtility /> },
        { path: 'interpretation', element: <Interpretation /> },
        { path: 'profile', element: <Profile /> },
       
      ];
      break;
    case 'user':
        children = [
          { path: 'userDashboard', element: <DashboardUserPage /> },
          { path: 'allTests', element: <AllTests /> },
          { path: 'userOrder', element: <UserOrder />}
        ];
        break;
    case 'b2b':
      children = [
        { path: 'b2bDashboard', element: <DashboardUserPage /> },
        { path: 'allTests', element: <AllTests /> },
        { path: 'profile', element: <Profile/> },
        { path: 'associated-users', element: <ManageAssociatedUsers/> },
        { path: 'business-users', element:<Managebusinessuser/>},
        { path: 'procured-devices', element: <ProcuredDevices />}, 
        { path: 'deviceusage', element: <DeviceUsage />},
        { path: 'devicereports/:id', element: <DeviceReports />},
      ]
      break;
      case 'b2b-user':
        children = [
          { path: 'b2b-userDashboard', element: <DashboardUserPage /> },
          { path: 'profile', element: <Profile/> }
        ]
        break;
    case 'admin':
      children = [
        { path: 'adminDashboard', element: <DashboardSuperUserPage /> },
        { path: 'allReports', element: <AllReports /> },
        { path: 'profile', element: <Profile/> },
        { path: 'internal-users', element: <ManageInternalUsers/> },
        { path: 'clients', element: <ManageB2BUsers/> },
        { path: 'b2b-dashboard', element: <ViewB2BDashboard/>}
        
      ];
      break;
    
    case 'superuser':
        children = [
          { path: 'adminDashboard', element: <DashboardSuperUserPage /> },
          { path: 'allReports', element: <AllReports /> },
          { path: 'profile', element: <Profile/> },
          { path: 'internal-users', element: <ManageInternalUsers/> },
          { path: 'clients', element: <ManageB2BUsers/> },
          { path: 'finance', element: <Finance/> },
          { path: 'finance/invoiceHistory', element: <InvoiceHistory/> },
          { path: 'b2b-dashboard', element: <ViewB2BDashboard/>},
        ];
        break;
    default:
      break;
  }

  const routes = useRoutes([
    {
      path: `${process.env.REACT_APP_HOMEPAGE}dashboard`,
      element: <DashboardLayout />,
      children: [
        { element: <Navigate to={ `${process.env.REACT_APP_HOMEPAGE}${ account?.authorization ? `dashboard/${account?.userType === 'superuser' ? 'admin' : account?.userType}Dashboard` : 'login' }` } />, index: true },
        ...children,
      ],
    },
    { 
      path: `${process.env.REACT_APP_HOMEPAGE}custominterpretation/:id`, 
      element: <Custominterpretation /> 
    },
    { 
      path: `${process.env.REACT_APP_HOMEPAGE}interpretation`, 
      element: <Interpretation /> 
    },
    {
      path: `${process.env.REACT_APP_HOMEPAGE}login`,
      element: <LoginPage />,
    },
    {
      path: `${process.env.REACT_APP_HOMEPAGE}`,
      element: account?.authorization ? <Navigate to={ `${process.env.REACT_APP_HOMEPAGE}${`dashboard/${account?.userType === 'superuser' ? 'admin' : account?.userType}Dashboard`}` } /> : <LoginPage />,
    },
    { 
      path: `${process.env.REACT_APP_HOMEPAGE}404`, 
      element: <Page404 /> 
    },
    {
      path: '*',
      element: <Navigate to={ account?.authorization ? `${process.env.REACT_APP_HOMEPAGE}404` : `${process.env.REACT_APP_HOMEPAGE}login` } replace />,
    },
  
  ]);
  return routes;
}
