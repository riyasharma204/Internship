import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Container, Stack, Typography, TextField, Button, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import B2BProfile from './B2BProfile';
import UserProfile from './UserProfile';

function Profile() {
  const account =
    localStorage.getItem('TokenDetails') && JSON.parse(localStorage.getItem('TokenDetails'))?.authorization
      ? JSON.parse(localStorage.getItem('TokenDetails'))
      : {};

    return (
      <>
        <Helmet>
          <title> { `${account?.userType === 'b2b' ? 'Business' : 'User'} Profile | ${ process.env.REACT_APP_PORTAL_NAME }` }</title>
        </Helmet>

        <Container>
          <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
              <Typography variant="h4" gutterBottom>
                  Update {account?.userType === 'b2b' ? 'business' : ''} profile
              </Typography>
          </Stack>
          {account?.userType === 'b2b' ? <B2BProfile  data={{ ...account, phone_number: account?.phoneNumber }} /> : <UserProfile data={{ ...account, phone_number: account?.phoneNumber }} /> }
        </Container>
    </>
  )
}

export default Profile