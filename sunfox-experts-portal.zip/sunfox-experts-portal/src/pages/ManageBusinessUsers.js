import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useForm, Controller } from 'react-hook-form'; // Importing useForm hook
import { LoadingButton } from '@mui/lab';
import CircularProgress from '@mui/material/CircularProgress';
import {
    Box,
    Button,
    Card,
    Container,
    Dialog,
    DialogActions,
    DialogTitle,
    Divider,
    InputAdornment,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableFooter,
    TableHead,
    TableRow,
    TextField,
    Tooltip,
    Typography
} from '@mui/material';
import { Add } from '@mui/icons-material';
import { styled } from '@mui/system';

// Additional components
import { useSnackbar } from '../components/snackbar';
import Scrollbar from '../components/scrollbar';
import { useAuthDispatch } from 'components/AuthStateProvider';

// API functions
import { addB2BAdmin, removeB2BAdminUser, getB2Badmindata } from 'api/users';
import { copyToClipboard, downloadFromURI } from 'utils/Utils';
import useResponsive from '../hooks/useResponsive';
import { useTheme } from '@mui/material/styles';

const OverflowTypography = styled(Typography)(() => ({
    maxWidth: 150,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
}));

export default function Managebusinessuser() {
    const theme = useTheme();
    const { enqueueSnackbar } = useSnackbar();
    const isSmall = useResponsive('', 'xs');
    const isLg = useResponsive('between', 'lg', 'xl');
    const { account } = useAuthDispatch();

    const [openAddUser, setOpenAddUser] = useState(false);
    const [deleteData, setDeleteData] = useState(null);

    const [isSubmitting, setIsSubmitting] = useState(false);

    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const defaultValues = {
        phone_number: '',
        name: '',
        email: '',
    };
    const { control, register, handleSubmit, formState: { errors } } = useForm({
        defaultValues,
        mode: "onChange",
    });

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await getB2Badmindata();
            setLoading(false);
            if (response?.success) {
                setData(response?.data || []);
            } else {
                enqueueSnackbar(response.message, { variant: 'error' });
            }
        } catch (e) {
            setLoading(false);
            enqueueSnackbar(e.message, { variant: 'error' });
        }
    };

    const onDeleteDataClick = async () => {
        try {
            if (deleteData) {
                setIsSubmitting(true);
                const response = await removeB2BAdminUser({ phone_numbers: [deleteData?.phone_number] });
                setIsSubmitting(false);
                if (response?.success) {
                    setDeleteData(null);
                    fetchData();
                } else {
                    enqueueSnackbar(response.message, { variant: 'error' });
                }
            } else {
                setIsSubmitting(false);
                enqueueSnackbar("Please select user to delete.", { variant: 'error' });
            }
        } catch (e) {
            setIsSubmitting(false);
            enqueueSnackbar(e.message || "Unable to delete the user.", { variant: 'error' });
            console.log(e);
        }
    };

    const handleAddUser = async (formData) => {
        try {
            setIsSubmitting(true);
            const { name, email, phone_number } = formData;
            const fullPhoneNumber = `+91${phone_number}`;
            const response = await addB2BAdmin({ phone_numbers: [fullPhoneNumber], name, email });
            if (response.success) {
                enqueueSnackbar(response.message || 'Added successfully.', { variant: 'success' });
                fetchData();
                setOpenAddUser(false);
            } else {
                enqueueSnackbar(response.message || 'Unable to add user.', { variant: 'error' });
            }
        } catch (error) {
            enqueueSnackbar('Failed to add user.', { variant: 'error' });
            console.error(error);
        } finally {
            setIsSubmitting(false);
        }
    };
    
    
    

    return (
        <>
            <Helmet>
                <title> Manage Your User | Sunfox Experts</title>
            </Helmet>

            <Container sx={{ marginTop: (isLg ? -2 : 1) }}>
                <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
                    <Typography variant="h4" gutterBottom>
                        Manage business users
                    </Typography>
                    <Stack direction="row" spacing={2}>
                        <Button variant="contained" onClick={() => setOpenAddUser(true)}>
                            <Add sx={{ mr: 1 }} />
                            Add User
                        </Button>
                    </Stack>
                </Stack>
                <Card>
                    <Box>
                        <Box>
                            {loading ? (
                                <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: '30px', alignItems: 'center' }}>
                                    <CircularProgress />
                                </Box>
                            ) : (
                                <Scrollbar>
                                    <Table>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell sx={{ minWidth: 150 }}>Name</TableCell>
                                                <TableCell sx={{ minWidth: 100 }}>Phone No.</TableCell>
                                                <TableCell>Action</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        {data.length ? (
                                            <TableBody>
                                                {data.map((row, index) => (
                                                    <TableRow hover key={index} tabIndex={-1}>
                                                        <TableCell>
                                                            <OverflowTypography maxWidth={150} variant="subtitle2" noWrap>
                                                                {row.name}
                                                            </OverflowTypography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <OverflowTypography maxWidth={150} variant="subtitle2" noWrap>
                                                                {row.phone_number}
                                                            </OverflowTypography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Stack direction="row" spacing={2}>
                                                                <Tooltip title="Edit" arrow>
                                                                    <LoadingButton
                                                                        onClick={() => setDeleteData(row)}
                                                                        loading={false}
                                                                        variant="contained"
                                                                        color='error'
                                                                        disabled={deleteData?.phone_number === row?.phone_number}
                                                                    >
                                                                        Delete
                                                                    </LoadingButton>
                                                                </Tooltip>
                                                            </Stack>
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        ) : (
                                            <TableFooter>
                                                <TableRow>
                                                    <TableCell style={{ width: '100%' }} align="center" colSpan={3}>
                                                        <Typography mt={2}>No user found.</Typography>
                                                    </TableCell>
                                                </TableRow>
                                            </TableFooter>
                                        )}
                                    </Table>
                                </Scrollbar>
                            )}
                        </Box>
                    </Box>
                </Card>
            </Container>
            <Dialog
                fullWidth
                maxWidth="xs"
                scroll='body'
                disableBackdropClick={true}
                open={openAddUser}
                onClose={() => setOpenAddUser(false)}
            >
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="h6">Add B2B Admin</Typography>
                    <Button onClick={() => setOpenAddUser(false)}>Close</Button>
                </DialogTitle>
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '20px' }}>
                    <Box sx={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
                        <Controller
                            name="phone_number"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    sx={{ maxWidth: 200 }}
                                    label="Phone number"
                                    fullWidth
                                    margin="normal"
                                    error={!!errors.phone_number}
                                    helperText={errors.phone_number?.message}
                                    InputProps={{
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                +91
                                            </InputAdornment>
                                        ),
                                    }}
                                    {...register('phone_number', {
                                        required: "Please enter the phone number.",
                                        pattern: {
                                            value: /^[0-9]{10}$/i,
                                            message: 'Invalid phone number'
                                        }
                                    })}
                                />
                            )}
                        />
                        <Controller
                            name="name"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    sx={{ maxWidth: 200 }}
                                    label="Name"
                                    fullWidth
                                    margin="normal"
                                    error={!!errors.name}
                                    helperText={errors.name?.message}
                                    {...register('name', {
                                        required: "Please enter the name."
                                    })}
                                />
                            )}
                        />
                    </Box>
                    <Controller
                        name="email"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                sx={{ minWidth: 300 }}
                                label="Email"
                                fullWidth
                                margin="normal"
                                error={!!errors.email}
                                helperText={errors.email?.message}
                                {...register('email', {
                                    pattern: {
                                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                        message: 'Invalid email address'
                                    }
                                })}
                            />
                        )}
                    />
                    <LoadingButton
                        disabled={isSubmitting}
                        onClick={handleSubmit(handleAddUser)}
                        loading={isSubmitting}
                        sx={{
                            alignSelf: 'flex-end',
                            color: '#ffffff',
                            bgcolor: '#1976d2',
                            '&:hover': {
                                bgcolor: '#1565c0',
                            },
                            mt: 2
                        }}
                        variant='primary'
                    >
                        Add User
                    </LoadingButton>
                </Box>
            </Dialog>
            {deleteData && <Dialog
                fullWidth
                maxWidth="xs"
                scroll='body'
                disableEscapeKeyDown={() => setDeleteData(null)}
                open={deleteData ? true : false}
                onClose={() => setDeleteData(null)}
                transitionDuration={{
                    enter: theme.transitions.duration.shortest,
                    exit: theme.transitions.duration.shortest - 80,
                }}
            >
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    Confirmation
                </DialogTitle>
                <Box sx={{ px: 3, pb: 4 }}>Do you want to delete user <b>{deleteData?.name}</b>?</Box>
                <Divider />
                <DialogActions>
                    <Stack direction='row' spacing={4} sx={{ px: 2, py: 1 }}>
                        <Button variant="outlined" color="error" onClick={() => setDeleteData(null)}>
                            Cancel
                        </Button>
                        <LoadingButton
                            type="submit"
                            variant="contained"
                            loading={isSubmitting}
                            onClick={onDeleteDataClick}
                        >
                            Confirm
                        </LoadingButton>
                    </Stack>
                </DialogActions>
            </Dialog>}
        </>
    );
}
