import { Helmet } from 'react-helmet-async';
import { useMemo } from 'react';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import { useEffect, useState } from 'react';
import Label from 'components/label/Label';
import dayjs from 'dayjs';
import { LoadingButton } from '@mui/lab';
import CircularProgress from '@mui/material/CircularProgress';
import { getAllReports, updateReportStatus } from 'api/reports';
import * as React from 'react';
import CloseIcon from '@mui/icons-material/Close'
import { getEcgData } from 'api/reports';
import { copyToClipboard, downloadFromURI } from 'utils/Utils';
// @mui
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Card,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  Box,
  Alert,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
  TableFooter,
  Tooltip,
} from '@mui/material';
import useResponsive from '../hooks/useResponsive';

import { Download, Share, ContentCopy } from '@mui/icons-material';
// components
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
// mock
import USERLIST from '../_mock/user';

import { refreshSocket } from '../utils/socket'

import { styled } from '@mui/system';
import { useSnackbar } from '../components/snackbar'
import { useAuthDispatch } from 'components/AuthStateProvider';
//-----------------------------------------------------------------------
const OverflowTypography = styled(Typography)(() => ({
  maxWidth: 150, // percentage also works
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis"
}));


function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(array, (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}

export default function AllTests() {
  const { enqueueSnackbar } = useSnackbar();
  const isSmall = useResponsive('', 'xs');
  const isLg = useResponsive('between', 'lg', 'xl');
  const { account } = useAuthDispatch();
  // const account =
  //   localStorage.getItem('TokenDetails') && JSON.parse(localStorage.getItem('TokenDetails'))?.authorization
  //     ? JSON.parse(localStorage.getItem('TokenDetails'))
  //     : {};

  const [open, setOpen] = useState(null);

  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [selected, setSelected] = useState([]);

  const [completeSelected, setCompleteSelected] = useState([]);

  const [orderBy, setOrderBy] = useState('name');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(10);

  const [data, setData] = useState([]);

  const [status, setstatus] = useState('');

  const [loading, setLoading] = useState(true);

  const [InitialDate, setInitialDate] = useState(null);

  const [startDate, setStartDate] = useState(dayjs());

  const [ButtonLoadingStatus, setButtonLoadingStatus] = useState(false);
  const [downloadButtonLoadingStatus, setDownloadButtonLoadingStatus] = useState(false);

  const [pdf, setPdf] = useState(null);

  const [allFilesUrl, setAllFilesUrl] = useState([]);

  const [allFilesData, setAllFilesData] = useState([]);

  const [rowLoading, setRowLoading] = useState([]);
  const [rowDownloadLoading, setRowDownloadLoading] = useState([]);

  const [openPaymentAlert, setOpenPaymentAlert] = useState(false);

  const [paymentPayload, setPaymentPayload] = useState({});

  const [interpretationStatusFilter, setInterpretationStatusFilter] = useState('all');


  // ----------------------------------------------------------------------
  const TABLE_HEAD = [
    { id: 'name', label: 'Name', alignRight: false, minWidth: '150px' },
    { id: 'report_type', label: 'Report Type', alignRight: false, minWidth: '120px' },
    { id: 'Created_Time', label: 'Taken At', alignRight: false, minWidth: '150px' },
    { id: 'Requested_At', label: `${(status === 'completed' ? 'Completed' : 'Requested')} At`, alignRight: false, minWidth: '160px' },
    ...(status === 'completed' || !status ? [{ id: 'Report_Status', label: 'Findings', alignRight: false }] : []),
    { id: 'Status', label: 'Status', alignRight: false },
    { id: ' ', label: ' ', alignRight: false, minWidth: '100px' },
  ];

  const [socket, setSocket] = useState();

  async function getSocketDetails() {
    setSocket(await refreshSocket());
  }

  const handleStartDateChange = (date) => {
    setStartDate(date);
    setLoading(true);
  };

  const formatDate = (date) => {
    return date ? dayjs(date).format('DD MMM, YYYY') : null;
  };

  const handleCloseMenu = () => {
    setOpen(null);
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };
  const handleSelectAllClick = (event) => {
    if (!(selected?.length || completeSelected?.length)) {
      const newSelectedIds = data
        .filter((row) => !row?.interpretation_request_status)
        .map((row) => row.id);
      const completedIds = data
        .filter((row) => row?.interpretation_request_status === 'completed')
        .map((row) => row.id);
      setSelected(newSelectedIds);
      setCompleteSelected(completedIds);
    } else {
      setSelected([]);
      setCompleteSelected([]);
    }
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handlePaymentPopupClose = (event) => {
    setOpenPaymentAlert(false);
    setRowLoading([]);
  };

  const handlePaymentPopup = (event) => {
    setOpenPaymentAlert(false);
    const options = {
      prefill: {
        contact: paymentPayload.notes?.phoneNumber
      },
      modal: {
        ondismiss: () => {
          document.body.style = '';
        },
      },
      handler: function (res) {
        if (res.razorpay_payment_id && res.razorpay_order_id && res.razorpay_signature) {
          const updatedData = data.map(item => {
            if (paymentPayload?.ids?.includes(item.id)) {
              return { ...item, interpretation_request_status: "requested" };
            }
            return item;
          });

          setData(updatedData);
          enqueueSnackbar('Payment successful', { variant: 'success' });
          setButtonLoadingStatus(false);
        }

      },
      key: paymentPayload.razorpay_public_key,
      order_id: paymentPayload.id,
    }
    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
    paymentObject.on('payment.failed', function (response) {
      enqueueSnackbar(response.error.description || 'Payment failed', { variant: 'error' });
      setButtonLoadingStatus(false);
    });
    setSelected([]);
    setRowLoading([]);
    setLoading(false);
  };

  const handleChangeRowsPerPage = (event) => {
    setPage(0);
    setRowsPerPage(parseInt(event.target.value, 10));
  };

  const handleFilterByName = (event) => {
    setPage(0);
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - USERLIST.length) : 0;

  const changeFilter = (changeFilter,) => {
    setInterpretationStatusFilter(selectedValue);
  }

  const filteredUsers = useMemo(() => {
    if (status === 'completed') {
      return applySortFilter(
        data.filter(row => {
          if (interpretationStatusFilter === 'all') {
            return true;
          } else {
            return row?.interpretation_report_status === interpretationStatusFilter;
          }
        }),
        getComparator(order, orderBy),
        filterName
      );
    } else {
      return applySortFilter(data, getComparator(order, orderBy), filterName);
    }
  }, [data]);


  const isNotFound = !filteredUsers.length && !!filterName;

  useEffect(() => {
    if (!socket) {
      getSocketDetails();
    }

  }, [socket])


  useEffect(() => {
    fetchData();

  }, [status, startDate]);
  const fetchData = async () => {
    const response = await getAllReports({
      id: account?.phoneNumber,
      startDate: formatDate(startDate),
      endDate: formatDate(startDate),
      status: status,
    });
    setLoading(false);
    if (response?.success) {
      const filteredData = response?.data?.filter(
        (row) =>
          !row.interpretation_request_status ||
          row.interpretation_request_status === 'requested' ||
          row.interpretation_request_status === 'in progress' ||
          row.interpretation_request_status === 'completed'
      );
      setData(filteredData || []);
    } else {
      enqueueSnackbar(response.message, { variant: 'error' })
    }
  };

  const handleRowButtonClick = async (event, reportIds, row, rowInter) => {
    try {
      // socket.emit("requestedReport", reportIds, account?.authorization)
      setButtonLoadingStatus(true);

      setRowLoading(reportIds);
      const response = await updateReportStatus({
        ids: reportIds,
      });
      if (response) {
        console.log("Res", response)
        if (response?.data?.id && response?.data?.amount_due && response?.data?.razorpay_public_key) {
          setOpenPaymentAlert(true);
          setPaymentPayload(response?.data);
        }
        else {
          setSelected([]);
          setRowLoading([]);
          setLoading(false)
          fetchData();
          enqueueSnackbar(response.message, { variant: 'success' })
        }

      } else {
        enqueueSnackbar(response.message, { variant: 'error' })
        setRowLoading([]);
      }
    } catch (error) {
      console.error("Error occurred:", error);
      // Handle any potential errors
    }
  };

  const downloadPDF = async (event, ids) => {
    try {
      setDownloadButtonLoadingStatus(true);
      setRowDownloadLoading(ids);
      for (const id of ids) {
        const reportResponse = await getEcgData({ id });
        if (reportResponse?.success) {
          const reportdata = reportResponse?.data;
          const fileName = `${reportdata?.user_data?.first_name}-${reportdata?.user_data?.last_name}-${dayjs(reportdata?.report_timestamp).format('DD-MM-YYYY-HH-mm')}${reportdata?.interpretation_data?.report_status ? `-${reportdata?.interpretation_data?.report_status}` : ''}`;
          downloadFromURI(`data:application/pdf;base64,${reportdata?.ReportPdf}`, fileName)
          // setSnackAlert({ snackOpen: true, snackMsg: `Report PDF ${(ids?.length > 1 ? `${(ids.indexOf(id) + 1)}/${ids.length}` : '')} downloaded suceessfully.`, severity: 'success' });
          enqueueSnackbar(`Report PDF ${(ids?.length > 1 ? `${(ids.indexOf(id) + 1)}/${ids.length}` : '')} downloaded suceessfully.`, { variant: 'success' })

        }
      }
      setRowDownloadLoading([]);
      setDownloadButtonLoadingStatus(false);
      setCompleteSelected([])
    } catch (error) {
      setRowDownloadLoading([]);
      setDownloadButtonLoadingStatus(false);
      setCompleteSelected([]);
      enqueueSnackbar(error, { variant: 'error' })

    }
  };
  const cancelAllSelected = async () => {
    setSelected([]);
    setCompleteSelected([]);
  };

  const handleClick = (checked, row) => {
    if (checked) {
      if (row?.interpretation_request_status === "completed") setCompleteSelected((prevIds) => [...prevIds, row?.id])
      else if (!row?.interpretation_request_status) setSelected((prevIds) => [...prevIds, row?.id])
    } else {
      if (row?.interpretation_request_status === "completed") setCompleteSelected((prevIds) => prevIds.filter((existingId) => existingId !== row?.id))
      else if (!row?.interpretation_request_status) setSelected((prevIds) => prevIds.filter((existingId) => existingId !== row?.id));
    }
  };

  const handleDatastatus = (newStatus, loading) => {
    setstatus(newStatus);
    setLoading(loading);
  };

  const onCopyClick = (text) => (e) => {
    copyToClipboard(text);
    enqueueSnackbar('Copied to clipboard.', { variant: 'success' })
  };


  return (
    <>
      <Helmet>
        <title> User | Sunfox Experts</title>
      </Helmet>

      <Container sx={{ marginTop: (isLg ? -2 : 1) }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
          <Typography variant="h4" gutterBottom>
            ECG tests
          </Typography>
        </Stack>
        <Dialog
          open={openPaymentAlert}
          onClose={handlePaymentPopupClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            Payment for interpretation
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              <Typography color={'black'} gutterBottom>Pay <b>{paymentPayload?.currency} {paymentPayload?.amount / 100}</b> to request ECG report for interpretation.</Typography>
              <Typography variant="body2">You have exceeded your <b>free</b> ECG report interpretation quota for today.</Typography>
            </DialogContentText>
          </DialogContent>
          <DialogActions sx={{ paddingRight: 2, paddingBottom: 2 }}>
            <Button sx={{ marginRight: 2 }} variant='outlined' color="error" onClick={handlePaymentPopupClose}>
              Cancel
            </Button>
            <Button variant='contained' color='primary' onClick={handlePaymentPopup} payload={paymentPayload} autoFocus>
              Proceed
            </Button>
          </DialogActions>
        </Dialog>
        <Card>
          <Box>
            <UserListToolbar
              filterName={filterName}
              onFilterName={handleFilterByName}
              newStatus={handleDatastatus}
              startDate={startDate}
              handleStartDateChange={handleStartDateChange}
              selectedIds={selected}
              completeSelectedIds={completeSelected}
              requestedSelectedReportClick={handleRowButtonClick}
              downloadSelectedReportClick={downloadPDF}
              unselecteReports={cancelAllSelected}
              filterReportTypeData={changeFilter}
              ButtonLoading={ButtonLoadingStatus}
              DownloadButtonLoading={downloadButtonLoadingStatus}
              isSmall={isSmall}
            />
            <Box>
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: '30px', alignItems: 'center' }}>
                  <CircularProgress />
                </Box>
              ) : (
                <Scrollbar>
                  {/* <TableContainer sx={{ minWidth: 800 }}> */}
                  <Table>
                    <UserListHead
                      order={order}
                      orderBy={orderBy}
                      headLabel={TABLE_HEAD}
                      rowCount={data.length}
                      numSelected={selected?.length + completeSelected?.length}
                      onRequestSort={handleRequestSort}
                      onSelectAllClick={handleSelectAllClick}
                      hideCheckbox={!account?.business_id}
                    />
                    {data.length ? (
                      <TableBody>
                        {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                          const { id, user_Data, report_Timestamp, interpretation_request_status } = row;
                          const selectedUser = selected.indexOf(name) !== -1;
                          return (
                            <TableRow hover key={id} tabIndex={-1} role="checkbox" selected={selectedUser}>
                              <TableCell padding="checkbox">
                                {account?.business_id && <Checkbox
                                  disabled={!(!row.interpretation_request_status || (row.interpretation_request_status === "completed"))}
                                  checked={selected.includes(row?.id) || completeSelected.includes(row?.id)}
                                  onChange={(event) => handleClick(event.target.checked, row)}
                                />}
                              </TableCell>
                              <TableCell component="th" scope="row" padding="none">
                                <Stack direction="row" alignItems="center" spacing={2}>
                                  <Tooltip title={row?.user_data?.phone_number}>
                                    {/* <Avatar alt={row?.user_Data?.first_name} {...row?.user_data?.last_name} /> */}
                                    <OverflowTypography variant="subtitle2" noWrap>
                                      {row?.user_data?.first_name} {row?.user_data?.last_name}
                                    </OverflowTypography>
                                  </Tooltip>
                                  <ContentCopy fontSize='small' sx={{ cursor: "pointer" }} onClick={onCopyClick(row?.user_data?.phone_number)} />
                                </Stack>
                              </TableCell>
                              <TableCell>
                                <OverflowTypography maxWidth={150} variant="subtitle2" noWrap>
                                  {row?.report_type?.replace(/REPORT|_/g, ' ')}
                                </OverflowTypography>
                              </TableCell>
                              <TableCell>
                                <Tooltip title={row?.report_timestamp ? dayjs(parseInt(row?.report_timestamp)).format('DD MMM, YYYY hh:mm A') : '--'}>
                                  <span>{row?.report_timestamp ? dayjs(parseInt(row?.report_timestamp)).format('DD MMM hh:mm A') : '--'}</span>
                                </Tooltip>
                              </TableCell>
                              <TableCell>
                                <Tooltip title={(row?.interpretation_completed_at ? dayjs(parseInt(row?.interpretation_completed_at)).format('DD MMM, YYYY hh:mm A') : (row?.interpretation_requested_at ? dayjs(parseInt(row?.interpretation_requested_at)).format('DD MMM, YYYY hh:mm A') : '--'))}>
                                  <span>{(row?.interpretation_completed_at ? dayjs(parseInt(row?.interpretation_completed_at)).format('DD MMM hh:mm A') : (row?.interpretation_requested_at ? dayjs(parseInt(row?.interpretation_requested_at)).format('DD MMM hh:mm A') : '--'))}</span>
                                </Tooltip>
                              </TableCell>
                              {status === "completed" || !status ? (
                                <TableCell>
                                  {row?.interpretation_report_status ? <Typography
                                    color={
                                      row?.interpretation_report_status === 'abnormal'
                                        ? 'error.main'
                                        : row?.interpretation_report_status === 'retake'
                                          ? 'warning.main'
                                          : 'success.main'
                                    }
                                    sx={{ textTransform: 'capitalize' }}
                                  >
                                    {row?.interpretation_report_status || 'normal'}
                                  </Typography> : '--'}
                                </TableCell>
                              ) : null}
                              <TableCell>
                                {row?.interpretation_request_status ?
                                  <Label
                                    color={
                                      row.interpretation_request_status === 'requested'
                                        ? 'primary'
                                        : row.interpretation_request_status === 'completed'
                                          ? 'success'
                                          : row.interpretation_request_status === 'in progress'
                                            ? 'warning'
                                            : 'default'
                                    }
                                  >
                                    {row?.interpretation_request_status}
                                  </Label> : '--'}
                              </TableCell>
                              <TableCell align="center">
                                {row?.interpretation_request_status === 'completed' && dayjs(row?.interpretation_completed_at).isBefore(dayjs().subtract(1, 'minute')) ? (
                                  <>
                                    <Tooltip title="Download" arrow>
                                      <LoadingButton
                                        loading={downloadButtonLoadingStatus}
                                        variant="contained"
                                        disabled={completeSelected.includes(row?.id)}
                                        onClick={(event) => downloadPDF(event, [row?.id])}
                                      >
                                        <Download />
                                      </LoadingButton>
                                    </Tooltip>
                              
                                {/* &nbsp;&nbsp;
                                      <Button aria-describedby="adadsa" variant="contained">
                                        <Share />
                                      </Button> */}
                              </>
                              ) : (
                              <>
                                {!row?.interpretation_request_status ? (
                                  <LoadingButton
                                    loading={ButtonLoadingStatus}
                                    variant="contained"
                                    disabled={selected.includes(row?.id)}
                                    onClick={(event) => handleRowButtonClick(event, [row.id], row, row?.interpretation_request_status)}
                                  >
                                    Request
                                  </LoadingButton>
                                ) : null}
                              </>

                                )}
                            </TableCell>
                            </TableRow>
                    );
                        })}
                    {emptyRows > 0 && (
                      <TableRow style={{ height: 53 * emptyRows }}>
                        <TableCell colSpan={6} />
                      </TableRow>
                    )}
                    {isNotFound && (
                      <TableRow>
                        <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                          <Paper
                            sx={{
                              textAlign: 'center',
                            }}
                          >
                            <Typography variant="h6" paragraph>
                              Not found
                            </Typography>
                            <Typography variant="body2">
                              No results found for &nbsp;
                              <strong>&quot;{filterName}&quot;</strong>.
                              <br /> Try checking for typos or using complete words.
                            </Typography>
                          </Paper>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                  ) : (
                  <TableFooter>
                    <TableRow>
                      <TableCell style={{ width: '100%' }} align="center" colSpan={6} v>
                        <Typography mt={2}>No interpretation request found.</Typography>
                      </TableCell>
                    </TableRow>
                  </TableFooter>
                    )}
                </Table>
                  {/* </TableContainer> */}
            </Scrollbar>
              )}
          </Box>
        </Box>
        {data.length ? (
          <TablePagination
            rowsPerPageOptions={[10, 20, 25]}
            component="div"
            count={USERLIST.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        ) : null}
      </Card>
    </Container >
      <Popover
        open={Boolean(open)}
        anchorEl={open}
        onClose={handleCloseMenu}
        anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        PaperProps={{
          sx: {
            p: 1,
            width: 140,
            '& .MuiMenuItem-root': {
              px: 1,
              typography: 'body2',
              borderRadius: 0.75,
            },
          },
        }}
      >
        <MenuItem>
          <Iconify icon={'eva:edit-fill'} sx={{ mr: 2 }} />
          Edit
        </MenuItem>

        <MenuItem sx={{ color: 'error.main' }}>
          <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
          Delete
        </MenuItem>
      </Popover>
    </>
  );
}
