function PDFExtractor(pdfjs, pdfPath, pageNumber) {
    const extractTextFromCoords = (page) => {
        return page.getTextContent().then((textContent) => {
            const reportType = textContent.items.find(item => item.str && item.str.match(new RegExp('^first name', 'ig')))
            if (reportType) return oldReportDataExtraction(textContent);
            return newReportDataExtraction(textContent);
        });
    };

    // const pdfPath = 'Ashok_Kumar_Jain_1694434125632_twelve_lead_1.pdf'; // Replace with the path to your PDF file
    return pdfjs.getDocument(pdfPath).promise.then((pdf) => {
        const promise = pdf.getPage(pageNumber).then((page) => {
            return extractTextFromCoords(page); // Replace with your desired coordinates
        })

        return Promise.resolve(promise).then((extractedTextArray) => {
            return extractedTextArray;
        });
    });
};

function oldReportDataExtraction(textContent) {
    const textFragments = {};
    let keysToExtract = ['date', 'report id', 'patient id', 'mobile', 'first name', 'last name', 'gender', 'age', 'height', 'weight'];
    let hWidht = 150, vWidth = 8;
    for (const key of keysToExtract) {
        const keyData = textContent.items.find(item => item.str && item.str.match(new RegExp('^' + key, 'ig')))
        if (keyData && keyData.width && (keyData.transform || []).length === 6) {
            const itemX = keyData.transform[4];
            const itemY = keyData.transform[5];

            const keyValues = textContent.items.filter(item => {
                return item.str.trim() && ((item.transform[4] >= (itemX + keyData.width)) && (item.transform[4] <= (itemX + keyData.width + hWidht))) && ((item.transform[5] >= (itemY - vWidth)) && (item.transform[5] <= (itemY + vWidth)));
            });

            const sortedKeyValues = keyValues.sort((a, b) => a.transform[4] - b.transform[4]).map(item => item.str);
            textFragments[keyData.str.replace(/\s|[:]/g, '')] = sortedKeyValues.join(' ');
        }
    }
    return textFragments;
};

function newReportDataExtraction(textContent) {
    const textFragments = { ReportType: "neo" };
    let keysToExtract = ['date', 'id', 'patient id', 'mobile', 'full name', 'name', 'age/gender', 'height/weight'];
    let hWidht = 120, vWidth = 0;
    for (const key of keysToExtract) {
        const keyData = textContent.items.find(item => item.str && item.str.match(new RegExp('^' + key, 'ig')))
        if (keyData && keyData.width && (keyData.transform || []).length === 6) {
            const itemX = keyData.transform[4];
            const itemY = keyData.transform[5];

            const keyValues = textContent.items.filter(item => {
                return item.str.trim() && ((item.transform[4] >= (itemX + keyData.width)) && (item.transform[4] <= (itemX + keyData.width + hWidht))) && ((item.transform[5] >= (itemY - vWidth)) && (item.transform[5] <= (itemY + vWidth)));
            });
            const sortedKeyValues = keyValues.sort((a, b) => a.transform[4] - b.transform[4]).map(item => item);

            let uniqueValues = [];
            for(const n of sortedKeyValues){
                if(uniqueValues.indexOf(n.str) === -1){
                    uniqueValues.push(n.str);
                }
            }
            const dataKey = keyData.str.replace(/\s|[:]/g, '');
            let dataValue = uniqueValues.join(' ');
            if (dataKey === "Id" || dataKey === "ID") textFragments["ReportId"] = dataValue;
            if (dataKey === "Fullname" || dataKey === "name") {
                const splittedData = dataValue.split(' ');
                textFragments["FirstName"] = "";
                textFragments["LastName"] = "";
                if (splittedData.length) {
                    if (splittedData.length >= 2) {
                        textFragments["LastName"] = splittedData[splittedData.length - 1];
                        splittedData.pop();
                        textFragments["FirstName"] = splittedData.join(" ");
                    } else {
                        textFragments["FirstName"] = splittedData.join(" ");
                        textFragments["LastName"] = "";
                    }
                }
            } else if (dataKey === 'Height/Weight') {
                const splittedData = dataValue.split("/");
                textFragments["Height"] = "";
                textFragments["Weight"] = "";
                if (splittedData.length) {
                    if (splittedData.length === 1) textFragments["Height"] = splittedData[0];
                    if (splittedData.length === 2) {
                        textFragments["Height"] = splittedData[0];
                        textFragments["Weight"] = splittedData[1];
                    }
                }
            } else if (dataKey === 'Age/Gender') {
                const splittedData = dataValue.split("/");
                textFragments["Age"] = "";
                textFragments["Gender"] = "";
                if (splittedData.length) {
                    if (splittedData.length === 1) textFragments["Age"] = splittedData[0];
                    if (splittedData.length === 2) {
                        textFragments["Age"] = splittedData[0];
                        textFragments["Gender"] = splittedData[1];
                    }
                }
            } else {
                textFragments[dataKey] = dataValue;
            }
        }
    }
    return textFragments;

};

export default PDFExtractor;

//*******************************************************//
//                                                       //
//              Backup Old Report Extraction             //
//                                                       //
//*******************************************************//

// function PDFExtractor(pdfjs, pdfPath, pageNumber) {
//     const keysToExtract = ['date', 'report id', 'patient id', 'mobile', 'first name', 'last name', 'gender', 'age', 'height', 'weight']
//     const extractTextFromCoords = (page) => {
//         return page.getTextContent().then((textContent) => {
//             const textFragments = {};
//             for (const key of keysToExtract) {
//                 const keyData = textContent.items.find(item => item.str && item.str.match(new RegExp('^' + key, 'ig')))
//                 if (keyData && keyData.str && keyData.width && (keyData.transform || []).length === 6) {
//                     const itemX = keyData.transform[4];
//                     const itemY = keyData.transform[5];

//                     const keyValues = textContent.items.filter(item => {
//                         return item.str.trim() && ((item.transform[4] >= (itemX + keyData.width)) && (item.transform[4] <= (itemX + keyData.width + 150))) && ((item.transform[5] >= (itemY - 8)) && (item.transform[5] <= (itemY + 8)));
//                     })

//                     const sortedKeyValues = keyValues.sort((a, b) => a.transform[4] - b.transform[4]).map(item => item.str);
//                     textFragments[keyData.str.replace(/\s|[:]/g, '')] = sortedKeyValues.join(' ');
//                 }
//             }

//             return Object.keys(textFragments).length ? textFragments : null;
//         });
//     };

//     // const pdfPath = 'Ashok_Kumar_Jain_1694434125632_twelve_lead_1.pdf'; // Replace with the path to your PDF file
//     return pdfjs.getDocument(pdfPath).promise.then((pdf) => {
//         const promise = pdf.getPage(pageNumber).then((page) => {
//             return extractTextFromCoords(page); // Replace with your desired coordinates
//         })

//         return Promise.resolve(promise).then((extractedTextArray) => {
//             return extractedTextArray;
//         });
//     });
// }

// export default PDFExtractor;