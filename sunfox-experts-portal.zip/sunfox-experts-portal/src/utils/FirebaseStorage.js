import firebase, { storage } from '../firebase';

export const uploadFileAsync = (file, callBack) => {
  if (file) {
    const storageRef = storage.ref(`interpretations/${file.name}`);
    try {
      const uploadTask = storageRef.put(file);

      uploadTask.on("state_changed", async (snapshot) => {
        // Track upload progress
        const progress = Math.round(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        if (progress === 100) {
            const url = await storageRef.getDownloadURL();
            return callBack(null, url, progress);
        } else {
            callBack(null, null, progress);
        }
      });
    } catch (error) {
        return callBack(error);
    }
  } else {
    return callBack({ message: "Invalid file." });
  }
};

export const uploadFile = async (blob, fileName) => {
  if (blob) {
    const file = new File([blob], fileName);
    const storageRef = storage.ref(`interpretations/${file.name}`);
    try {
      const uploadTask = storageRef.put(file);

      await uploadTask;

      // Get the download URL after successful upload
      const url = await storageRef.getDownloadURL();
      return { url };
    } catch (error) {
        return { error };
    }
  } else {
    return { error: { msg: "Invalid file." } };
  }
};
