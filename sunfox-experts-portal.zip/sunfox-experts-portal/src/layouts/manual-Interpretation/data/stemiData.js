const stemiData = [
    { title: "wideQRS" },
    { title: "dominantSV1" },
    { title: "notchedMShapeRWaveV5V6" },
    { title: "rBySRatioGreaterThan1InV1" },
    { title: "stElevationOrDepressionInV1" },
    { title: "stElevationOrDepressionInV2" },
    { title: "stElevationOrDepressionInV3" },
    { title: "stElevationOrDepressionInV4" },
    { title: "stElevationOrDepressionInV5" },
    { title: "stElevationOrDepressionInLeadI" },
    { title: "stElevationOrDepressionInLeadAVL" },
    { title: "stElevationOrDepressionInLeadII" },
    { title: "stElevationOrDepressionInLeadIII" },
    { title: "stElevationOrDepressionInLeadAVF" },
    { title: "stElevationOrDepressionInV6" },
    { title: "stSegmentDepression" },
    { title: "tWaveInversion" },
    { title: "totalScore" },
    { title: "stSegmentElevation" }
  ]
  export default stemiData;