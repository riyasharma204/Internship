const arrhythmiaTextData = [
    "Atrial Fibrillation",
    "Atrial Flutter",
    "Atrial Tachycardia",
    "Junctional Rhythm",
    "High-Degree AV Block",
    "AV Block",
    "Wolff-Parkinson-White (WPW) Syndrome",
    "Superaventricular Ectopics",
    "Ventricular Ectopics",
    "Supraventricular Tachycardia",
    "Ventricular Tachycardia",
    "Ventricular Premature Contraction (VPC) Detected",
    "Sinus Bradycardia",
    "Sinus Tachycardia"
]

export default arrhythmiaTextData;