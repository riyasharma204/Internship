import SvgColor from '../../../components/svg-color';
import { AccountBox, ManageAccounts, GroupAdd, People, NoteAlt, History, Description, CurrencyRupee, MonitorHeart } from '@mui/icons-material';

const icon = (name) => <SvgColor src={`${process.env.REACT_APP_HOMEPAGE}assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />;

const generateNavConfig = (userType) => {
  let navConfig = [];
  
  switch (userType) {
    case 'user':
      navConfig = [
        {
          title: 'dashboard',
          path: `userDashboard`,
          icon: icon('ic_analytics'),
        },
        {
          title: 'Tests',
          path: `allTests`,
          icon: icon('ic_stethoscope'),
        },
        {
          title: 'Paid Requests',
          path: 'userOrder',
          icon: <History />,
        },
      ];
      break;
    case 'expert':
      navConfig = [
        {
          title: 'dashboard',
          path: `expertDashboard`,
          icon: icon('ic_analytics'),
        },
        {
          title: 'Reports',
          path: `allReports`,
          icon: <Description />,
        },
        {
          title: 'Interpretation Utility',
          path: `interpretationUtility`,
          icon: <NoteAlt />,
        },
        {
          title: 'Profile',
          path: 'profile',
          icon: <AccountBox />,
        }
      ];
      break;
    case 'b2b':
      navConfig = [
        {
          title: 'dashboard',
          path: `b2bDashboard`,
          icon: icon('ic_analytics'),
        },
        {
          title: 'Tests',
          path: `allTests`,
          icon: icon('ic_stethoscope'),
        },
        {
          title: 'Profile',
          path: 'profile',
          icon: <AccountBox />,
        },
        {
          title: 'Associated Users',
          path: 'associated-users',
          icon: <ManageAccounts />,
        },
        {
          title: 'Procured Devices',
          path: 'procured-devices',
          icon: icon('ic_device'),
        },
        {
          title: 'Device Usage',
          path: 'deviceusage',
          icon: <MonitorHeart />
        },
        {
          title: 'Manage Business Users',
          path: 'business-users',
          icon: <ManageAccounts />,
        },
      ];
      break;
      case 'b2b-user':
        navConfig = [
          {
            title: 'dashboard',
            path: `b2b-userDashboard`,
            icon: icon('ic_analytics'),
          },
          {
            title: 'Profile',
            path: 'profile',
            icon: <AccountBox />,
          },
        ];
        break;
    case 'admin':
      navConfig = [
        {
          title: 'dashboard',
          path: `adminDashboard`,
          icon: icon('ic_analytics'),
        },
        {
          title: 'Reports',
          path: `allReports`,
          icon: <Description />,
        },
        {
          title: 'Profile',
          path: 'profile',
          icon: <AccountBox />,
        },
        {
          title: 'Manage User',
          path: 'internal-users',
          icon: <ManageAccounts />,
        },
        {
          title: 'Manage Client',
          path: 'clients',
          icon: <GroupAdd />,
        },
        {
          title: 'View B2B Dashboard',
          path: 'b2b-dashboard',
          icon: icon('ic_analytics'),
        },
      ];
      break;
      case 'superuser':
        navConfig = [
          {
            title: 'dashboard',
            path: `adminDashboard`,
            icon: icon('ic_analytics'),
          },
          {
            title: 'Reports',
            path: `allReports`,
            icon: <Description />,
          },
          {
            title: 'Profile',
            path: 'profile',
            icon: <AccountBox />,
          },
          {
            title: 'Manage User',
            path: 'internal-users',
            icon: <ManageAccounts />,
          },
          {
            title: 'Manage Client',
            path: 'clients',
            icon: <GroupAdd />,
          },
          {
            title: 'finance',
            path: 'finance',
            icon: <CurrencyRupee />,
          },
          {
            title: 'View B2B Dashboard',
            path: 'b2b-dashboard',
            icon: icon('ic_analytics'),
          },
        ];
        break;
      default:
        break;
  }

  return navConfig;
};

export default generateNavConfig;