import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const useAuthDispatch = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthDispatch must be used within a AuthStateProvider');
  }
  return context;
};

export const AuthStateProvider = ({ children }) => {
  const userAccount = localStorage.getItem('TokenDetails') ? JSON.parse(localStorage.getItem('TokenDetails')) : null;
  const [account, setAccount] = useState(userAccount?.authorization ? userAccount : null);

  const setLocalStorage = (key, value) => {
    localStorage.setItem(key, JSON.stringify(value))
    setAccount(JSON.parse(localStorage.getItem('TokenDetails')))
  }

  const updateLocalStorage = (key, value) => {
    // const existingData = JSON.parse(localStorage.getItem(key)) || {};

    const updatedData = { ...account||{}, ...value };
    localStorage.setItem(key, JSON.stringify(updatedData));
    if (key === 'TokenDetails') {
      setAccount(updatedData);
    }
  };
  

  return (
    <AuthContext.Provider value={{ updateLocalStorage, account, setAccount, setLocalStorage }}>
      {children}
    </AuthContext.Provider>
  );
};












