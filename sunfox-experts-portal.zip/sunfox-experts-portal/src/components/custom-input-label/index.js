import * as React from 'react';

function CustomInputLabel(attr) {
    return (<span style={{ fontSize: (attr.size||"small")}} className={attr.className}>{attr.children}</span>)
}
export default CustomInputLabel; 