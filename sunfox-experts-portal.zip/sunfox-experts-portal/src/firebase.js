// src/firebase.js
import firebase from 'firebase/compat/app';
import 'firebase/compat/storage';

const firebaseConfig = {
    apiKey: "AIzaSyBI026hzC3sm_3hbCIanjijuNRZ25YnjxU",
    authDomain: "sunfox-ecg-interpretation.firebaseapp.com",
    projectId: "sunfox-ecg-interpretation",
    storageBucket: "sunfox-ecg-interpretation.appspot.com",
    messagingSenderId: "614086569547",
    appId: "1:614086569547:web:5487b1375378d395a8e7ce",
    measurementId: "G-F3KGGH0YNX"
  };

firebase.initializeApp(firebaseConfig);

export const storage = firebase.storage();
export default firebase;
