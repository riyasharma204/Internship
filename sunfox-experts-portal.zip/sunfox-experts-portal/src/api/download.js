// utils
import { fetcher, endpoints, poster, patcher } from '../utils/axios';

export async function downloadReportInJson(payload){
    // const backendUrl = 'http://localhost:3002';
    // const URL = `${backendUrl}${endpoints.device.report}`;
    const URL = endpoints.device.report;
    return await fetcher([URL, {params:payload}] )
}