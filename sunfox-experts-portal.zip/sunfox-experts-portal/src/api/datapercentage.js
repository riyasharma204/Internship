import { useMemo } from 'react';
// utils
import { fetcher, endpoints} from '../utils/axios';

export async function getMonthlyDataOrPercentages(payload){
    const URL = endpoints.testdata.getDataPercentage;
    return await fetcher([URL, {params:payload}] )
}