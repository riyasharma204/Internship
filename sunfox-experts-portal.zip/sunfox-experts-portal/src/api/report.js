import { useMemo } from 'react';
// utils
import { fetcher, endpoints} from '../utils/axios';

export async function getDeviceReports(payload){
    const URL = endpoints.report.getReports;
    return await fetcher([URL, {params:payload}] )
}