import { useMemo } from 'react';
// utils
import { fetcher, endpoints, patcher} from '../utils/axios';

export async function getAllDevices(payload){
    const URL = endpoints.device.getDevice;
    return await fetcher([URL, {params:payload}] )
}

export async function getDeviceReports(payload){
    const URL = endpoints.device.getReports+`${payload.device_id}`;
    return await fetcher([URL, {}] )
}

export async function downloadReportInJson(payload){
    const URL = endpoints.device.report;
    return await fetcher([URL, {params:payload}] )
}

export async function disableOrEnableDevice(payload){
    const URL = endpoints.device.disableEnable;
    return await patcher([URL, {params:payload}] )
}