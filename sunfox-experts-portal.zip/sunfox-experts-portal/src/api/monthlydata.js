import { useMemo } from 'react';
// utils
import { fetcher, endpoints} from '../utils/axios';

export async function getDeviceMonthlyCount(payload){
    const URL = endpoints.testdata.getMonthlyData;
    return await fetcher([URL, {params:payload}] )
}