import { useMemo } from 'react';
// utils
import { fetcher, endpoints} from '../utils/axios';

export async function getMonthlyTestsAndTheirCount(payload){
    const URL = endpoints.testdata. getTestCount;
    return await fetcher([URL, {params:payload}] )
}