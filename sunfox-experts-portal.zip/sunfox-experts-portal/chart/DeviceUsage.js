import React from 'react';
import { Grid } from '@mui/material';
import Chart from 'react-apexcharts';
import BarGraph from './barChart';

const testData = [
  { name: '12 Lead', count: 20 },
  { name: 'Lead 2', count: 10 },
  { name: '7 Lead', count: 40 },
  { name: 'HRV', count: 20 }
];

const totalTests1 = testData.reduce((acc, curr) => acc + curr.count, 0);

const devicesData = [
  { device: 'Device 1', tests: 30 },
  { device: 'Device 2', tests: 20 },
  { device: 'Device 3', tests: 40 }
];

const totalTests2 = devicesData.reduce((acc, curr) => acc + curr.tests, 0);

const ProgressChart = () => {
  const pieChartData = devicesData.map(device => ({
    x: device.device,
    y: device.tests
  }));

  const chartOptions = {
    labels: pieChartData.map(data => data.x),
    plotOptions: {
      pie: {
        startAngle: -90,
        endAngle: 90, 
        offsetY: 10,
        dataLabels: {
          offset: 0,
          minAngleToShowLabel: 10
        },
        donut: {
          size: '65%' 
        }
      }
    },
    colors: ['#ff6347', '#4682b4', '#32cd32'], 
    chart: {
      toolbar: {
        show: false 
      }
    }
  };

  const chartData = {
    series: testData.map(data => (data.count / totalTests1) * 100),
    options: {
      chart: {
        height: 350,
        type: 'radialBar',
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: '40%' 
          },
          dataLabels: {
            show: true ,
            total: {
                show: true, 
                label: 'Total Tests', // Label for total
                formatter: function (w) {
                  return totalTests1; // Display total test count
                }
              },
          },
          track: {
            show: false 
          },
        }
      },
      labels: testData.map(data => data.name),
      legend: {
        show: true,
        position: 'bottom', 
      }
    }
  };

  return (
    <Grid container spacing={4}>
      <Grid item xs={12} sm={6} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <Chart
          options={chartOptions}
          series={pieChartData.map(data => data.y)}
          type="donut"
          width="200%"
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <Chart
          options={chartData.options}
          series={chartData.series}
          type="radialBar"
          width="100%"
        />
      </Grid>
      <Grid item xs={12} sm={12}>
      <BarGraph/>
      </Grid>
    </Grid>
  );
};

export default ProgressChart;
