import React from 'react';
import Chart from 'react-apexcharts';

// Sample data for demonstration
const testData = [
    { month: 'January', device1: 10, device2: 20, device3: 15 },
    { month: 'February', device1: 15, device2: 25, device3: 20 },
    { month: 'March', device1: 8, device2: 40, device3: 13 },
    { month: 'April', device1: 12, device2: 10, device3: 30 },
    { month: 'May', device1: 23, device2: 19, device3: 11 },
    { month: 'June', device1: 9, device2: 18, device3: 23 },
    { month: 'July', device1: 17, device2: 30, device3: 19 },
    { month: 'August', device1: 14, device2: 10, device3: 25 },
    { month: 'September', device1: 25, device2: 34, device3: 23 },
    { month: 'October', device1: 23, device2: 20, device3: 21 },
    { month: 'November', device1: 13, device2: 29, device3: 18 },
    { month: 'December', device1: 20, device2: 33, device3: 29 },
  
];

const months = testData.map(data => data.month);

const totalTestsByMonth = testData.map(data =>
  Object.values(data).slice(1).reduce((acc, curr) => acc + curr, 0)
);

const series = [
  { name: 'Device 1', data: testData.map(data => data.device1) },
  { name: 'Device 2', data: testData.map(data => data.device2) },
  { name: 'Device 3', data: testData.map(data => data.device3) }
];

// Define colors for devices
const deviceColors = ['#0088FE', '#FF69B4', '#800080'];

const options = {
  chart: {
    type: 'bar',
    height: 400,
    stacked: true,
    toolbar: {
      show: false
    }
  },
  plotOptions: {
    bar: {
      horizontal: false,
    },
  },
  xaxis: {
    categories: months,
    title: {
      text: 'Month'
    },
  },
  yaxis: {
    title: {
      text: 'Total Tests'
    },
  },
  legend: {
    show: false,
    position: 'bottom',
    offsetY: 40,
    
  },
  grid: {
    show: false // Hide background grid lines
  }
 
};

const BarGraph = () => {
  return (
    <div>
      <h2>Total Tests by Month</h2>
      <Chart options={options} series={series} type="bar" height={400} />
    </div>
  );
};

export default BarGraph;
