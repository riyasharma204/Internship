
const sendToRoom = (room, event, data) => {
    const { broadcastToRoom } = require('./socket-io')
    broadcastToRoom(room, event, data);
}

const sendToAll = (event, data) => {
    const { broadcastToAll } = require('./socket-io')
    broadcastToAll(event, data);
}

const sendToSocket = (socketId, event, data) => {
    const { broadcastToSocket } = require('./socket-io')
    broadcastToSocket(socketId, event, data);
}

module.exports = { sendToAll, sendToRoom, sendToSocket };
