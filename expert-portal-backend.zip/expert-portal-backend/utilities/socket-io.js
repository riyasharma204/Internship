
const socketIo = require('socket.io')
const { setSocket } = require("../controllers/userController");
const { decodeJWT } = require('../controllers/middleware')
const { setReportStatus } = require('../controllers/ecgController')

let interpretationService;
const initSocket = (server) => {
    const io = socketIo(server, {
        cors: {
            origin: "*",
            methods: ["GET", "HEAD", "PUT", "PATCH", "POST", "DELETE"],
            credentials: true,
        },
    });

    interpretationService = io.of(
        process.env.SPANDAN_SERVICE_HOME_ROUTE || "/"
    );

    //socket.io connection
    interpretationService.on("connection", (socket) => {
        socket.on("event", async (info) => {
            try {
                const { authToken, socketId } = info;
                const user = await decodeJWT(authToken);
                if (user) {
                    if (socketId) await setSocket(user?.phoneNumber, socketId);
                    if (user?.userType === "expert") {
                        socket.join("Expert");
                    }
                }
            } catch (err) {
                console.log("Socket IO [ERRO]: ", err)
            }
        });

        //to receive Tests requested for Interpreation from b2b user 
        socket.on('requestedReport', async (ids, authToken) => {
            try {
                const user = await decodeJWT(authToken);
                if (user && user?.phoneNumber) {
                    // const result = await setReportStatus(ids, "requested", null, null, user, true);
                    // if (result) interpretationService.to('Expert').emit('addReport', result)
                }
            } catch (error) {
                console.log("Socket IO [ERRO]: ", error)
            }
        })

        socket.on("onClickInterpret", async (id, authToken) => {
            try {
                const user = await decodeJWT(authToken);
                if (user && user?.phoneNumber) {
                    const updatedReport = await setReportStatus(
                        [id],
                        "in progress",
                        null,
                        null,
                        user
                    );
                    broadcastToRoom("Expert", "InterpretationInProgress", updatedReport[0]);
                }
            } catch (error) {
                console.log("Socket IO [ERRO]: ", error);
            }
        });
    });

    return interpretationService;
}

const broadcastToRoom = (room, event, data) => {
    interpretationService.to(room).emit(event, data);
}

const broadcastToAll = (event, data) => {
    interpretationService.emit(event, data);
}

const broadcastToSocket = (socketId, event, data) => {
    interpretationService.to(socketId).emit(event, data);
}

module.exports = { initSocket, broadcastToSocket, broadcastToRoom, broadcastToAll };
