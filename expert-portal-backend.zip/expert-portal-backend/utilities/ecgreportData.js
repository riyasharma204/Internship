const AWS = require('../config/aws');
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

const getEcgReportData = async (id) => {
  try {
    const params = {
      TableName: process.env.ECG_RECORD_DATA_TABLE,
      Key: { id: Number(id) },
      ProjectionExpression: 'id, phone_number, report_timestamp, interpretation_data, user_data, report_type, paths, interpretation_request_status, interpreter_details',
    };

    const { Item } = await dynamodb.get(params).promise();
    return Item;
  } catch (error) {
    throw error;
  }
};

const readFileFromS3Bucket = async (path,report_type) => {
  try {
    const bucketName = process.env.AWS_S3_BUCKET_NAME;
    const params = {
      Bucket: bucketName,
      Key: `${report_type}/${path.split('/')[0]}/${path.split('/')[1]}`,
    };
  
    const { Body } = await s3.getObject(params).promise();
    return Body;
  } catch (error) {
    throw error;
  }
};
const readS3BucketLeadFiles = async (paths,report_type) => {
  if (!paths) return null;
  const ecgLeadData = Object.keys(paths);
  const leadsData = {};
  for (const leadData of ecgLeadData) {
    const leadPath = paths[leadData];
    const fileData = bufferToText(await readFileFromS3Bucket(leadPath,report_type));
    const fileDataList = fileData.split(',');
    leadsData[leadData] = fileDataList;
  } 
  return leadsData;
};

const bufferToText = (bufferData, encoding = 'utf-8') => {
  const textData = Buffer.from(bufferData).toString(encoding);
  return textData;
};

module.exports = {
  getEcgReportData,
  readS3BucketLeadFiles
};
