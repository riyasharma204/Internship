const dayjs = require('dayjs');
const AWS = require("../config/aws");
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const {errorLog} = require('./errorLogs')


async function getPendingCount(startTimestamp, endTimestamp, user_phone_number, business_id) {
  const pendingStatus = ["requested", "in progress"];
  let totalPending = 0;
  for (const status of pendingStatus) {
    const queryParams = {
      TableName: process.env.ECG_RECORD_DATA_TABLE,
      IndexName: "interpretation_request_status-interpretation_requested_at-index",
      KeyConditionExpression:
        "interpretation_request_status = :interpretation_request_status AND interpretation_requested_at BETWEEN :startTimestamp AND :endTimestamp",
      ExpressionAttributeValues: {
        ":interpretation_request_status": status,
        ":startTimestamp": startTimestamp,
        ":endTimestamp": endTimestamp,
      },
      ProjectionExpression: "id",
    };

    if (user_phone_number) {
      queryParams.FilterExpression = "phone_number = :userPhoneNumber";
      queryParams.ExpressionAttributeValues[":userPhoneNumber"] = user_phone_number;
    }

    if (business_id) {
      queryParams.FilterExpression = "business_id = :business_id";
      queryParams.ExpressionAttributeValues[":business_id"] = business_id;
    }
    const { Count } = await dynamoDB.query(queryParams).promise();  
    totalPending += Count;
  }
  return totalPending;
}

async function getExpertCompleteCount(expert_phone_number, startTimestamp, endTimestamp, user_phone_number, business_id) {
  const queryParams = {
    TableName: process.env.ECG_RECORD_DATA_TABLE,
    IndexName: "interpreter_phone_number-interpretation_completed_at-index",
    KeyConditionExpression:
      "interpreter_phone_number = :expertPhoneNumber AND interpretation_completed_at BETWEEN :startTimestamp AND :endTimestamp",
    FilterExpression:
      "interpretation_request_status = :interpretation_request_status",
    ExpressionAttributeValues: {
      ":interpretation_request_status": "completed",
      ":startTimestamp": startTimestamp,
      ":endTimestamp": endTimestamp,
      ":expertPhoneNumber": expert_phone_number,
    },
    ProjectionExpression: "id",
  };

  if (user_phone_number) {
    queryParams.FilterExpression += " AND phone_number = :userPhoneNumber";
    queryParams.ExpressionAttributeValues[":userPhoneNumber"] = user_phone_number;
  }

  if (business_id) {
    queryParams.FilterExpression += " AND business_id = :business_id";
    queryParams.ExpressionAttributeValues[":business_id"] = business_id;
  }

  const { Count, Items } = await dynamoDB.query(queryParams).promise();
  return Count;
}

async function getTotalCompletedCount(startTimestamp, endTimestamp, user_phone_number, business_id) {
    const getParams = {
      TableName: process.env.INTERNAL_USERS_TABLE,
      FilterExpression: "user_type = :user_type",
      ExpressionAttributeValues: {
        ":user_type": "expert",
      }
    };

    const { Items } = await dynamoDB.scan(getParams).promise();

    let completedCount = 0;
    let expertsWiseCount = {};
    let expertsCount = [];
    if (Items?.length) {
      return Promise.all(
        Items.map(async ({ phone_number, name }) => {
          const total = await getExpertCompleteCount(phone_number, startTimestamp, endTimestamp, user_phone_number, business_id);
          completedCount += total;
          expertsWiseCount[name] = total;
          expertsCount.push({ name, phone_number, count: total })
        })
      )
        .then(() => {
          return { completedCount, expertsWiseCount, expertsCount };
        });
    } else {
      return { completedCount, expertsWiseCount, expertsCount };
    }
}

async function getExpertCompleteItems(expert_phone_number, startTimestamp, endTimestamp, user_phone_number, business_id) {
  const queryParams = {
    TableName: process.env.ECG_RECORD_DATA_TABLE,
    IndexName: "interpreter_phone_number-interpretation_completed_at-index",
    KeyConditionExpression:
      "interpreter_phone_number = :expertPhoneNumber AND interpretation_completed_at BETWEEN :startTimestamp AND :endTimestamp",
    FilterExpression:
      "interpretation_request_status = :interpretation_request_status",
    ExpressionAttributeValues: {
      ":interpretation_request_status": "completed",
      ":startTimestamp": startTimestamp,
      ":endTimestamp": endTimestamp,
      ":expertPhoneNumber": expert_phone_number,
    },
    ProjectionExpression: "id, phone_number, interpretation_request_status, interpretation_report_status",
  };

  if (user_phone_number) {
    queryParams.FilterExpression += " AND phone_number = :userPhoneNumber";
    queryParams.ExpressionAttributeValues[":userPhoneNumber"] = user_phone_number;
  }

  if (business_id) {
    queryParams.FilterExpression += " AND business_id = :business_id";
    queryParams.ExpressionAttributeValues[":business_id"] = business_id;
  }

  const { Items } = await dynamoDB.query(queryParams).promise();
  return Items;
}

async function getTotalCompletedItems(startTimestamp, endTimestamp, user_phone_number, business_id) {
    const getParams = {
      TableName: process.env.INTERNAL_USERS_TABLE,
      ProjectionExpression: "phone_number",
      FilterExpression: "user_type = :user_type",
      ExpressionAttributeValues: {
        ":user_type": "expert",
      }
    }

    const { Items } = await dynamoDB.scan(getParams).promise();

    let totalItems = [];
    let expertsItem = [];
    if (Items?.length) {
      return Promise.all(
        Items.map(async ({ phone_number, name }) => {
          const Items = await getExpertCompleteItems(phone_number, startTimestamp, endTimestamp, user_phone_number, business_id);
          totalItems.push(...Items);
          expertsItem.push({ name, phone_number, items: Items })
        })
      )
        .then(() => {
          return { totalItems, expertsItem };
        });
    } else {
      return { totalItems, expertsItem };
    }
}

const get_requested_today_count = async (req, res) => {
  const reponse = await get_requested_today_count_data(req?.query, req?.headers?.user);
  return res.json({ status: 200, success: reponse?.data ? true : false, data: reponse });
};

async function get_requested_today_count_data(payload, auth) {
  try {
    const startDateTime = dayjs().startOf('day').valueOf().toString()
    const endDateTime = dayjs().endOf('day').valueOf().toString()

    if (auth?.userType === "expert" || auth?.userType === "admin" || auth?.userType === "superuser") {
      const todayPending = await getPendingCount(startDateTime, endDateTime, null, payload?.business_id);
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, payload?.business_id);
      return {
        data: {
          todayRequested: completedCount + todayPending
        },
      };
    } else if (auth?.userType === "b2b" || auth?.userType === "b2b-user") {
      const todayPending = await getPendingCount(startDateTime, endDateTime, null, auth?.business_id);
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, auth?.business_id);
      return {
        data: {
          todayRequested: completedCount + todayPending
        },
      };
    } else { //for user
      const todayPending = await getPendingCount(startDateTime, endDateTime, auth?.phoneNumber);
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, auth?.phoneNumber);
      return {
        data: {
          todayRequested: completedCount + todayPending
        },
      };
    }
  } catch (error) {
    await errorLog(error,'get_requested_today_count_data','analyticsController.js')
    return {
      error
    };
  }
}

const get_completed_today_count = async (req, res) => {
  const reponse = await get_completed_today_count_data(req?.query, req?.headers?.user);
  return res.json({ status: 200, success: reponse?.data ? true : false, data: reponse });
};

async function get_completed_today_count_data(payload, auth) {
  try {
    const startDateTime = dayjs().startOf('day').valueOf()?.toString();
    const endDateTime = dayjs().endOf('day').valueOf()?.toString();
    if (auth?.userType === "expert") {
      const Count = await getExpertCompleteCount(auth?.phoneNumber, startDateTime, endDateTime);
      return {
        data: {
          todayCompleted: Count
        }
      };
    } else if (auth?.userType === "admin" || auth?.userType === "superuser") {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, payload?.business_id);
        return {
          data: {
            todayCompleted: completedCount
          },
        };
    } else if (auth?.userType === "b2b" || auth?.userType === "b2b-user") {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, auth?.business_id);
        return {
          data: {
            todayCompleted: completedCount
          },
        };
    } else {
      //for user
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, auth?.phoneNumber); 
      return {
        data: {
          completedCount
        }
      };
    }
  } catch (error) {
    await errorLog(error,'get_completed_today_count_data','analyticsController.js')

    return {
      error
    }
  }
};

const get_completed_count_in_last_30_days = async (req, res) => {
  const reponse = await get_completed_count_in_last_30_days_data(req?.query, req?.headers?.user);
  return res.json({ status: 200, success: reponse?.data ? true : false, data: reponse });
};

async function get_completed_count_in_last_30_days_data(payload, auth) {
  try {
    const startDateTime = dayjs().add(-30, 'day').startOf('day').valueOf()?.toString();
    const endDateTime = dayjs().endOf('day').valueOf()?.toString();
    if (auth?.userType === "expert") {
      const totalCompleted = await getExpertCompleteCount(auth?.phoneNumber, startDateTime, endDateTime);
      return {
        data: {
          totalCompleted
        }
      }
    } else if (auth?.userType === "admin" || auth?.userType === "superuser" ) {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, payload?.business_id);
      return {
        data: {
          totalCompleted: completedCount
        }
      };
    }else if( auth?.userType === "b2b"||auth?.userType === "b2b-user"){
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, auth?.business_id);
      return {
        data: {
          totalCompleted: completedCount
        }
      };
    } else {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, auth?.phoneNumber);
      return {
        data: {
          totalCompleted: completedCount
        }
      };
    }
  } catch (error) {
    await errorLog(error,'get_completed_count_in_last_30_days_data','analyticsController.js')

    return {
      error
    }
  }
}

const get_pending_count_in_last_30_days = async (req, res) => {
  const reponse = await get_pending_count_in_last_30_days_data(req?.query, req?.headers?.user);
  return res.json({ status: 200, success: reponse?.data ? true : false, data: reponse });
};

async function get_pending_count_in_last_30_days_data (payload, auth) {
  try {


    const startDateTime = dayjs().add(-30, 'day').startOf('day').valueOf()?.toString();
    const endDateTime = dayjs().endOf('day').valueOf()?.toString();
    if (auth?.userType === "expert" || auth?.userType === "admin" || auth?.userType === "superuser") {
      const totalPending = await getPendingCount(startDateTime, endDateTime, null,  payload?.business_id);
      return {
        data: {
          totalPending
        }
      }
    } else if(auth?.userType === "b2b" || auth?.userType === "b2b-user"){
      const totalPending = await getPendingCount(startDateTime, endDateTime, null, auth?.business_id );
      return {
        data: {
          totalPending
        }
      }
    }
    else {
      const totalPending = await getPendingCount(startDateTime, endDateTime, auth?.phoneNumber);
      return {
        data: {
          totalPending
        }
      }
    }
  } catch (error) {
    await errorLog(error,'get_pending_count_in_last_30_days_data','analyticsController.js')

    return {
      error
    }
  }
}

const get_interpretation_analytics = async (req, res) => { 
  const todayRequested = await get_requested_today_count_data(req?.query, req?.headers?.user);
  const todayCompleted = await get_completed_today_count_data(req?.query, req?.headers?.user);

  const totalCompleted = await get_completed_count_in_last_30_days_data(req?.query, req?.headers?.user);
  const totalPending = await get_pending_count_in_last_30_days_data(req?.query, req?.headers?.user);

  return res.json({ status: 200, success: true, data: { ...todayRequested?.data, ...todayCompleted?.data, ...totalCompleted?.data, ...totalPending?.data  } })
}

const get_annual_report = async (req, res) => { 
  try {
    const data = await get_annual_report_data(req.query, req.headers?.user);
    return res.json({ status: 200, success: true, data });
  } catch (error) {
    await errorLog(error,'get_annual_report','analyticsController.js')
    return res.json({ status: error?.code, success: false, message: error?.message, data: error })
  }
}

const get_monthly_report = async (req, res) => { 
  try {
    const data = await get_monthly_report_data(req.query, req.headers?.user);
    return res.json({ status: 200, success: true, data });
  } catch (error) {
    await errorLog(error,'get_annual_report','analyticsController.js')
    return res.json({ status: error?.code, success: false, message: error?.message, data: error })
  }
}

async function get_annual_report_data(payload, auth) {
  const months = [];
  // for last 12 months data  
  let dataSet = [];
  for (const count of Array.from({ length: 12 }, (_, index) => index++)) {
    const monthObj = dayjs().add(-count, "month")
    let startDateTime = monthObj.startOf('month').startOf('day').valueOf()?.toString();
    let endDateTime = monthObj.endOf('month').endOf('day').valueOf()?.toString();
    let month = monthObj.startOf('month').format("MMM'YY");

    if (auth?.userType === "admin" || auth?.userType === "b2b") {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, auth?.business_id);
      const pending = await getPendingCount(startDateTime, endDateTime, null, auth?.business_id);
      dataSet = [{ month, requested: (completedCount + pending), completed: completedCount, pending }, ...dataSet];
    } else if (auth?.userType === "expert") {
      const completed_by_me = await getExpertCompleteCount(auth?.phoneNumber, startDateTime, endDateTime);
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime);
      const pending = await getPendingCount(startDateTime, endDateTime);
      dataSet = [{ month, requested: (completedCount + pending), completed: completedCount, pending, completed_by_me }, ...dataSet];
    } else {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, auth?.phoneNumber);
      const pending = await getPendingCount(startDateTime, endDateTime, auth?.phoneNumber);
      dataSet = [{ month, requested: (completedCount + pending), completed: completedCount, pending }, ...dataSet];
    }
  }
  return dataSet;
}

async function get_monthly_report_data(payload, auth) {

  const monthName = dayjs(payload?.date, "DD-MM-YY").format("MMMM");

  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const monthIndex = months.findIndex((name) => name.toLowerCase() === monthName.toLowerCase());
  const totalDaysInMonth = dayjs().month(monthIndex).daysInMonth();

  let dataSet = [];
  for (const day of Array.from({ length: totalDaysInMonth }, (_, index) => index + 1)) {
    const startDateTime = dayjs().month(monthIndex).date(day).startOf('day').valueOf()?.toString();
    const endDateTime = dayjs().month(monthIndex).date(day).endOf('day').valueOf()?.toString();
    
    const displayDate = dayjs().month(monthIndex).date(day).format("MM/DD/YYYY");
    const date = dayjs().month(monthIndex).date(day).format("DD");
    
    if (startDateTime > dayjs().month(monthIndex).startOf('day').valueOf()?.toString()) return dataSet;

    if (auth?.userType === "admin" || auth?.userType === "b2b") {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, null, auth?.business_id);
      const pending = await getPendingCount(startDateTime, endDateTime, null, auth?.business_id);
      dataSet = [{ date, displayDate, requested: (completedCount + pending), completed: completedCount, pending }, ...dataSet];
    } else if (auth?.userType === "expert") {
      const completed_by_me = await getExpertCompleteCount(auth?.phoneNumber, startDateTime, endDateTime);
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime);
      const pending = await getPendingCount(startDateTime, endDateTime);
      dataSet = [{ date, displayDate, requested: (completedCount + pending), completed: completedCount, pending, completed_by_me }, ...dataSet];
    } else {
      const { completedCount } = await getTotalCompletedCount(startDateTime, endDateTime, auth?.phoneNumber);
      const pending = await getPendingCount(startDateTime, endDateTime, auth?.phoneNumber);
      dataSet = [{ date, displayDate, requested: (completedCount + pending), completed: completedCount, pending }, ...dataSet];
    }
  }
  return dataSet;
}

const get_total_completed_group_by_expert_and_report_types = async (req,res) => {
  const payload = req.query;
  const auth = req.headers?.user;
  try {
    const startDateTime = dayjs().add(-30, 'day').startOf('day').valueOf()?.toString();
    const endDateTime = dayjs().endOf('day').valueOf()?.toString();

    if(auth?.userType === 'expert' || auth?.userType === 'admin' || auth?.userType === 'superuser') {
      if (payload?.business_id) {
        const { totalItems } = await getTotalCompletedItems(startDateTime, endDateTime, null, payload?.business_id)
        let reportStatusCounts = null;
        totalItems.map(item => {
          if (!reportStatusCounts) reportStatusCounts = {};
          if (item?.interpretation_report_status) reportStatusCounts[item?.interpretation_report_status] = (reportStatusCounts[item?.interpretation_report_status] || 0) + 1;
        })
        return res.json({ success: true, status: 200, data: reportStatusCounts })
      }
      const { expertsWiseCount } = await getTotalCompletedCount(startDateTime, endDateTime);
      return res.json({ success: true, status: 200, data: expertsWiseCount })
    } else { //users
      const { totalItems } = auth?.userType === 'b2b' 
                            ? await getTotalCompletedItems(startDateTime, endDateTime, null, auth?.business_id)
                            : await getTotalCompletedItems(startDateTime, endDateTime, auth?.phoneNumber);
      let reportStatusCounts = null;
      totalItems.map(item => {
        if (!reportStatusCounts) reportStatusCounts = {};
        if (item?.interpretation_report_status) reportStatusCounts[item?.interpretation_report_status] = (reportStatusCounts[item?.interpretation_report_status] || 0) + 1;
      })
      return res.json({ success: true, status: 200, data: reportStatusCounts })
    }
  } catch(error){
      await errorLog(error,'get_total_completed_group_by_expert_and_report_types','analyticsController.js')
      return res.status(500).json({ message: 'Some error occured' })
  }
}

module.exports = {
  get_interpretation_analytics,
  get_annual_report,
  get_monthly_report,
  get_total_completed_group_by_expert_and_report_types,
  get_completed_count_in_last_30_days,
  get_completed_today_count,
  get_pending_count_in_last_30_days,
  get_requested_today_count,
  get_requested_today_count_data,
  get_completed_today_count_data
};
