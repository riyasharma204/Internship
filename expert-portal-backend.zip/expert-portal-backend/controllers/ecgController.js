const AWS = require('../config/aws');
const dayjs = require('dayjs');
const { getEcgReportData, readS3BucketLeadFiles } = require('../utilities/ecgreportData');
const { get_requested_today_count_data, get_completed_today_count_data } = require('./analyticsController')
const { generateInterpretatedPdf } = require("./reportController");
const dynamodb = new AWS.DynamoDB.DocumentClient();
const messages = require('../utils/messages')
const razorpay = require('../config/razorpay')
const ECGData = require("../ecg-data");
const { sendToRoom } = require("../utilities/socketEvents")
const { errorLog } = require('./errorLogs');
const { sendPushNotifications } = require('../utils/pushNotification');
const { getUserFromFirebase } = require('./authController');
const admin = require('../config/firebase')


const getList = async (req, res) => {
  const auth = req.headers?.user;
  if (!auth) return res.json({ status: 403, success: false, message: messages.authentication.invalidAccessToken })

  try {
    
    const batchSize = 100
    const now = dayjs()

    // id is phoneNumber    
    const { id, business_id, startDate, endDate, status } = req.query
    const endDateTime = endDate ? dayjs(endDate, "DD MMM, YYYY").endOf('day').valueOf().toString() : now.endOf('day').valueOf().toString()
    const startDateTime = startDate ? dayjs(startDate, "DD MMM, YYYY").startOf('day').valueOf().toString() : now.startOf('day').valueOf().toString()
    
    let params = {
      TableName: process.env.ECG_RECORD_DATA_TABLE,
      ExpressionAttributeValues: {
        ':startTimestamp': startDateTime,
        ':endTimestamp': endDateTime
      }
    }


    if (auth?.userType === "b2b"){

      const totalItems = []

      const phone_numbers = [...auth?.associated_users, id ]

      for (const ass_user_number of phone_numbers) {
          // Set up query parameters for each user
          params.IndexName = "phone_number-report_timestamp-index"
          params.KeyConditionExpression = "phone_number = :phoneNumber AND report_timestamp BETWEEN :startTimestamp AND :endTimestamp"
          params.ExpressionAttributeValues[':phoneNumber'] = ass_user_number

          // Execute the query
          const { Items } = await dynamodb.query(params).promise();

          // Add fetched items to the totalItems array
          totalItems.push(...Items)
      }

      const projectionAttributes = 'conclusions, report_timestamp, id, report_type, user_data, interpretation_request_status, interpretation_report_status, interpretation_requested_at, interpretation_display_requested_at, interpretation_completed_at, interpretation_display_completed_at, interpreter_phone_number, interpreter_details, interpretation_data_logs'
      let allBatchGetResults = []

      for (let i = 0; i < totalItems.length; i += batchSize) {
        const batchIds = totalItems.slice(i, i + batchSize).map(item => ({ id: item.id }))
        const params2 = {
          RequestItems: { [`${process.env.ECG_RECORD_DATA_TABLE}`]: { Keys: batchIds, ProjectionExpression: projectionAttributes } }
        }
  
        const response = await dynamodb.batchGet(params2).promise()
        const flatData = response.Responses[`${process.env.ECG_RECORD_DATA_TABLE}`]
        allBatchGetResults.push(...flatData)
      } 
      if (status) allBatchGetResults = allBatchGetResults?.filter(item => item?.interpretation_request_status === status);
      
      return res.json({ status: 200, success: true, message: messages.getList.successfullyGotResults, data: allBatchGetResults })
    }
    else{

      if (id && auth?.userType === "user") { //for users
        params.IndexName = "phone_number-report_timestamp-index"
        params.KeyConditionExpression = "phone_number = :phoneNumber AND report_timestamp BETWEEN :startTimestamp AND :endTimestamp"
        params.ExpressionAttributeValues[':phoneNumber'] = id
  
        if (status) {
          params.FilterExpression = "interpretation_request_status = :status"
          params.ExpressionAttributeValues[':status'] = status
        }
      } else { // for interpreter, admin or superadmin
        params.IndexName = "interpretation_request_status-interpretation_requested_at-index"
        params.KeyConditionExpression = "interpretation_request_status = :interpretation_request_status AND interpretation_requested_at BETWEEN :startTimestamp AND :endTimestamp" 
        params.ExpressionAttributeValues[':interpretation_request_status'] = status || null;
        if (business_id) {
          params.FilterExpression = "business_id = :business_id"
          params.ExpressionAttributeValues[':business_id'] = business_id
        }
      }
      const totalItems = []
      if (!status && !id && (auth?.userType === "expert" || auth?.userType === "admin" || auth?.userType === "superuser")) {
          const status_types = ['requested', 'in progress', 'completed']
          for (const statuss of status_types) {
            params.ExpressionAttributeValues[':interpretation_request_status'] = statuss
            const { Items } = await dynamodb.query(params).promise()
            totalItems.push(...Items)
          }
      } else {
        const { Items } = await dynamodb.query(params).promise()
        totalItems.push(...Items)
      }
  
      const projectionAttributes = 'conclusions,report_timestamp, id, report_type, user_data, interpretation_request_status, interpretation_report_status, interpretation_requested_at, interpretation_display_requested_at, interpretation_completed_at, interpretation_display_completed_at, interpreter_phone_number, interpreter_details,interpretation_data_logs'
      const allBatchGetResults = []
  
      for (let i = 0; i < totalItems.length; i += batchSize) {
        const batchIds = totalItems.slice(i, i + batchSize).map(item => ({ id: item.id }))
        const params2 = {
          RequestItems: { [`${process.env.ECG_RECORD_DATA_TABLE}`]: { Keys: batchIds, ProjectionExpression: projectionAttributes } }
        }
  
        const response = await dynamodb.batchGet(params2).promise()
        const flatData = response.Responses[`${process.env.ECG_RECORD_DATA_TABLE}`]
        allBatchGetResults.push(...flatData)
      } 

      return res.json({ status: 200, success: true, message: messages.getList.successfullyGotResults, data: allBatchGetResults })
    }
 
  } catch (err) {
    await errorLog(err, 'getList', 'ecgController.js')
    res.json({ status: 400, success: false, message: err?.message || messages.getList.errorGettingResults, data: err })
  }
}

const saveInterpretationData = async (req, res) => {

  if (!req.headers?.user) return res.json({ status: 403, success: false, message: messages.authentication.invalidAccessToken })

  const interpreter_details = req.headers?.user
  const { id, interpretationFormData } = req.body
  if (!id || !interpretationFormData) {
    return res.json({ status: 400, success: false, message: messages.saveInterpretationData.idInterpretationFormDataMissing })
  }
  const getParams = {
    TableName: process.env.ECG_RECORD_DATA_TABLE,
    Key: { id: Number(id) }
  }
  try {
    const { Item } = await dynamodb.get(getParams).promise();
    let previousInterpretationData = Item["interpretation_data_logs"] || [];
    let interpretationData = { ...Item["interpretation_data"] };
    if (Item["interpreter_details"]) {
      interpretationData = {
        ...interpretationData,
        interpreter_details: Item["interpreter_details"]
      };
    }
    previousInterpretationData = [...previousInterpretationData, interpretationData];

    const newInterpretationData = { ...interpretationData, ...interpretationFormData, completed_at: dayjs().valueOf(), display_completed_at: dayjs().format() }
    const updateParams = {
      TableName: process.env.ECG_RECORD_DATA_TABLE,
      Key: { id: Number(id) },
      UpdateExpression: `SET interpretation_data = :updatedObject,interpretation_data_logs=:interpretation_data_logs,  interpretation_request_status = :status, interpretation_completed_at=:interpretation_completed_at, interpretation_display_completed_at = :interpretation_display_completed_at, interpreter_phone_number=:interpreter_phone_number, interpreter_details=:interpreter_details, interpretation_report_status=:interpretation_report_status`,
      ExpressionAttributeValues: {
        ':interpreter_details': interpreter_details,
        ':interpreter_phone_number': interpreter_details?.phoneNumber,
        ':updatedObject': newInterpretationData,
        ':interpretation_completed_at': dayjs().valueOf().toString(),
        ':interpretation_display_completed_at': dayjs().format(),
        ':interpretation_report_status': newInterpretationData?.report_status,
        ':status': "completed",
        ':interpretation_data_logs': previousInterpretationData
      },
      ReturnValues: 'ALL_NEW'
    }
    
    const { Attributes } = await dynamodb.update(updateParams).promise()

    await sendPushNotifications(Item?.phone_number,id,updateParams.ExpressionAttributeValues[':interpretation_completed_at'])

    const generatedPDF = await readECGLeadDataAndGenerateReportPDF("interpreted", Attributes)

    res.json({ status: 200, success: true, message: messages.saveInterpretationData.successfullyUpdated, data: { id: Attributes?.id, ReportPdf: Buffer.from(generatedPDF).toString("base64") } });
  }
  catch (err) {
    await errorLog(err, 'saveInterpretationData', 'ecgController.js')
    res.json({ status: 400, success: false, message: err?.message || messages.saveInterpretationData.failedToUpdate, data: err })
  }
}

const getSpecificReportData = async (req, res) => {

  if (!req.headers?.user) return res.json({ status: 403, success: false, message: messages.authentication.invalidAccessToken })

  try {
    const id = parseInt(req.params.report_id, 10);
    if (!id) {
      return res.json({ status: 400, success: false, message: messages.getSpecificReportData.idDoesNotExist })
    }

    const ecgReportData = await getEcgReportData(id);

    if (req.query?.noReport !== "Y" && ecgReportData?.paths) {
      const generatedPDF = await readECGLeadDataAndGenerateReportPDF(req.query?.reportType || (ecgReportData?.interpretation_request_status === "completed" ? "interpreted" : "system"), ecgReportData);
      delete ecgReportData?.paths;
      res.json({ status: 200, success: true, data: { ...ecgReportData, ReportPdf: Buffer.from(generatedPDF).toString("base64") } });
    } else {
      delete ecgReportData?.paths;
      res.json({ status: 200, success: true, message: messages.getSpecificReportData.accessingReportDataSuccess, data: ecgReportData });
    }
  } catch (error) {
    await errorLog(error, 'getSpecificReportData', 'ecgController.js')
    res.json({ status: 400, success: false, message: error?.message || messages.getSpecificReportData.accessingReportDataError, data: error })
  }
}

async function readECGLeadDataAndGenerateReportPDF(reportType, ecgReportData) {
  let allLeadsData = ECGData;
  try { allLeadsData = await readS3BucketLeadFiles(ecgReportData?.paths, ecgReportData?.report_type); } catch (e) {
    await errorLog(err, 'readECGLeadDataAndGenerateReportPDF', 'ecgController.js')
    console.log(e);
  }
  const generatedPDF = await generateInterpretatedPdf(reportType, ecgReportData, allLeadsData);
  return generatedPDF;
}

const reportsRequestForInterpretation = async (req, res) => {
  if (!req.headers?.user) return res.json({ status: 403, success: false, message: messages.authentication.invalidAccessToken })

  if (!req?.body?.ids || !(req?.body?.ids || []).length) {
    return res.json({ status: 400, success: false, message: messages.reportsRequestForInterpretation.idDoesNotExist })
  }

  if (req.headers?.user?.userType === 'user' && !req.headers?.user?.business_id && req?.body?.ids.length > 1) {
    return res.json({ status: 400, success: false, message: "Please request one report at a time." })
  }

  try {
    const updateResults = await setReportStatus(req.body?.ids, "requested", null, null, req.headers?.user, true);
    
    if (Array.isArray(updateResults)) sendToRoom('Expert', 'addReport', updateResults)

    res.json({ status: 200, success: true, message: "sucessfully updated", data: updateResults?.razorpay_public_key ? [{payment_data : updateResults}] : updateResults });
  }
  catch (err) {
    await errorLog(err, 'reportsRequestForInterpretation', 'ecgController.js')
    res.json({ status: 400, success: false, message: err?.message || messages.reportsRequestForInterpretation.updateFailed, data: err })
  }
}

const revokeInterpretationRequest = async (req, res) => {
  if (!req.headers?.user) return res.json({ status: 403, success: false, message: "Invalid access token." })

  if (!req?.body?.ids || !(req?.body?.ids || []).length) {
    return res.json({ status: 400, success: false, message: "id doesn't exist" })
  }
  try {
    const updateResults = await setReportStatus(req?.body?.ids, "requested", null, ["interpreter_details", "interpreter_phone_number"])

    res.json({ status: 200, success: true, message: "sucessfully updated", data: updateResults });
  } catch (err) {
    await errorLog(err, 'revokeInterpretationRequest', 'ecgController.js')
    res.json({ status: 400, success: false, message: err?.message || "failed to update the record", data: err })
  }
}

const   interpretation_request_order = async (auth, ids) => {
  const idsString = ids.join(',')
  delete auth?.profilePic;
  const orderPayload = {
    amount: process.env.SPANDAN_SERVICE_INTERPRETATION_CHARGE_PER_REQUEST * ids.length * 100,
    currency: 'INR',
    notes: { ...auth, idsString }
  }
  let order = await razorpay.orders.create(orderPayload)
  order = { ids, ...order, razorpay_public_key: process.env.RAZORPAY_KEY_ID }

  const tax_charge = (process.env.SPANDAN_SERVICE_INTERPRETATION_CHARGE_PER_REQUEST - (process.env.SPANDAN_SERVICE_INTERPRETATION_CHARGE_PER_REQUEST / (1 + (process.env.SPANDAN_SERVICE_INTERPRETATION_TAX_RATE / 100))));

  const putParams = {
    TableName: process.env.INTERPRETATION_REQUEST_ORDER_TABLE,
    Item: {
      reports: ids,
      meta_data: order.notes,
      payment_id: null,
      order_status: order.status,
      currency: order.currency,
      entity: order.entity,
      id: order.id,
      charges: process.env.SPANDAN_SERVICE_INTERPRETATION_CHARGE_PER_REQUEST,
      tax_charge,
      tax: process.env.SPANDAN_SERVICE_INTERPRETATION_TAX_RATE,
      timestamp: Date.now().toString(),
      amount: order.amount,
      phone_number: order.notes.phoneNumber,
      created_at: order.created_at * 1000,
      created_at_formatted: dayjs(order.created_at * 1000).format('MMMM DD, YYYY, HH:mm:ss')
    }
  }
  await dynamodb.put(putParams).promise()
  return order
}

const getPlans = async (identifier) => {
  const params = { 
        TableName: process.env.SUBSCRIPTION_PLAN_TABLE_NAME,
        FilterExpression:'identifier=:identifier',
        ExpressionAttributeValues: {
          ':identifier': identifier,
        }
      }
  const {Items} = await dynamodb.scan(params).promise()
  return Items[0]
}

const setReportStatus = async (ids, status, otherSetFields, removeFields, auth, isNewRequest) => {
  
  if (auth?.userType === "user" && !auth?.business_id && isNewRequest && !auth?.is_paid) {
    
    // const requested = await get_requested_today_count_data({}, auth)
    // const completed = await get_completed_today_count_data({}, auth)

    // if ((requested?.data?.todayRequested + completed?.data?.completedCount) >= process.env.SPANDAN_SERVICE_INTERPRETATION_FREE_REQUEST_LIMIT) {
    //   //make order
    //   return await interpretation_request_order(auth, ids)
    // }

    const usersRef = admin.firestore().collection(process.env.SPANDAN_SERVICE_FIREBASE_USER_TABLE_NAME)
    let userRef = await usersRef.where('phoneNumber', '==', auth?.phoneNumber).get()
    const userData = userRef.docs[0].data()
    userRef = userRef.docs[0].ref

    //get current user subscription
    const params = {
      TableName: process.env.SUBSCRIPTION_TABLE_NAME,
      IndexName: 'phone_number-created_at-index',
      ProjectionExpression: 'expiry_date, subscription_type, subscription_status, identifier',
      KeyConditionExpression: 'phone_number = :phone_number',
      FilterExpression: 'subscription_status IN (:status1, :status2)',
      ExpressionAttributeValues: {
        ':phone_number': auth.phoneNumber,
        ':status1': 'active',
        ':status2': 'cancel'
      },
      ScanIndexForward: false
    }

    const { Items } = await dynamodb.query(params).promise()

    // is there a subscription ? if there is then check if expired or not or if cancelled 
    if(Items.length > 0 && Items[0]?.expiry_date > Date.now() && Items[0]?.subscription_status !== 'cancel'){
      
      //subscription exists and is not expired or cancelled
      const planData = await getPlans(Items[0].identifier)

      if(planData.identifier === "SPN_PREMIUM"){

        if(userData.subscriptionRequestCount){
          //count exists
          //get plan and check remaining count
          if(userData.subscriptionRequestCount >= planData.free_interpretation_requests){

            const planData = await getPlans("SPN_BASIC")

            if(userData.defaultRequestCount >= planData.free_interpretation_requests){
              // make an order
              return await interpretation_request_order(auth, ids)
            }
            else{
                await userRef.update({defaultRequestCount: userData.defaultRequestCount ? userData.defaultRequestCount + 1 : 1})
            }
          }
          else{
            await userRef.update({
              subscriptionRequestCount: userData.subscriptionRequestCount + 1
            })
          }

        }
        else{
          //count does not exists
          //get plan and check remaining count
         
          await userRef.update({
            subscriptionRequestCount: 1
          })

        }

      }
    }
    else{

      //subscription does not exists
      if(userData.defaultRequestCount){
        //Default count exists
        const planData = await getPlans("SPN_BASIC")
        if(userData.defaultRequestCount >= planData.free_interpretation_requests){
          // make an order
          return await interpretation_request_order(auth, ids)
        }
        else{
          await userRef.update({
            defaultRequestCount: userData.defaultRequestCount + 1
          })
        }

      }
      else{
        //setting count
        await userRef.update({
          defaultRequestCount: 1
        })
      }

    }
    
  }
  //let it pass
  const queries = ids.map((id) => {
    let query = {
      TableName: process.env.ECG_RECORD_DATA_TABLE,
      Key: { 'id': Number(id) },
      UpdateExpression: 'SET interpretation_request_status = :interpretation_request_status',
      ExpressionAttributeValues: {
        ':interpretation_request_status': status
      },
      ReturnValues: 'ALL_NEW'
    };
    if (isNewRequest) {
      query.UpdateExpression += ', interpretation_data = :interpretation_data, interpretation_requested_at = :interpretation_requested_at, interpretation_display_requested_at = :interpretation_display_requested_at';
      query.ExpressionAttributeValues = {
        ...query.ExpressionAttributeValues,  // Preserve existing values
        ':interpretation_requested_at': dayjs().valueOf().toString(),
        ':interpretation_display_requested_at': dayjs().format(),
        ':interpretation_data': {
          requested_at: dayjs().valueOf(),
          display_requested_at: dayjs().format(),
        }
      };
      if (auth?.business_id) {
        query.UpdateExpression += ', business_id = :business_id';
        query.ExpressionAttributeValues = {
          ...query.ExpressionAttributeValues,  // Preserve existing values
          ':business_id': auth?.business_id
        }
      }
    }
    if (auth?.userType === 'expert' || auth?.userType === 'admin') {
      query.UpdateExpression += ',interpreter_details = :interpreter_details, interpreter_phone_number = :interpreter_phone_number';
      query.ExpressionAttributeValues = {
        ...query.ExpressionAttributeValues,  // Preserve existing values
        ':interpreter_details': auth,
        ':interpreter_phone_number': auth?.phoneNumber
      };
    }
    if (otherSetFields && Object.keys(otherSetFields)?.length) {
      for (const field in otherSetFields) {
        query.UpdateExpression += `,${field} = :${field}`;
        query.ExpressionAttributeValues = {
          ...query.ExpressionAttributeValues,  // Preserve existing values
          [`:${field}`]: otherSetFields[field]
        };
      }
    }
    if (removeFields && removeFields?.length) {
      query.UpdateExpression += ' REMOVE '
      removeFields.forEach((field, index) => {
        query.UpdateExpression += `${field}`;
        if (index !== removeFields.length - 1) query.UpdateExpression += `, `;
      })
    }
    return query;
  });
  const updateResults = [];
  for (const query of queries) {
    const queryResult = await dynamodb.update(query).promise();
    const projections = {
      id: queryResult?.Attributes?.id,
      report_type: queryResult?.Attributes?.report_type,
      report_timestamp: queryResult?.Attributes?.report_timestamp,
      user_data: queryResult?.Attributes?.user_data,
      interpretation_request_status: queryResult?.Attributes?.interpretation_request_status,
      interpretation_requested_at: queryResult?.Attributes?.interpretation_requested_at,
      interpretation_data: queryResult?.Attributes?.interpretation_data,
      interpreter_details: queryResult?.Attributes?.interpreter_details
    };
    updateResults.push(projections);
  }
  return updateResults;
}

const getSpecificInvoiceData = async (req, res) => {
  const now = dayjs();

  let { phone_number, startDate, endDate } = req.query;
  const endDateTime = endDate ? dayjs(endDate, "DD MMM, YYYY").endOf('day').valueOf().toString() : now.endOf('day').valueOf().toString()
  const startDateTime = startDate ? dayjs(startDate, "DD MMM, YYYY").startOf('day').valueOf().toString() : now.startOf('day').valueOf().toString()
  const params = {
    TableName: process.env.ECG_RECORD_DATA_TABLE,
    FilterExpression: "phone_number = :phone_number",
    ExpressionAttributeValues: {
      ':phone_number': phone_number,
    }
  };
  let totalTest = 0;
  let completed = 0;
  try {
    const data = await dynamodb.scan(params).promise();
    data.Items.forEach((item) => {
      totalTest++;
      if (item.interpretation_request_status === "completed") {
        completed++;
      }
    });

    const invoiceData = {
      totalTest,
      completed
    };
    res.json({ status: 200, success: true, message: "successfully retrieved", data: invoiceData });
  } catch (err) {
    await errorLog(err, 'getSpecificInvoiceData', 'ecgController.js')
    res.json({ status: 400, success: false, message: err?.message, data: err });
  }
}

module.exports = { getList, saveInterpretationData, getSpecificReportData, reportsRequestForInterpretation, revokeInterpretationRequest, setReportStatus, getSpecificInvoiceData };
