// const pdfMake = require('pdfmake');
const AWS = require("../config/aws");
const dayjs = require('dayjs');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const admin = require("../config/firebase");
const { errorLog } = require('./errorLogs')
const { getUserFromFirebase, getUserFromDynamo } = require("./authController")
const { generateApiKey, generateVerifierKey } = require("../utils/Utils")


const getB2Busers = async (req, res) => {
    try {
        const scanParams = {
            TableName: process.env.INTERNAL_USERS_TABLE,
            FilterExpression: req.headers.user?.getB2bAdminUsers
                ? "(user_type = :user_type AND associated_business_id=:associated_business_id) AND (#s <> :status) AND (attribute_exists(phone_number))"
                : "(user_type = :user_type) AND (#s <> :status) AND (attribute_exists(phone_number))",
            ExpressionAttributeValues: {
                ":user_type": req.headers.user?.getB2bAdminUsers ? "b2b-user" : "b2b",
                ":status": "deleted",
                ...(req.headers.user?.getB2bAdminUsers && { ":associated_business_id": req.headers.user.business_id })
            },
            ExpressionAttributeNames: {
                "#s": "status",
            },
        };
        if (req.headers.user?.userType === 'b2b') {
            scanParams["ExpressionAttributeNames"] = { ...scanParams?.ExpressionAttributeNames, "#n": "name" }
            scanParams["ProjectionExpression"] = "api_key, #n, business_name, phone_number, email, company_data, test_charges, interpretation_charges, user_type, created_at, updated_at"
        }

        const { Items } = await dynamoDB.scan(scanParams).promise();
        return res.json({ status: 200, success: true, data: Items });
    } catch (error) {
        await errorLog(error, 'getB2Busers', 'userController.js')
        return res.json({ status: 500, success: false, data: error, message: error?.message });
    }
};

async function updateBusinessIds(phone_numbers, business_id) {
    const db = admin.firestore();
    const users = db.collection(
        process.env.SPANDAN_SERVICE_FIREBASE_USER_TABLE_NAME || "user"
    );

    const updatedPhoneNumbers = [];

    const updatePromises = phone_numbers?.map(async (phone_number) => {
        const user = await users
            .where("phoneNumber", "==", phone_number)
            .where("masterUser", "==", true)
            .limit(1)
            .get();

        if (!user.empty) {
            const userRef = user.docs[0].ref;

            try {
                await userRef.update({ business_id });
                updatedPhoneNumbers.push(phone_number);
            } catch (error) {
                console.error("Error adding business id:", error);
            }
        } else {
            console.log(`No user found with phone number: ${phone_number}`);
        }
    });

    if (updatePromises?.length) await Promise.all(updatePromises);
    return updatedPhoneNumbers;
}

const saveB2BProfile = async (req, res) => {
    const auth = req.headers?.user;
    const {
        phone_number,
        name,
        email,
        business_name,
        gst_number,
        billing_address,
        state,
        interpretation_charges,
        status,
        pin,
        code,
        updated_devices_enabled,
        updated_tests_enabled,
        is_offline_sdk_mode,
        is_active,
        test_charges,
        usage_limit
    } = req.body;
    if (auth?.userType === "b2b") {
        try {
            //search in dynamo if business already exists for phone_number
            const { Items } = await getUserFromDynamo(phone_number, auth?.business_id);
            let updatedData;
            if (Items && Items.length > 0) {
                const updateParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key: Items[0].api_key },
                    UpdateExpression:
                        "SET company_data = :company_data, business_name = :business_name, #n = :name, email = :email, updated_at = :updated_at",
                    ExpressionAttributeValues: {
                        ":company_data": {
                            business_name,
                            gst_number,
                            billing_address,
                            state,
                            pin,
                            code
                        },
                        ":business_name": business_name,
                        ":email": email,
                        ":name": name,
                        ":updated_at": dayjs().format(),
                    },
                    ExpressionAttributeNames: {
                        "#n": "name",
                    },
                    ReturnValues: 'ALL_NEW'
                };

                const { Attributes } = await dynamoDB.update(updateParams).promise();
                updatedData = {
                    name: Attributes?.name,
                    email: Attributes?.email,
                    company_data: Attributes?.company_data
                }
            }
            return res.json({
                status: 200,
                success: true,
                message: "Successfully updated",
                data: updatedData
            });
        } catch (error) {
            await errorLog(error, 'saveB2BProfile', 'userController.js')
            return res.json({ status: 500, success: false, message: error?.message });
        }
    } else if (auth?.userType === "admin" || auth?.userType === "superuser") {
        try {
            //search in dynamo if business already exists for phone_number
            const { Items } = await getUserFromDynamo(phone_number);

            if (Items && Items.length > 0) {
                let updateParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key: Items[0].api_key },
                };
                if (status && status === "deleted") {
                    if (Items?.associated_users?.length) await updateBusinessIds(Items.associated_users || [], null);
                    updateParams = {
                        ...updateParams,
                        UpdateExpression: "SET updated_at = :updated_at, #s=:status",
                        ExpressionAttributeValues: {
                            ":updated_at": dayjs().format(),
                            ":status": status,
                        },
                        ExpressionAttributeNames: { "#s": "status" },
                    };
                    await dynamoDB.update(updateParams).promise();
                } else {
                    updateParams = {
                        ...updateParams,
                        UpdateExpression:
                            "SET is_active=:is_active,usage_limit=:usage_limit,is_offline_sdk_mode=:is_offline_sdk_mode,#n=:name,user_type = :user_type,devices_enabled=:updated_devices_enabled, tests_enabled=:updated_tests_enabled, business_name = :business_name, email = :email, company_data = :company_data, interpretation_charges = :interpretation_charges, test_charges = :test_charges, updated_at = :updated_at, #s=:status",
                        ExpressionAttributeValues: {
                            ":company_data": {
                                business_name,
                                gst_number,
                                billing_address,
                                state,
                                pin,
                                code
                            },
                            ":user_type": "b2b",
                            ":name": name,
                            ":business_name": business_name,
                            ":email": email,
                            ":interpretation_charges": interpretation_charges || '',
                            ":test_charges": test_charges || '',
                            ":updated_at": dayjs().format(),
                            ":status": 'active',
                            ":updated_devices_enabled": updated_devices_enabled,
                            ":updated_tests_enabled": updated_tests_enabled,
                            ":is_offline_sdk_mode": Boolean(is_offline_sdk_mode || false),
                            ":is_active": Boolean(is_active || false),
                            ":usage_limit": usage_limit || ''
                        },
                        ExpressionAttributeNames: { "#n": "name", "#s": "status" },
                    };
                    await dynamoDB.update(updateParams).promise();
                }
            } else {
                const api_key = generateApiKey();
                const verifier_token =generateVerifierKey(api_key);
                
                const params = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Item: {
                        creation_timestamp: Date.now(),
                        created_at: dayjs().format(),
                        updated_at: dayjs().format(),
                        name,
                        phone_number,
                        api_key,
                        business_name,
                        email,
                        company_data: { business_name, gst_number, billing_address, state, pin, code },
                        interpretation_charges: interpretation_charges,
                        user_type: "b2b",
                        status: "active",
                        verifier_token,
                        updated_devices_enabled,
                        updated_tests_enabled,
                        is_offline_sdk_mode,
                        is_active,
                        test_charges,
                        usage_limit
                    },
                };

                await dynamoDB.put(params).promise();
            }

            return res.json({
                status: 200,
                success: true,
                message: "Successfully updated",
            });
        } catch (error) {
            await errorLog(error, 'saveB2BProfile', 'userController.js')
            return res.json({ status: 500, success: false, message: error.message });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission.",
        });
    }
};

const addB2BAdminOrAssociatedUsers = async (req, res) => {
    
    const auth = req.headers?.user;
    
    if (auth?.userType === "b2b") {
        
        const { phone_numbers, name, email, isb2bUser } = req. body
        const response = { status: 200, success: false, message: "" }
        
        try {

            if(isb2bUser){
                
                //check if user exists in internal users table
                const existedUser = await getUserFromDynamo(phone_numbers[0]);
                
                if (existedUser?.Items && existedUser?.Items.length > 0) {

                    //user exists but is not in deleted state
                    if (existedUser?.Items[0]?.status !== 'deleted') {
                        response.message = `User is already exists as ${existedUser?.Items[0]?.user_type}.`
                    }
                    else{

                        await updateBusinessIds([phone_numbers[0]], null);
                        
                        //update user
                        const updateParams = {
                            TableName: process.env.INTERNAL_USERS_TABLE,
                            Key: { api_key: existedUser.Items[0].api_key },
                            UpdateExpression: "SET #s=:status,#n=:name, email=:email, user_type=:user_type,associated_business_id=:associated_business_id, updated_at = :updated_at",
                            ExpressionAttributeValues: {
                                ":email":email,
                                ":user_type": "b2b-user",
                                ":status": 'active',
                                ":associated_business_id": auth?.business_id,
                                ":name" : name,
                                ":updated_at": dayjs().format(),
                            },
                            ExpressionAttributeNames: {"#s": "status","#n":"name" },
                        };

                        await dynamoDB.update(updateParams).promise();
                        response.success = true
                        response.message = "Successfully added"
                    }
                } 
                else {
                
                    //remove from firebase if present
                    await updateBusinessIds([phone_numbers[0]], null);

                    //add b2b-user
                    const params = {
                        TableName: process.env.INTERNAL_USERS_TABLE,
                        Item: {
                            api_key: generateApiKey(),
                            user_type : 'b2b-user',
                            status: 'active',
                            phone_number: phone_numbers[0],
                            associated_business_id : auth?.business_id,
                            name,
                            email,
                            creation_timestamp : Date.now(),
                            created_at: dayjs().format(),
                            updated_at: dayjs().format(),
                        },
                    }
                    await dynamoDB.put(params).promise()
                    response.success = true
                    response.message = "Successfully added"
                }
            }
            else if (phone_numbers && phone_numbers.length !== 0) {
                if (!phone_numbers[0] || phone_numbers[0]?.length < 10) {
                    response.message = "Please enter the valid phone number."
                }
                else{

                    const existedUser = await getUserFromDynamo(phone_numbers[0])
                    const user = await getUserFromFirebase(phone_numbers[0])

                    if (existedUser?.Items && existedUser?.Items.length > 0 && existedUser?.Items[0]?.status !== 'deleted') {
                        response.message = `User is already exists as ${existedUser?.Items[0]?.user_type}.`
                    }
                    else if(!user){
                        response.message = "User does not exist. Please try with different phone number."
                    }
                    else{
                        const { Items } = await getUserFromDynamo(auth?.phoneNumber,auth?.business_id);
                        const { associated_users, api_key } = Items[0];
                        const newBusinesId = api_key;
        
                        let filteredPhoneNumbers;
                        let updated_associated_users = [];
        
                        if (associated_users && associated_users.length !== 0) {
                            filteredPhoneNumbers = phone_numbers.filter(
                                (phone) => !associated_users.includes(phone)
                            );
        
                            updated_associated_users = [...associated_users];
                        } else {
                            filteredPhoneNumbers = phone_numbers;
                        }
        
                        successfullyUpdatedPhoneNumbers = await updateBusinessIds(
                            filteredPhoneNumbers,
                            newBusinesId
                        );
        
                        if (successfullyUpdatedPhoneNumbers.length > 0) {
                            updated_associated_users = [
                                ...updated_associated_users,
                                ...successfullyUpdatedPhoneNumbers,
                            ];
                        }
        
                        const updateParams = {
                            TableName: process.env.INTERNAL_USERS_TABLE,
                            Key: { api_key },
                            UpdateExpression: "SET associated_users = :associated_users, updated_at = :updated_at",
                            ExpressionAttributeValues: {
                                ":associated_users": updated_associated_users,
                                ":updated_at": dayjs().format(),
                            },
                        };
        
                        await dynamoDB.update(updateParams).promise();
                        response.success = true
                        response.message = "Successfully added"
                    }
                }
            }
            
            return res.json(response)

        } catch (error) {
            await errorLog(error, 'addB2BAdminOrAssociatedUsers', 'userController.js')
            return res.json({ status: 500, success: false, message: error?.message });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission.",
        });
    }
};

const removeB2BAdminOrAssociatedUsers = async (req, res) => {
    
    const auth = req.headers?.user
    
    if (auth?.userType === "b2b") {
        
        const { phone_numbers, removeB2BAdminUser } = req.body

        let updateParams = {}

        try {
            if(removeB2BAdminUser){
                //get user with the phone number
                const { Items } = await getUserFromDynamo(phone_numbers[0])

                updateParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key: Items[0].api_key },
                    UpdateExpression: "SET #s=:status,associated_business_id=:associated_business_id, updated_at = :updated_at",
                    ExpressionAttributeValues: {
                        ":status": 'deleted',
                        ":associated_business_id": "",
                        ":updated_at": dayjs().format(),
                    },
                    ExpressionAttributeNames: {"#s": "status"},
                }

            }
            else{
                //if not b2b-admin then remove business-id from firebase

                await updateBusinessIds(phone_numbers, null);
                const { Items } = await getUserFromDynamo(auth?.phoneNumber,auth?.business_id);
                const { associated_users } = Items[0];
    
                const updated_associated_users = associated_users.filter(
                    (phone) => !phone_numbers.includes(phone)
                );
    
                updateParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key : auth?.business_id },
                    UpdateExpression: "SET associated_users = :associated_users, updated_at = :updated_at",
                    ExpressionAttributeValues: { 
                        ":associated_users": updated_associated_users,
                        ":updated_at": dayjs().format(),
                    },
                };
            }

            await dynamoDB.update(updateParams).promise();

            return res.json({
                status: 200,
                success: true,
                message: "Successfully updated",
            })

        } catch (err) {
            await errorLog(err, 'removeB2BAdminOrAssociatedUsers', 'userController.js')
            return res.json({ status: 500, success: false, message: err });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission",
        });
    }
};

const getAssociatedUserDataFromFirebase = async (req, res) => {
    const auth = req.headers?.user;
    if (auth?.userType === "b2b") {
        try {
            const { Items } = await getUserFromDynamo(auth?.phoneNumber);
            const { api_key } = Items[0];
            if (api_key) {
                const db = admin.firestore();
                const users = db.collection(
                    process.env.SPANDAN_SERVICE_FIREBASE_USER_TABLE_NAME || "user"
                );

                const result = await users.where("business_id", "==", api_key).get();

                const userData = result.docs.map((doc) => {
                    const { phoneNumber, firstName, lastName, email } = doc.data();
                    return { phone_number: phoneNumber, name: `${firstName} ${lastName}`, email };
                });

                res.json({ status: 200, success: true, data: userData });
            } else {
                res.json({ status: 200, success: true, data: [] });
            }
        } catch (err) {
            await errorLog(err, 'getAssociatedUserDataFromFirebase', 'userController.js')
            return res.json({ status: 500, success: false, message: err.message });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission",
        });
    }
};

const getInternalUsers = async (req, res) => {
    const auth = req.headers?.user;
    if (auth?.userType === "admin" || auth?.userType === "superuser") {
        try {
            const getParams = {
                TableName: process.env.INTERNAL_USERS_TABLE,
                FilterExpression: "(user_type = :admin_type OR user_type = :expert_type) AND #s <> :status",
                ExpressionAttributeValues: {
                    ":admin_type": "admin",
                    ":expert_type": "expert",
                    ":status": "deleted",
                },
                ExpressionAttributeNames: {
                    "#s": "status",
                },

            };

            const { Items } = await dynamoDB.scan(getParams).promise();
            return res.json({ status: 200, success: true, data: Items });
        } catch (error) {
            await errorLog(error, 'getInternalUsers', 'userController.js')
            return res.json({ status: 500, success: false, message: error });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission",
        });
    }
};

const updateUserProfile = async (req, res) => {
    const auth = req.headers?.user;
    if (auth?.userType === "expert" || auth?.userType === "admin" || auth?.userType === "superuser") {
        const { user_type, name, email } = req.body;
        try {
            const { Items } = await getUserFromDynamo(auth?.phoneNumber);
            if (Items && Items.length > 0) {
                const updateParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key: auth?.business_id },
                    UpdateExpression: "SET #n=:name, email=:email, updated_at = :updated_at",
                    ExpressionAttributeValues: {
                        ":name": name,
                        ":email": email,
                        ":updated_at": dayjs().format(),
                    },
                    ExpressionAttributeNames: { "#n": "name" },
                };
                if (user_type) {
                    updateParams.UpdateExpression += ", user_type = :user_type"
                    updateParams.ExpressionAttributeValues = { ...updateParams?.ExpressionAttributeValues, ":user_type": user_type }
                }
                await dynamoDB.update(updateParams).promise();
                return res.json({ status: 200, success: true, message: 'Profile updated successfully.' });
            } else {
                return res.json({ status: 200, success: true, message: "User doen't exists." });
            }
        } catch (error) {
            console.log(error);
            await errorLog(error, 'updateUserProfile', 'userController.js')
            return res.json({ status: 500, success: false, message: error });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission",
        });
    }
};

const saveUsers = async (req, res) => {
    const auth = req.headers?.user;
    if (auth?.userType === "admin" || auth?.userType === "superuser") {
        const { user_type, phone_number, name, email } = req.body;
        let message;
        try {
            await updateBusinessIds([phone_number], null);
            const { Items } = await getUserFromDynamo(phone_number);
            if (Items && Items.length > 0) {
                const updateParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key: Items[0].api_key },
                    UpdateExpression: "SET #n=:name, email=:email,#s=:status, updated_at = :updated_at",
                    ExpressionAttributeValues: {
                        ":name": !!name ? name : Items[0].name,
                        ":email": email || Items[0].email,
                        ":status": 'active',
                        ":updated_at": dayjs().format(),
                    },
                    ExpressionAttributeNames: { "#n": "name", "#s": "status" },
                };
                if (user_type) {
                    updateParams.UpdateExpression += ", user_type = :user_type"
                    updateParams.ExpressionAttributeValues = { ...updateParams?.ExpressionAttributeValues, ":user_type": user_type }
                }
                await dynamoDB.update(updateParams).promise();
                message = "Successfully updated";
            } else {
                const params = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Item: {
                        api_key: generateApiKey(),
                        name,
                        email,
                        user_type,
                        status: 'active',
                        phone_number,
                        creation_timestamp: Date.now(),
                        created_at: dayjs().format(),
                        updated_at: dayjs().format(),
                    },
                };
                await dynamoDB.put(params).promise();
                message = "Successfully added";
            }
            return res.json({ status: 200, success: true, message });
        } catch (error) {
            await errorLog(error, 'saveUsers', 'userController.js')
            return res.json({ status: 500, success: false, message: error });
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission",
        });
    }
};

const removeInternalUsers = async (req, res) => {
    const auth = req.headers?.user;
    if (auth?.userType === "admin" || auth?.userType === "superuser") {

        const { phone_number } = req.body;
        const { Items } = await getUserFromDynamo(phone_number);

        if (Items && Items.length > 0) {

            try {
                const deleteParams = {
                    TableName: process.env.INTERNAL_USERS_TABLE,
                    Key: { api_key: Items[0].api_key },
                    UpdateExpression: "SET #s=:status, updated_at = :updated_at",
                    ExpressionAttributeValues: {
                        ":status": 'deleted',
                        ":updated_at": dayjs().format(),
                    },
                    ExpressionAttributeNames: { "#s": "status" },
                    ConditionExpression: "attribute_exists(phone_number)",
                };

                await dynamoDB.update(deleteParams).promise();

            } catch (error) {
                await errorLog(error, 'removeInternalUsers', 'userController.js')
                return res.json({ status: 500, success: false, message: error });
            }

            return res.json({
                status: 200,
                success: true,
                message: "Deleted successfully.",
            })
        }
    } else {
        return res.json({
            status: 403,
            success: false,
            message: "You don't have enough permission",
        });
    }
};

const setSocket = async (phoneNumber, socketId) => {
    if (!phoneNumber || !socketId) return false;
    try {
        const { Items } = await getUserFromDynamo(phoneNumber);
        if (Items?.length) {

            const updateParams = {
                TableName: process.env.INTERNAL_USERS_TABLE,
                Key: { api_key: Items[0].api_key },
                UpdateExpression: `SET socket_id = :socket_id, updated_at = :updated_at`,
                ExpressionAttributeValues: {
                    ":socket_id": socketId,
                    ":updated_at": dayjs().format(),
                },
                ConditionExpression: "attribute_exists(phone_number)",
            };

            await dynamoDB.update(updateParams).promise();
        }
    } catch (err) {
        await errorLog(err, 'setSocket', 'userController.js')
        console.log("Error while setting socket id :: ", err);
    }
};

module.exports = {
    getB2Busers,
    saveB2BProfile,
    setSocket,
    getAssociatedUserDataFromFirebase,
    addB2BAdminOrAssociatedUsers,
    removeB2BAdminOrAssociatedUsers,
    getInternalUsers,
    updateUserProfile,
    saveUsers,
    removeInternalUsers,
};
