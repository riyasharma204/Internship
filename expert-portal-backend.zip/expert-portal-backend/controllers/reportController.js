const fs = require("fs")
const { createSVGWindow } = require("svgdom");
const { SVG, registerWindow } = require("@svgdotjs/svg.js");
const hexRgb = require('hex-rgb');
const PdfPrinter = require("pdfmake");
const { notes } = require('../client-config')
const AWS = require('../config/aws');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const {errorLog} = require('./errorLogs');

var fonts = {
  Roboto: {
    normal: "assets/fonts/Roboto-Regular.ttf",
    bold: "assets/fonts/Roboto-Medium.ttf",
    italics: "assets/fonts/Roboto-Italic.ttf",
    bolditalics: "assets/fonts/Roboto-MediumItalic.ttf",
  },
};

var pdfMake = new PdfPrinter(fonts);

async function generateInterpretatedPdf(reportType, reportData, leadsData, ) {
  try {
    const headerImage = Buffer.from(fs.readFileSync("assets/report-header.png"));
    const footerImage = Buffer.from(fs.readFileSync("assets/report-footer.png"));
    const width = 595
    const height = 842

    const docDefinition = {
      pageSize: { width: width || 595, height: height || 842 }, // or page size name
      pageMargins: [0, 80, 0, 100], // [left, top, right, bottom] or [horizontal, vertical] or just a number for equal margins
      header: {
        image: headerImage,
        height: 80,
        width: width,
      },
      footer: function (currentPage, pageCount) {
        const chartScaleAndVersionInfo = {
          // width: ["*", '*', "auto"],
          margin: [20, 0],
          columns: [
            (currentPage === pageCount ? {
              width: 250,
              text: [{ text: "Scale: x-axis: ", bold: true }, { text: "25 mm/sec \t" }, { text: "y-axis: ", bold: true }, { text: "10 mm/mV" }],
              alignment: "left",
              fontSize: 10,
            } : {}),
            (currentPage === pageCount ? {
              width: 200,
              text: [{ text: "App version: ", bold: true }, "4.0.0-beta5"],
              alignment: "center",
              fontSize: 10,
            } : {}),
            {
              width: 100,
              text: `Page: ${currentPage} of ${pageCount}`,
              alignment: "right",
              fontSize: 11,
              bold: true,
            },
          ]
        };
        return [
          chartScaleAndVersionInfo,
          {
            image: footerImage,
            height: 85,
            width: width,
          },
        ];
      },
      styles: {
        heading: {
          bold: true,
          fontSize: 16,
          lineHeight: 1.8,
        },
        interpretationParams: {
          lineHeight: 2,
          fontSize: 10,
          color: "#514f4f",
        },
        findingsHeading: {
          fontSize: 12,
          color: "#514f4f",
          bold: true,
          margin: [50, 10, 50, 0]
        },
        section: {
          lineHeight: 1.5,
          fontSize: 10,
          color: "#504e4e",
          // fillColor: "#f5f7f7"
        },
        pageMargin: {
          margin: [100, 0, 100, 0],
        },
        tableExample: {
          fontSize: 10,
          bold: true,
          margin: [50, 5, 50, 15],
        },
        tableHeader: {
          bold: true,
          fontSize: 14,
          color: "black",
          margin: [0, 5],
        },
        tableTextCell: {
          fontSize: 10,
          margin: [0, 5],
          alignment: "center",
          bold: true,
        },
        tableValueCell: {
          fontSize: 10,
          margin: [0, 5],
          alignment: "center",
          bold: true,
        },
      },
      defaulStyle: {
        fontSize: 10,
        lineHeight: 1,
      }
    };

    const ecgChartContent = await ecgReportChartPage(leadsData, { width: (width - 40), height });
    if (reportType === "interpreted") docDefinition.content = [setPatientReportInfo(reportData), ...setInterpretationReport(reportData), setECGParameters(reportData), ...setFindings(reportData), setNote(), await setSignature(reportData), ...ecgChartContent];
    else docDefinition.content = [...ecgChartContent];
    const pdfDoc = pdfMake.createPdfKitDocument(docDefinition);
    var chunks = [];
    var result;
    return new Promise((resolve) => {
      pdfDoc.on("data", function (chunk) {
        chunks.push(chunk);
      });
      pdfDoc.on("end", function () {
        result = Buffer.concat(chunks);
        // const base64 = Buffer.from(result).toString("base64");

        resolve(result);
      });
      pdfDoc.end();

    });
  } catch (err) {
    await errorLog(err,'generateInterpretatedPdf','reportController.js')
    console.log("there is error ", err)
    
    return err
  }

};

function setPatientReportInfo(reportData) {
  return {
    style: "section",
    table: {
      widths: ["8%", "10%", "1%", "*", "auto", "1%", "auto", "8%"],
      body: [
        [
          {
            colSpan: 8,
            text: " ",
            lineHeight: 1,
          }, {}, {}, {}, {}, {}, {}, {}
        ],
        [
          {
            text: " ",

          },
          {
            text: "Name",
            bold: true,
          },
          {
            text: ":",
            bold: true,
          },
          {
            text: `${reportData?.interpretation_data?.first_name || reportData?.user_data?.first_name} ${reportData?.interpretation_data?.last_name || reportData?.user_data?.last_name}`.substring(0, 25) || "-",
            lineHeight: 1,
            bold: true,
            fontSize: 12
          },
          {
            text: "Date of Receiving ECG",
            bold: true,
          },
          {
            text: ":",
            bold: true,
          },
          {
            text: reportData?.interpretation_data?.date_of_receiving_ecg || "-",
            bold: true,
            fontSize: 12
          },
          {
            text: " ",
          },
        ],
        [
          {
            text: " ",
          },
          {
            text: "Age",
            bold: true,
          },
          {
            text: ":",
            bold: true,
          },
          {
            text: (reportData?.interpretation_data?.age || (reportData?.user_data?.age || "-")),
            bold: true,
            fontSize: 12
          },
          {
            text: "Time of Receiving ECG",
            bold: true,
          },
          {
            text: ":",
            bold: true,
          },
          {
            text: reportData?.interpretation_data?.time_of_receiving_ecg || "-",
            alignment: "left",
            bold: true,
            fontSize: 12
          },
          {
            text: " "
          },
        ],
        [
          {
            text: " ",
            lineHeight: 1,
          },
          {
            text: "Gender",
            bold: true,
            lineHeight: 1,
          },
          {
            text: ":",
            bold: true,
            lineHeight: 1,
          },
          {
            text: (reportData?.interpretation_data?.gender || (reportData?.user_data?.gender || "-")),
            lineHeight: 1,
            bold: true,
            fontSize: 12
          },
          {
            text: "Time of ECG Interpretation",
            bold: true,
            lineHeight: 1,
          },
          {
            text: ":",
            bold: true,
            lineHeight: 1,
          },
          {
            text: reportData?.interpretation_data?.time_of_ecg_interpretation || "-",
            lineHeight: 1,
            bold: true,
            fontSize: 12
          },
          {
            text: " ",
            lineHeight: 1,
          },
        ],
        [
          {
            colSpan: 8,
            text: " ",
            lineHeight: 1,
          },
        ],
      ],
    },
    layout: "noBorders",
  };
};

function setInterpretationReport(reportData) {
  return [
    {
      margin: [50, 20, 50, 0],
      text: "Interpretation Report",
      style: "heading",
    },
    {
      margin: [50, 0],
      style: "interpretationParams",
      table: {
        widths: ["75%", "5%", "*"],
        body: [
          [
            {
              ul: [
                {
                  text: "Were there any symptoms?",
                  bold: true,
                },
              ],
            },
            {
              text: "-",
              bold: true,
            },
            {
              text: reportData?.interpretation_data?.any_symptom || " NA ",
              color: "black",
              bold: true,
            },
          ],
          [
            {
              ul: [
                {
                  text: "Interpretation and the Nature of ECG Traces?",
                  bold: true,
                },
              ],
            },
            {
              text: "-",
              bold: true,
            },
            {
              text: reportData?.interpretation_data?.nature_of_ecg || " NA ",
              color: "black",
              bold: true,
            },
          ],
          [
            {
              ul: [
                {
                  text: "Interpretation for Classification of Abnormality?",
                  bold: true,
                },
              ],
            },
            {
              text: "-",
              bold: true,
            },
            {
              text: reportData?.interpretation_data?.classification_of_abnormality || " NA ",
              color: "black",
              bold: true,
            },
          ],
        ],
      },
      layout: "noBorders",
    },
  ];
};

function setECGParameters(reportData) {
  return {
    style: "tableExample",
    table: {
      widths: [120, 80, "*", 80, "*"],
      body: [
        [
          {
            rowSpan: 4,
            margin: [0, 40],
            text: [{ text: "MEASUREMENT" }, { text: "\n(ECG Parameter)" }],
            style: "tableTextCell",
          },
          {
            text: [{ text: "PR" }, { text: " (ms)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.pr_interval || "-", style: "tableValueCell" },
          {
            text: [{ text: "QT" }, { text: " (ms)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.qt_interval || "-", style: "tableValueCell" },
        ],
        [
          {},
          {
            text: [{ text: "ST" }, { text: " (ms)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.st_interval || "-", style: "tableValueCell" },
          {
            text: [{ text: "QTc" }, { text: " (ms)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.qtc || "-", style: "tableValueCell" },
        ],
        [
          {},
          {
            text: [{ text: "R-R" }, { text: " (ms)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.rr_interval || "-", style: "tableValueCell" },
          {
            text: [{ text: "QRS" }, { text: " (ms)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.qrs_interval || "-", style: "tableValueCell" },
        ],
        [
          {},
          {
            text: [{ text: "HR" }, { text: " (BPM)", fontSize: 8 }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.heart_rate || "-", style: "tableValueCell" },
          {
            text: [{ text: "Axis" }],
            style: "tableTextCell",
          },
          { text: reportData?.interpretation_data?.heart_rate_axis || "-", style: "tableValueCell" },
        ],
      ],
    },
  };
};

function setFindings(reportData) {
  return reportData?.interpretation_data?.suggested_actions ? [
    { text: 'Findings and Suggested Actions (if any) –', style: 'findingsHeading' },
    {
      style: 'tableExample',
      table: {
        widths: ['*'],
        body: [
          [{
            text: reportData?.interpretation_data?.suggested_actions || "",
            margin: [10, 5],
            lineHeight: 1.2
          }],
        ]
      }
    }
  ] : [];
};

function setNote(notesOf) {
  const heading = "Disclaimer - ";
  const content = notes[notesOf || "default"];
  return {
    margin: [50, 0, 50, 10],
    text: heading + content,
    fontSize: 8,
    bold: true
  };
};

async function setSignature(reportData) {
  const sign = {};
  const signature = Buffer.from(fs.readFileSync(`assets/sign/${reportData?.interpretation_data?.signature_of || 'default.png'}`));
  sign["image"] = signature;
  return {
    margin: [50, 10, 50, 0],
    columns: [
      {
        width: 150,
        ...sign,
      },
      { text: '' },
      {
        margin: [0, 30, 0, 0],
        text: [
          { text: "Not for Medico Legal Purpose", fontSize: 9, bold: true },
          { text: "\n\nPowered by: Sunfox Technologies Private Limited", fontSize: 9, bold: true }
        ]
      }
    ],
    pageBreak: 'after'
  }
};

async function ecgReportChartPage(ecgData, { width, height }) {
  const chartSVG = await create12LeadECGPlot(ecgData, width, height);
  if (chartSVG) {
    let chartPdfContent = [
      {
          alignment: "center",
          margin: [20, 20],
          columns:[{
            svg: chartSVG,
          }]
      },
    ];
    return chartPdfContent;
  }
  return [];
};

const create12LeadECGPlot = async(data, width, height) => {
  try {
    // returns a window with a document and an svg root node
    const window = createSVGWindow();
    const document = window.document;

    // register window and document
    registerWindow(window, document);

    const leads = Object.keys(data);
    const total_leads = (leads.length > 6 ? leads.length + 1 : leads.length);
    height = (total_leads === 1 ? 40 : 0) + ((total_leads > 3 ? Math.ceil(total_leads/2) : total_leads) * 90)
    let draw = SVG(document.documentElement).size(width, height).css({ "border-width": "0.00001pt", "border-style": "solid", "border-color": "#c0c0c0" });


    function makeReferenceSample() {
      var referenceSample = [];
      for (var i = 1; i <= 20; i++) {
          referenceSample.push(370.0);
      }
      for (var i = 21; i <= 60; i++) {
          referenceSample.push(650.0);
      }
      for (var i = 61; i <= 80; i++) {
          referenceSample.push(370.0);
      }
      return referenceSample;
    };

    function plotGrid(draw, { height, width }, { gridSize, gridColor, gridLineWidth, boxColor, boxLineWidth, scaleBoxLineWidth }) {
      // Add horizontal grid lines
      for (let y = 0, box = 0; y < height; y += gridSize) {
        if (y === 0 || y/(gridSize * box) === 5) {
          box++;
          draw.line(0, y, width, y).stroke({ width: (box % 2 === 1 ? scaleBoxLineWidth : boxLineWidth), color: boxColor });
        } else draw.line(0, y, width, y).stroke({ width: gridLineWidth, color: gridColor });
      }
    
      // Add vertical grid lines
      for (let x = 0, box = 0; x < width; x += gridSize) {
        if (x === 0 || x/(gridSize * box) === 5) {
          box++;
          draw.line(x, 0, x, height).stroke({ width: (box % 2 === 1 ? scaleBoxLineWidth : boxLineWidth), color: boxColor });
        } else draw.line(x, 0, x, height).stroke({ width: gridLineWidth, color: gridColor });
    
      }
      return draw;
    };

    const referenceSample = makeReferenceSample();

    const gridSize = 4;
    const gridLineWidth = 0.05;
    const boxLineWidth = 0.6;
    const chartLineWidth = 1;
    const textFontSize = 13;
    const xScaleDown = 7;
    const yScaleDown = 14;
    const textColor = hexRgb("#333333");
    const textFont = 'arial';
    const textChatGap = (leads.length > 3 ? 10 : 0);
    const chartColor = '#444444';
    const boxColorCode = '#FF7F7F' //'#555555';
    const scaleBoxLineWidth = 1;
    const boxColorData = hexRgb(boxColorCode, { alpha: 0.5 });
    const gridColorData = hexRgb(boxColorCode, { alpha: 0.4 });
    const boxColor = `rgba(${boxColorData?.red},${boxColorData?.green},${boxColorData?.blue},${boxColorData?.alpha})`;
    const gridColor = `rgba(${gridColorData?.red},${gridColorData?.green},${gridColorData?.blue},${gridColorData?.alpha})`;

    const xScale = width / (2 *(data[leads[0]].length - 1));
    const yScale = (height / (leads.length > 3 ? Math.ceil(total_leads / 2) : (total_leads + 0.5))) + (leads.length > 3 ? 0 : (textFontSize / 2));

    draw = plotGrid(draw, { height, width }, { gridSize, gridColor, gridLineWidth, boxColor, boxLineWidth, scaleBoxLineWidth })

    const leadTitleStartFrom = 2;
    const col2LeadGap = 1;
    const leadsName = {
      "lead1_data": "Lead I", "lead2_data": "Lead II", "lead3_data": "Lead III", "v1_data": "v1", "v2_data": "v2", "v3_data": "v3",
      "avr_data": "aVr", "avl_data": "aVl", "avf_data": "aVf", "v4_data": "v4", "v5_data": "v5", "v6_data": "v6"
    }

    let lead2_half = false, leadCol1Scale = 18, leadCol2Scale = 18, startDataPointIndex = 0, endDataPointIndex = Infinity;
    if (leads.length > 3) {
      if (leads.length > 7) lead2_half = true;
      endDataPointIndex = 1950;
    }
    let leadStartIndex = 0, lead2Index = 0;
    const col1Lead = ["lead1_data", "lead2_data", "lead3_data", "v1_data", "v2_data", "v3_data"], 
          col2Lead = ["avr_data", "avl_data", "avf_data", "v4_data", "v5_data", "v6_data"];
    // Iterate through key-value pairs with index using Object.entries
    for (let column1 = 0, leadIndex = leadStartIndex; column1 < col1Lead.length; column1++) {
      const leadData = data[col1Lead[column1]]?.slice(startDataPointIndex, endDataPointIndex - referenceSample?.length);
      if (!leadData) continue;
      if (!lead2_half && col1Lead[column1] === "lead2_data") continue;
      const refPathData = [...referenceSample]?.map((value, index) => {
        const x = xScale + (index / xScaleDown);
        const y = (yScale * leadIndex + yScale) - (parseFloat(value)/yScaleDown);
        return `${x},${y}`;
      }).join(' ');
      draw.polyline(refPathData).fill('none').stroke({ width: chartLineWidth, color: chartColor });

      const pathData = [...leadData]?.map((value, index) => {
        const x = xScale + ((referenceSample.length + index) / xScaleDown);
        const y = ((parseFloat(value) < 200 ? yScale - leadCol1Scale : yScale) * leadIndex + yScale) - (parseFloat(value)/yScaleDown);
        return `${x},${y}`;
      }).join(' ');
      draw.text(`${leadsName[col1Lead[column1]]}`).move(leadTitleStartFrom, (yScale * leadIndex) - (textFontSize/2)).font({ size: textFontSize, family: textFont, weight: 700 }).fill(textColor);
      draw.polyline(pathData).fill('none').stroke({ width: chartLineWidth, color: chartColor });
      leadIndex++
      lead2Index++;
    }

    for (let column2 = 0, leadIndex = leadStartIndex; column2 < col2Lead.length; column2++) {
      const leadData = data[col2Lead[column2]]?.slice(startDataPointIndex, endDataPointIndex);
      const leadName = leadsName[col2Lead[column2]];
      if (!leadData) continue;
      let pathData = [...leadData]?.map((value, index) => {
        const x = ((width / 2 + col2LeadGap) + xScale + (index / xScaleDown));
        let y = ((parseFloat(value) < 200 ? yScale - leadCol2Scale : yScale) * leadIndex + yScale) - (parseFloat(value)/yScaleDown);
        if (leadName === "aVr") y = (yScale * leadIndex + yScale) - 32 - (parseFloat(value)/yScaleDown);
        return `${x},${y}`;
      }).join(' ');
      draw.text(`${leadName}`).move((width / 2) + (leadTitleStartFrom + col2LeadGap), (yScale * leadIndex - (textFontSize/2))).font({ size: textFontSize, family: textFont, weight: 700 }).fill(textColor);
      draw.polyline(pathData).fill('none').stroke({ width: chartLineWidth, color: chartColor });
      leadIndex++;
    }

    if (leads.indexOf("lead2_data") !== -1 && data[leads[leads.indexOf("lead2_data")]]?.length) {
      const leadIndex = lead2Index;
      const leadData = data[leads[leads.indexOf("lead2_data")]]?.slice(startDataPointIndex, Infinity);

      const refPathData = [...referenceSample]?.map((value, index) => {
        const x = xScale + (index / xScaleDown);
        const y = (yScale * leadIndex + yScale) - (parseFloat(value)/yScaleDown);
        return `${x},${y}`;
      }).join(' ');
      draw.polyline(refPathData).fill('none').stroke({ width: chartLineWidth, color: chartColor });

      const pathData = [...leadData]?.map((value, index) => {
        const x = xScale + ((referenceSample.length + index) / xScaleDown);
        const y = (yScale * leadIndex + yScale) - (parseFloat(value)/yScaleDown);
        return `${x},${y}`;
      }).join(' ');
      draw.text(`${leadsName["lead2_data"]}`).move(leadTitleStartFrom, (yScale * leadIndex) - (textFontSize/2)).font({ size: textFontSize, family: textFont, weight: 700 }).fill(textColor);
      draw.polyline(pathData).fill('none').stroke({ width: chartLineWidth, color: chartColor });
      leadStartIndex = 1;
    }

    return draw.svg();
  } catch (err) {
    console.log("Error while plotting chart - ")
    await errorLog(err,'generateInterpretatedPdf','reportController.js')
    return null;
  }
};



module.exports = { generateInterpretatedPdf }