const AWS = require("../config/aws");
const dynamodb = new AWS.DynamoDB();
const fs = require("fs");
var PdfPrinter = require("pdfmake");

var fonts = {
  Roboto: {
    normal: "assets/fonts/Roboto-Regular.ttf",
    bold: "assets/fonts/Roboto-Medium.ttf",
    italics: "assets/fonts/Roboto-Italic.ttf",
    bolditalics: "assets/fonts/Roboto-MediumItalic.ttf",
  },
};

var pdfMake = new PdfPrinter(fonts);

const generate = async (req, res) => {
  const rawData = [
    {
      name: "lead2_data.txt",
      data: "480,481,480,481,480,480,480,481,481,481,480,481,481,483,482,481,481,482,482,483,483,483,483,482,483,483,483,484,484,485,484,484,484,485,484,483,485,484,484,484,486,485,485,486,485,485,485,485,486,485,486,486,486,486,486,486,486,486,486,486,486,487,487,487,486,487,486,487,488,488,487,487,488,487,489,487,488,487,487,488,487,487,486,488,487,488,488,488,487,488,489,489,489,489,489,489,489,490,489,489,490,488,489,489,489,489,489,489,489,489,489,489,490,490,490,489,489,489,489,489,491,490,490,490,490,491,489,490,490,490,490,490,491,490,491,491,490,491,491,491,491,492,491,491,491,491,490,492,491,491,491,492,491,492,492",
    },
    {
      name: "v1_data.txt",
      data: "480,481,480,481,480,480,480,481,481,481,480,481,481,483,482,481,481,482,482,483,483,483,483,482,483,483,483,484,484,485,484,484,484,485,484,483,485,484,484,484,486,485,485,486,485,485,485,485,486,485,486,486,486,486,486,486,486,486,486,486,486,487,487,487,486,487,486,487,488,488,487,487,488,487,489,487,488,487,487,488,487,487,486,488,487,488,488,488,487,488,489,489,489,489,489,489,489,490,489,489,490,488,489,489,489,489,489,489,489,489,489,489,490,490,490,489,489,489,489,489,491,490,490,490,490,491,489,490,490,490,490,490,491,492,491,492,492",
    },
    {
      name: "v2_data.txt",
      data: "480,481,480,481,480,480,480,481,481,481,480,481,481,483,482,481,481,482,482,483,483,483,483,482,483,483,483,484,484,485,484,484,484,485,484,483,485,484,484,484,486,485,485,486,485,485,486,486,486,486,486,486,486,487,487,487,486,487,486,487,488,488,487,487,488,487,489,487,488,487,487,488,487,487,486,488,487,488,488,488,487,488,489,489,489,489,489,489,489,490,489,489,490,488,489,489,489,489,489,489,489,489,489,489,490,490,490,489,489,489,489,489,491,490,490,490,490,491,489,490,490,490,490,490,491,490,491,491,490,491,491,491,491,492,491,491,491,491,490,492,491,491,491,492,491,492,492",
    },
    {
      name: "v3_data.txt",
      data: "480,481,480,481,480,480,480,481,481,481,480,481,481,483,482,481,481,482,482,483,483,483,483,482,483,483,483,484,484,485,484,484,484,485,484,483,485,484,484,484,486,485,485,486,485,490,490,491,490,491,491,490,491,491,491,491,492,491,491,491,491,490,492,491,491,491,492,491,492,492",
    },
    {
      name: "v4_data.txt",
      data: "480,481,480,481,480,480,480,481,481,481,480,481,481,483,482,481,481,482,482,483,483,483,483,482,483,483,483,484,484,485,484,484,484,485,484,483,485,484,484,484,486,485,485,486,485,485,485,485,486,485,486,486,486,486,486,486,486,486,486,486,486,487,487,487,486,487,486,487,488,488,487,487,488,487,489,487,488,487,487,488,487,487,486,488,487,488,488,490,491,491,490,491,491,491,491,492,491,491,491,491,490,492,491,491,491,492,491,492,492",
    },
    {
      name: "v5_data.txt",
      data: "485,485,486,485,486,486,486,486,486,486,486,486,486,486,486,487,487,487,486,487,486,487,488,488,487,487,488,487,489,487,488,487,487,488,487,487,486,488,487,488,488,488,487,488,489,489,489,489,489,489,489,490,489,489,490,488,489,489,489,489,489,489,489,489,489,489,490,490,490,489,489,489,489,489,491,490,490,490,490,491,489,490,490,490,490,490,491,490,491,491,490,491,491,491,491,492,491,491,491,491,490,492,491,491,491,492,491,492,492",
    },
    {
      name: "v6_data.txt",
      data: "480,481,480,481,480,480,480,481,481,481,480,481,481,483,482,481,481,482,482,483,483,483,483,482,483,483,483,484,484,485,484,484,484,485,484,483,485,484,484,484,486,485,485,486,485,485,485,485,486,485,486,486,486,486,486,486,486,486,486,486,486,487,487,487,486,487,486,487,488,488,487,487,488,487,489,487,488,487,487,488,487,487,486,488,487,488,488,488,487,488,489,489,489,489,489,489,489,490,489,489,490,488,489,489,489,489,489,489,489,489,489,489,490,490,490,489,489,489,489,489,491,490,490,490,490,491,489,490,490,490,490,490,491,490,491,491,490,491,491,491,491,492,491,491,491,491,490,492,491,491,491,492,491,492,492",
    },
  ];
  const name = [];
  const ecgData = [];
  try {
    const jsonData = rawData;
    jsonData.forEach((item) => {
      name.push(item.name);
      ecgData.push(item.data);
    });

    let chartImage = [];
    //iterate through each ecgData point to craete a buffer
    for (const index in ecgData) {
      const element = ecgData[index];
      chartImage.push(await createChartImage(element));
    }

    console.log("buffer", chartImage);

    //to send arrays of all buffer for pdf making
    const pdfBuffer = await ecgReportPDF(chartImage);

    // Serve the PDF as a response
    res.contentType("application/pdf");
    res.send(pdfBuffer);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).send("Error in making pdf");
  }
};

async function ecgReportPDF(chartImage) {
  const reportHeader = Buffer.from(
    fs.readFileSync("assets/report-header.png")
  );
  const reportFooter = Buffer.from(
    fs.readFileSync("assets/report-footer.png")
  );
  const graphPaper = Buffer.from(fs.readFileSync("assets/ecg-paper.png"));

  const leadII = chartImage[0];
  const v1 = chartImage[1];
  const v2 = chartImage[2];
  const v3 = chartImage[3];
  const v4 = chartImage[4];
  const v5 = chartImage[5];
  const v6 = chartImage[6];

  const ecgChartleadII = Buffer.from(leadII);
  const ecgChartv1 = Buffer.from(v1);
  const ecgChartv2 = Buffer.from(v2);
  const ecgChartv3 = Buffer.from(v3);
  const ecgChartv4 = Buffer.from(v4);
  const ecgChartv5 = Buffer.from(v5);
  const ecgChartv6 = Buffer.from(v6);
  const ecgChartavr = "";
  const ecgChartavf = "";
  const ecgChartleadIII = "";
  const ecgChartleadI = "";
  const ecgChartavl = "";

  console.log(Buffer.compare(v1, ecgChartv1));

  const docDefinition = {
    pageSize: "A4", // or page size name
    pageMargins: [0, 100, 0, 90], // [left, top, right, bottom] or [horizontal, vertical] or just a number for equal margins
    background: {
      image: graphPaper,
      width: 595,
      opacity: 0.8,
      absolutePosition: { x: 0, y: 145 },
    },
    header: {
      image: reportHeader,
      height: 90,
      width: 595,
    },
    footer: [
      // {
      //   text: `Page 1 of 2`,
      //   alignment: "right",
      //   fontSize: 11,
      //   bold: true,
      //   margin: [0, 0, 30, 2],
      //   style: "section"
      // },
      {
        image: reportFooter,
        height: 90,
        width: 595,
      },
    ],
    content: [
      {
        style: "section",
        absolutePosition: { x: 0, y: 734.8 },
        table: {
          widths: ["*"],
          body: [
            [
              {
                text: `Page 1 of 2`,
                fontSize: 11,
                bold: true,
                margin: [0, 0, 20, 0],
                alignment: "right",
              },
            ],
          ],
        },
        layout: "noBorders",
      },
      {
        text: "Report",
        fontSize: 26,
        bold: true,
        margin: [25, 0, 0, 0],
      },
      {
        text: "Speed: 25mm/sec \t\t Chest: 10mm/mV",
        alignment: "right",
        fontSize: 10,
        margin: [0, 0, 25, 0],
      },
      {
        alignment: "left",
        margin: [30, 20],
        columns: [
          {
            width: "*",
            columns: [
              [
                {
                  text: "I",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartleadI != ""
                  ? {
                      image: ecgChartleadI,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
          {
            width: "*",
            columns: [
              [
                {
                  text: "aVr",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartavr != ""
                  ? {
                      image: ecgChartv6,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
        ],
      },
      {
        alignment: "left",
        margin: [30, 20],
        columns: [
          {
            width: "*",
            columns: [
              [
                {
                  text: "II",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartleadII != ""
                  ? {
                      image: ecgChartleadII,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
          {
            width: "*",
            columns: [
              [
                {
                  text: "aVI",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartavl != ""
                  ? {
                      image: ecgChartv6,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
        ],
      },
      {
        alignment: "left",
        margin: [30, 20],
        columns: [
          {
            width: "*",
            columns: [
              [
                {
                  text: "III",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartleadIII != ""
                  ? {
                      image: ecgChartv6,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
          {
            width: "*",
            columns: [
              [
                {
                  text: "aVf",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartavf != ""
                  ? {
                      image: ecgChartv6,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
        ],
      },
      {
        alignment: "left",
        margin: [30, 20],
        columns: [
          {
            width: "*",
            columns: [
              [
                {
                  text: "V1",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartv1 != ""
                  ? {
                      image: ecgChartv1,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
          {
            width: "*",
            columns: [
              [
                {
                  text: "V4",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartv4 != ""
                  ? {
                      image: ecgChartv4,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
        ],
      },
      {
        alignment: "left",
        margin: [30, 20],
        columns: [
          {
            width: "*",
            columns: [
              [
                {
                  text: "V2",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartv2 != ""
                  ? {
                      image: ecgChartv2,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
          {
            width: "*",
            columns: [
              [
                {
                  text: "V5",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartv5 != ""
                  ? {
                      image: ecgChartv5,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
        ],
      },
      {
        alignment: "left",
        margin: [30, 20],
        columns: [
          {
            width: "*",
            columns: [
              [
                {
                  text: "V3",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartv3 != ""
                  ? {
                      image: ecgChartv3,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
          {
            width: "*",
            columns: [
              [
                {
                  text: "V6",
                  bold: true,
                  bold: true,
                  fontSize: 12,
                  margin: [10, 0, 0, 10],
                },
                ecgChartv6 != ""
                  ? {
                      image: ecgChartv6,
                      height: 35,
                      width: 260,
                    }
                  : "",
              ],
            ],
          },
        ],
      },
    ],
    styles: {
      section: {
        // lineHeight: 1.5,
        // fontSize: 10,
        // color: "#504e4e",
        fillColor: "#f5f7f7",
      },
    },
    defaultStyle: {
      columnGap: 5,
    },
  };

  var pdfDoc = pdfMake.createPdfKitDocument(docDefinition);

  var chunks = [];
  var result;
  return new Promise((resolve) => {
    pdfDoc.on("data", function (chunk) {
      chunks.push(chunk);
    });
    pdfDoc.on("end", function () {
      result = Buffer.concat(chunks);
      console.log(result);
      resolve(result);
    });
    pdfDoc.end();
  });
}

module.exports = { giveEcgReportsForInterpretation };
