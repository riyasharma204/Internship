// const pdfMake = require('pdfmake');
const AWS = require("../config/aws");
const s3 = new AWS.S3();
const dayjs = require('dayjs');
const PdfPrinter = require("pdfmake");
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const admin = require("../config/firebase");
const converter = require('number-to-words');
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const { errorLog } = require('./errorLogs')
const { getUserFromDynamo } = require("./authController")

const fonts = {
    Roboto: {
        normal: "assets/fonts/Roboto-Regular.ttf",
        bold: "assets/fonts/Roboto-Medium.ttf",
        italics: "assets/fonts/Roboto-Italic.ttf",
        bolditalics: "assets/fonts/Roboto-MediumItalic.ttf",
    },
};

const pdfMake = new PdfPrinter(fonts);

const invoice = async (req, res) => {
    try {

        const { phone_number, number_of_reports, startDate, endDate, business_id, invoice_number, discount_amount, business_name, email } = req.body

        const clientData = await getUserFromDynamo(phone_number);
        const companyData = await getUserFromDynamo(`+919027230532`);
        const b2b = clientData.Items[0]
        const superuser = companyData.Items[0]

        const now = dayjs()
        const timestamp = now.valueOf().toString()

        const logoSrc = Buffer.from(fs.readFileSync('assets/full-logo.png'));

        const data = {
            client: {
                name: b2b.company_data.business_name,
                address: {
                    street: b2b.company_data.billing_address,
                    state: b2b.company_data.state,
                    pin: b2b.company_data.pin,
                    code: b2b.company_data.code,
                },
                pan_no: b2b.company_data.pan_no,
                gstin: b2b.company_data.gst_number,
            },
            company: {
                name: superuser.company_data.company_name,
                address: {
                    street: superuser.company_data.company_address,
                    city: superuser.company_data.city,
                    state: superuser.company_data.state,
                    country: superuser.company_data.country,
                    pin: superuser.company_data.pin,
                    code: superuser.company_data.code,
                },
                website: superuser.website,
                email: superuser.email,
                cin: superuser.cin,
                gstin: superuser.company_data.gst_number,
                pan_no: superuser.company_data.pan_number,
                hsn_sac: superuser.company_data.hsn_sac

            },
            invoice_no: invoice_number,
            date: now.format('DD-MMM-YY'),
            invoice_note: "",
            reference_no: `${dayjs(startDate).format('DD.MM.YY')} to ${dayjs(endDate).format('DD.MM.YY')}`,
            order_no: "",
            dispatch_document_no: "",
            delivery_note_date: "",
            dispatch_via: "",
            gst_details: [
                {
                    name: "SGST",
                    value: "9",
                },
                {
                    name: "CGST",
                    value: "9",
                },
                {
                    name: "IGST",
                    value: "18",
                },
            ],
            rate: b2b.interpretation_charges,
            number_of_reports: number_of_reports,

        };

        let gstAmount = "";
        let gstHeader = "";
        let gstRate = "";
        let originalAmount = 0.0;
        let roundedOff = 0.0;
        let amountPayable;

        if (data.client.address.state === data.company.address.state) {
            gstHeader = {
                text: `${data.gst_details[0].name}+${data.gst_details[1].name}`,
                colSpan: 2,
                alignment: "center",
            };
            gstRate = {
                text: `${data.gst_details[0].value}% + ${data.gst_details[1].value}%`,
            };
        } else {
            gstHeader = {
                text: `${data.gst_details[2].name}`,
                colSpan: 2,
                alignment: "center",
            };
            gstRate = { text: `${data.gst_details[2].value}% ` };
        }

        const dd = {
            content: [
                {
                    style: "tableExample",
                    table: {
                        widths: ["19%", "38%", "21%", "22%"],
                        heights: [20, 20, 20, 20, 20, 20, "*"],
                        body: [
                            [
                                {
                                    image: logoSrc,
                                    width: 90,
                                    rowSpan: 3,
                                },
                                {
                                    text: [
                                        { text: data.company.name, style: "subheader" },
                                        {
                                            text: `\n${data.company.address?.street},\n${data.company.address?.city}, ${data.company.address?.state || ''}, ${data.company.address?.country || ''} ${data.company.address?.pin || ''}\nGSTIN/UIN: ${data.company.gstin}\nState name : ${data.company.address.state}, Code : ${data.company?.address?.code || '-'}\nCIN:${data.company?.cin}\nE-Mail :${data.company?.email}`,
                                        },
                                    ],
                                    rowSpan: 3,
                                    fontSize: 11,
                                },
                                {
                                    text: [
                                        { text: "Invoice No.", alignment: "top" },
                                        { text: `\n${data.invoice_no}`, style: "sectionValue" },
                                    ],
                                },
                                {
                                    text: [
                                        { text: "Dated" },
                                        { text: `\n${data.date}`, style: "sectionValue" },
                                    ],
                                },
                            ],
                            [
                                "",
                                {},
                                {
                                    text: [{ text: "Delivery Note" }, { text: "" }],
                                },
                                {
                                    text: [
                                        { text: "Mode/Terms of Payment" },
                                        { text: "\nDue Upon Receipt", style: "sectionValue" },
                                    ],
                                },
                            ],
                            [
                                "",
                                {},
                                {
                                    text: [
                                        { text: "Reference No. & Date" },
                                        { text: `\ndt. ${data.date}`, style: "sectionValue" },
                                    ],
                                },
                                {
                                    text: [
                                        { text: "Other References" },
                                        { text: `\n${data.reference_no}`, style: "sectionDateValue" },
                                    ],
                                },
                            ],
                            [
                                {
                                    text: [
                                        { text: "Consignee (Ship to)" },
                                        {
                                            text: `\n${data.client?.name || ''}`,
                                            bold: true,
                                            style: "subheader",
                                        },
                                        {
                                            text: `\n${data.client?.address?.street || ''}`,
                                        },
                                        { text: `\n${data.client?.address?.pin || ''}` },
                                        { text: `\nGSTIN/UIN\t\t:\t${data.client?.gst_number || 'N/A'}` },
                                        { text: `\nState name\t\t:\t${data.client?.address?.state || ''}, Code : ${data.client?.address?.code || '-'}` },
                                    ],
                                    rowSpan: 3,

                                    border: [true, true, false, false],
                                    colSpan: 2,
                                    fontSize: 11,
                                },
                                {},
                                {
                                    text: [{ text: "Buyers Order No.\n" }, { text: "" }],
                                },
                                {
                                    text: [{ text: "Dated" }, { text: "\n" }],
                                },
                            ],
                            [
                                "",
                                {},
                                {
                                    text: [{ text: "Dispatch Doc No" }, { text: "" }],
                                },
                                {
                                    text: [{ text: "Delivery Note Date" }, { text: "" }],
                                },
                            ],
                            [
                                "",
                                {},
                                {
                                    text: [{ text: "Dispatched through" }, { text: "" }],
                                },
                                {
                                    text: [
                                        { text: "Destination" },
                                        { text: `\n${data.client?.address?.state || ''}`, style: "sectionValue" },
                                    ],
                                },
                            ],
                            [
                                {
                                    text: [
                                        { text: "Buyer (Bill to)" },
                                        {
                                            text: `\n${data.client?.name || ''}`,
                                            bold: true,
                                            style: "subheader",
                                        },
                                        {
                                            text: `\n${data.client?.address?.street || ''}`,
                                        },
                                        { text: `\n${data.client?.address?.pin || ''}` },
                                        { text: `\nGSTIN/UIN\t\t:\t${data.client?.gst_number || 'N/A'}` },
                                        { text: `\nState name\t\t:\t${data.client?.address?.state || ''}, Code : ${data.client?.address?.code || '-'}` },
                                    ],
                                    colSpan: 2,
                                    fontSize: 11,
                                },
                                {},
                                {
                                    text: "Terms of delivery: \n\n\n",

                                    colSpan: 2,
                                    border: [true, true, true, true],
                                },

                                "",
                            ],
                        ],
                    },
                },
                {
                    style: "tableExample",
                    table: {
                        widths: ["4%", "43%", "12%", "11%", "10%", "20%"],
                        heights: ["", 60, "", 60],
                        body: [
                            [
                                { text: "Sl\nNo.", alignment: "center" },
                                {
                                    text: "Description of \n Services",
                                    colSpan: 2,
                                    alignment: "center",
                                },
                                {},
                                { text: "HSN/SAC", alignment: "center" },
                                { text: "GST Rate", alignment: "center" },
                                { text: "Amount", alignment: "center" },
                            ],

                            [
                                { text: "1", border: [true, true, true, false] },
                                {
                                    text: [
                                        {
                                            text: " ECG Interpretation Services",
                                            bold: true,
                                            style: "subheader",
                                        },
                                        { text: `\nPER ECG RATE ${data.rate}RS` },
                                        { text: `\n TOTAL NO OF REPORT ${data.number_of_reports}` },
                                        {
                                            text: `\n  ${data.number_of_reports} *  ${data.rate
                                                } = ${(originalAmount =
                                                    data.number_of_reports * data.rate)}`,
                                        },
                                    ],
                                    colSpan: 2,
                                    border: [true, true, false, false],
                                    fontSize: 10,
                                },
                                "",
                                { text: `${data.company.hsn_sac}`, border: [true] },
                                { text: "18%", border: [true] },
                                {
                                    text: `${originalAmount.toFixed(2)}`,
                                    border: [true, true, true, false],
                                    bold: true,
                                    alignment: "right",
                                    fontSize: 11,
                                },
                            ],
                            [
                                { text: "", border: [true, false, true, false] },
                                { text: "", border: [false, false, false, false] },
                                {
                                    text: "Discount-Amount",
                                    border: [false, false, false, false],
                                    alignment: "right",
                                },
                                { text: "", border: [true, false, true, false] },
                                { text: "", border: [false, false, false, false] },

                                {
                                    text: `${discount_amount.toFixed(2)}`,
                                    border: [true, false, true, false],
                                    bold: true,
                                    alignment: "right",
                                    fontSize: 11,
                                },
                            ],
                            [
                                { text: "", border: [true, false, true, false] },
                                { text: "", border: [false, false, false, false] },
                                {
                                    text: "IGST",
                                    border: [false, false, false, false],
                                    alignment: "right",
                                },
                                { text: "", border: [true, false, true, false] },
                                { text: "", border: [false, false, false, false] },

                                {
                                    text: `${(gstAmount = (
                                        (data.gst_details[2].value / 100) *
                                        originalAmount
                                    ).toFixed(2))}`,
                                    border: [true, false, true, false],
                                    bold: true,
                                    alignment: "right",
                                    fontSize: 11,
                                },
                            ],
                            [
                                { text: "", border: [true, false, true, false] },
                                { text: "", border: [false, false, false, true] },
                                {
                                    text: "Round Off",
                                    border: [false, false, false, true],
                                    alignment: "right",
                                },
                                { text: "", border: [true, false, true, true] },
                                { text: "", border: [false, false, false, true] },

                                {
                                    text: `${(roundedOff = (
                                        Math.ceil(gstAmount) - gstAmount
                                    ).toFixed(2))}`,
                                    border: [true, false, true, true],
                                    bold: true,
                                    alignment: "right",
                                },
                            ],
                            [
                                "",
                                { text: "", border: [false, false, false, true] },
                                {
                                    text: "Total ",
                                    border: [false, false, false, true],
                                    alignment: "right",
                                },
                                { text: "", border: [true, false, false, true] },
                                { text: "", border: [true, false, false, true] },

                                {
                                    text: `${(amountPayable = (parseFloat(originalAmount) +
                                        parseFloat(gstAmount) +
                                        parseFloat(roundedOff)) - parseFloat(discount_amount)
                                    ).toFixed(2)}`,
                                    bold: true,
                                    alignment: "right",
                                    fontSize: 11,
                                },
                            ],
                            [
                                {
                                    text: [
                                        { text: "Amount Chargeable (in words)" },
                                        {
                                            text: `\n INR ${(converter.toWords(amountPayable)).toUpperCase()}`,
                                            bold: true,
                                        },
                                    ],
                                    colSpan: 5,
                                    border: [true, true, false, true],
                                },
                                "",
                                "",
                                "",
                                "",
                                {
                                    text: "E. & O.E",
                                    alignment: "right",
                                    border: [false, true, true, true],
                                },
                            ],
                        ],
                    },
                },
                {
                    style: "tableExample",
                    table: {
                        widths: ["30%", "15%", "15%", "15%", "25%"],
                        heights: 2,

                        body: [
                            [
                                { text: "HSN/SAC", alignment: "center", rowSpan: 2 },
                                {
                                    text: "Taxable",
                                    alignment: "center",
                                    border: [true, true, true, false],
                                },

                                gstHeader,
                                { text: "" },
                                {
                                    text: "Total",
                                    border: [true, true, true, false],
                                    alignment: "center",
                                },
                            ],

                            [
                                { text: "" },
                                {
                                    text: "Value",
                                    border: [true, false, false, true],
                                    alignment: "center",
                                },
                                { text: "Rate" },
                                { text: "Amount" },

                                {
                                    text: "Tax Amount",
                                    border: [true, false, true, true],
                                    alignment: "center",
                                },
                            ],
                            [
                                { text: "999312", alignment: "left" },
                                { text: `${originalAmount.toFixed(2)}`, alignment: "right" },
                                gstRate,
                                { text: `${parseFloat(gstAmount).toFixed(2)}`, alignment: "right" },
                                { text: `${parseFloat(gstAmount).toFixed(2)}`, alignment: "right" },
                            ],
                            [
                                { text: "Total", bold: true, alignment: "right" },
                                { text: `${originalAmount.toFixed(2)}`, bold: true, alignment: "right" },
                                {},
                                { text: `${parseFloat(gstAmount).toFixed(2)}`, bold: true, alignment: "right" },
                                { text: `${parseFloat(gstAmount).toFixed(2)}`, bold: true, alignment: "right" },
                            ],

                            [
                                {
                                    columns: [
                                        { text: "Tax Amount (in words) :", width: "auto" },
                                        {
                                            text: `INR ${(converter.toWords(amountPayable)).toUpperCase()} ONLY`,
                                            width: "*",
                                            bold: true,
                                        },
                                    ],
                                    colSpan: 5,
                                    border: [true, true, true],
                                    columnGap: 5,
                                    margin: [0, 5, 0, 0],
                                },
                            ],
                            [
                                {
                                    columns: [
                                        { text: "Companys PAN :", width: "auto" },
                                        { text: "AAYCS5941B", bold: true, width: "*" },
                                    ],
                                    colSpan: 5,
                                    border: [true, false, true],
                                    margin: [0, 0, 0, 5],
                                    columnGap: 5,
                                },
                            ],
                            [
                                {
                                    text: "Declaration",
                                    colSpan: 5,
                                    alignment: "top",
                                    border: [true, false, true, false],
                                    style: { decoration: "underline" },
                                },
                            ],

                            [
                                {
                                    ol: [
                                        "Make all cheque payable to : Sunfox Technologies Pvt. Ltd",
                                        " All goods returned for replacement/credit must be in \n saleable condition with original packing.",
                                        "Please check the received goods for any damage \nclaims after 24 hours, from the time of delivery, will not be \n acceptable.                          ",
                                    ],
                                    colSpan: 5,
                                    border: [true, false, true],
                                },
                            ],
                            [
                                {
                                    text: "We declare that this invoice shows the actual price of thegoods described and that all particulars are true and correct",
                                    colSpan: 2,
                                    border: [true, false, true, true],
                                    margin: [0, 10, 0, 0],
                                },
                                {},
                                {
                                    text: [
                                        { text: "for Sunfox Technologies Pvt. Ltd.", bold: true },
                                        { text: "\n\n\n\nAuthorized Signatory" },
                                    ],
                                    colSpan: 3,
                                    alignment: "right",
                                },
                            ],
                        ],
                    },
                },
            ],
            styles: {
                header: {
                    fontSize: 18,
                    bold: true,
                    margin: [0, 0, 0, 10],
                },
                subheader: {
                    fontSize: 12,
                    bold: true,
                },
                sectionValue: {
                    margin: [20, 50],
                    fontSize: 11,
                    bold: true,
                },
                sectionDateValue: {
                    margin: [20, 50],
                    fontSize: 11,
                    bold: true,
                },
                tableExample: {
                    margin: [0, 0, 0, 0],
                    fontSize: 9,
                },
                tableHeader: {
                    bold: true,
                    fontSize: 13,
                    color: "black",
                },
            },
            defaultStyle: {
                // alignment: 'justify'
            },
        };
        const pdfDoc = pdfMake.createPdfKitDocument(dd);
        let chunks = [], buffer;
        pdfDoc.on("data", function (chunk) {
            chunks.push(chunk);
        });
        pdfDoc.on("end", async function () {
            buffer = Buffer.concat(chunks);
            res.setHeader("Content-Type", "application/pdf");
            res.setHeader(
                "Content-Disposition",
                'attachment; filename="generated.pdf"'
            );

            //to store the pdf in s3
            // const bucketName = process.env.AWS_S3_INVOICE_DATA_PDF;
            const bucketName = process.env.AWS_S3_INVOICE_DATA_PDF;
            const sanitizedInvoiceId = invoice_number.replace(/\//g, '_');

            const pdfParams = {
                Bucket: bucketName,
                Key: `${process.env.SPANDAN_SERVICE_ENVIRONMENT}/${business_id}/${sanitizedInvoiceId}-${timestamp}.pdf`,
                Body: buffer,
                ContentType: 'application/pdf',
            };
            const s3location = await s3.upload(pdfParams).promise()

            res.json({ status: 200, success: true, data: { InvoicePdf: Buffer.from(buffer).toString("base64"), InvoiceDetails: { date: data.date, amount: amountPayable, startDate: startDate, endDate: endDate, invoice_url: s3location.Key, invoice_timestamp: timestamp } } });
        });
        pdfDoc.end();
    } catch (error) {

        await errorLog(error, 'invoice', 'billController.js')
        res.send("some error");
    }
}

const getUserOrder = async (req, res) => {
    try {
        const auth = req.headers;
        if (!auth || (!auth.usertype || !auth.phonenumber)) {
            return res.status(401).json({ status: 401, success: false, message: "Unauthorized" });
        }
        const { usertype, phonenumber } = auth;
        if (usertype !== "user" && usertype !== "b2b") {
            return res.status(403).json({ status: 403, success: false, message: "Insufficient permissions" });
        }
        const status = 'paid';
        const getParams = {
            TableName: process.env.INTERPRETATION_REQUEST_ORDER_TABLE,
            FilterExpression: "#id = :phone_number AND #order_status = :order_status",
            ExpressionAttributeNames: {
                "#id": "phone_number",
                "#order_status": "order_status",
            },
            ExpressionAttributeValues: {
                ":phone_number": phonenumber,
                ":order_status": status,
            },
        };
        const { Items } = await dynamoDB.scan(getParams).promise();
        return res.json({ status: 200, success: true, data: Items });
    } catch (error) {
        await errorLog(error, 'getUserOrder', 'billController.js')
        return res.status(500).json({ status: 500, success: false, message: "Internal Server Error" });
    }
};

const saveInvoiceDetails = async (req, res) => {
    try {
        const { phone_number, date, amount, discount_amount, business_id, startDate, endDate, invoice_number, business_name, email, interpretation_charges, invoice_url, invoice_timestamp, number_of_reports } = req.body
        await saveInvoiceHistory(invoice_number, startDate, endDate, business_id, business_name, email, interpretation_charges, date, amount, discount_amount, invoice_url, number_of_reports, invoice_timestamp)

        const setParams = {
            TableName: process.env.INTERNAL_USERS_TABLE,
            Key: { api_key: business_id },
            UpdateExpression: 'SET invoice_details = :newInvoiceDetails',
            ExpressionAttributeValues: {
                ':newInvoiceDetails': {
                    'last_amount_payable': amount,
                    'last_generated_invoice': date
                },
            }
        }

        await dynamoDB.update(setParams).promise();
        return res.json({
            status: 200,
            success: true,
            message: "Updated Successfully.",
        });
    }
    catch (error) {

        await errorLog(error, 'saveInvoiceDetails', 'billController.js')
        return res.json({ status: 500, success: false, message: error });

    }
}

const saveInvoiceHistory = async (
    invoice_number,
    startDate,
    endDate,
    business_id,
    business_name,
    email,
    interpretation_charges,
    date,
    amount,
    discount_amount,
    invoice_url,
    number_of_reports,
    invoice_timestamp
) => {
    const params = {
        TableName: process.env.INVOICE_DATA_TABLE,
        Item: {
            business_id: business_id,
            invoice_timestamp: invoice_timestamp,
            invoice_number: invoice_number,
            business_name: business_name,
            email: email,
            generated_on: date,
            charge_per_interpretation: interpretation_charges,
            amount: amount,
            discount_amount: discount_amount,
            number_of_reports: number_of_reports,
            invoice_url: invoice_url,
            billing_period: {
                start_date: startDate,
                end_date: endDate
            }
        },
    };
    await dynamoDB.put(params).promise();
}

const fetchInvoiceData = async (req, res) => {

    try {
        const { business_id } = req.body;
        if (business_id) {
            const params = {
                TableName: process.env.INVOICE_DATA_TABLE,
                KeyConditionExpression: 'business_id = :id',
                ExpressionAttributeValues: {
                    ':id': business_id,
                },
            }
            const result = await dynamoDB.query(params).promise();
            return res.json({
                status: 200,
                success: true,
                message: 'data fetched successfully',
                data: result?.Items

            });
        } else {
            return res.json({
                status: 200,
                success: true,
                message: 'data fetched successfully',
                data: []
            });
        }
    }
    catch (error) {
        await errorLog(error, 'fetchInvoiceData', 'billController.js')
        return res.json({ status: 500, success: false, message: error });
    }
}

const toCheckInvoiceNumber = async (req, res) => {
    try {
        const { invoice_number, business_id } = req.body

        //to check if invoice number already exists
        const checkParams = {
            TableName: process.env.INVOICE_DATA_TABLE,
            KeyConditionExpression: 'business_id = :id ',
            FilterExpression: "invoice_number = :invoice",
            ExpressionAttributeValues: {
                ':id': business_id,
                ':invoice': invoice_number,
            },
        };

        const checkResult = await dynamoDB.query(checkParams).promise();

        if (checkResult.Items && checkResult.Items.length > 0) {
            return res.json({
                status: 500,
                success: false,
                message: "Invoice number already exists!",
            });
        }
        else {

            return res.json({
                status: 200,
                success: true,
                message: "Successfull",
            })
        }
    }
    catch (error) {
        await errorLog(error, 'toCheckInvoiceNumber', 'billController.js')
        return res.json({
            status: 500,
            success: false,
            message: "ServerSide Issue",
        })
    }
}

const fetchClientPdf = async (req, res) => {
    try {
        const { invoiceUrl } = req.body
        const bucketName = process.env.AWS_S3_INVOICE_DATA_PDF
        const params = {
            Bucket: bucketName,
            Key: invoiceUrl
        };
        const { Body } = await s3.getObject(params).promise();

        res.json({
            status: 200,
            success: true,
            message: "Successfull",
            data: Buffer.from(Body).toString("base64")
        })

    } catch (error) {
        await errorLog(error, 'fetchClientPdf', 'billController.js')
        return res.json({
            status: 500,
            success: false,
            message: "ServerSide Issue",
        })
    }
};

module.exports = {
    invoice,
    getUserOrder,
    saveInvoiceDetails,
    fetchInvoiceData,
    toCheckInvoiceNumber,
    fetchClientPdf,
};
