
const jwt = require('jsonwebtoken')
const { getUserFromDynamo, getUserFromFirebase } = require('./authController');


const verifyToken = async (req, res, next) => {
    
    const token = req.headers?.authorization;

    const appUser = (req.headers["x-sunfox-key"] && req.headers["x-sunfox-key"].length !== 0) ? true : false

    if(appUser){
        
        try{

            if (req.headers["x-sunfox-key"] !== process.env.X_SUNFOX_KEY || !token) {
                res.json({success: false,status: 401,message: "Unauthorized"})
            }
            else{
                
                const {phoneNumber} = await jwt.verify(req.headers.authorization.trim(), process.env.JWT_SECRET_KEY_FOR_APP)
                
                const user = await getUserFromFirebase(phoneNumber)

                if (!user) res.json({success: false,status: 401,message: "Unauthorized"})

                else{
                    req.headers.user = {
                        phoneNumber: user?.phoneNumber,
                        userType: "user",
                        email: user?.userEmail,
                        name: `${user?.firstName} ${user?.lastName}`,
                        displayName: user?.firstName,
                        profilePic: user?.primaryUserProfilePicture,
                        business_id: user?.business_id
                    }
                    next()
                }

            }
        }
        catch(err){
            console.log(err)
            return res.json({success: false,status: 401,message: "Unauthorized"})
        }
    }
    else{
        if (!token) {
            return res.status(403).json({ status: 403, success: false, message: 'Invalid auth token.' })
        }
        try {
            const decoded = await jwt.verify(token, process.env.SPANDAN_SERVICE_JWT_SECRET)
            const userTokenData = {
                ...decoded
            };
            if (userTokenData?.userType === "user") {
                const user =await getUserFromFirebase(userTokenData?.phoneNumber)
                if (!user) return res.status(403).json({ status: 403, success: false, message: "User not found." })
                req.headers.user = {
                    phoneNumber: user?.phoneNumber,
                    userType: userTokenData?.userType,
                    email: user?.email,
                    name: `${user?.firstName} ${user?.lastName}`,
                    displayName: user?.firstName,
                    profilePic: user?.primaryUserProfilePicture,
                    business_id: user?.business_id
                }
                next();
            } else {
                const {Items} = await getUserFromDynamo(userTokenData?.phoneNumber,userTokenData?.business_id)
                const user = Items[0]
                if (user && (user?.status !== 'deleted' && user?.status !== 'inactive')) {
                    req.headers.user = {
                        phoneNumber: user?.phone_number,
                        userType: user?.user_type,
                        email: user?.email,
                        name: user?.name,
                        displayName: user?.name,
                        business_id: user?.api_key,
                        associated_users: user?.api_key ? user?.associated_users || [] : null,
                    }
                    next();
                } else {
                    return res.status(403).json({ status: 403, success: false, message: "User not found." })
                }
            }
        } catch(error) {
            return res.status(403).json({ status: 403, success: false, message: error.code || 'Invalid auth token.', data: error });
        }
    }
}


const decodeJWT = async (token) => {
    if (!token) return null;
    try {
        const decoded = await jwt.verify(token, process.env.SPANDAN_SERVICE_JWT_SECRET)
        const userTokenData = {
            ...decoded
        };
        if (userTokenData?.userType === "user") {
            const user =await getUserFromFirebase(userTokenData?.phoneNumber)
            if (user) { 
                return {
                    phoneNumber: user?.phoneNumber,
                    userType: userTokenData?.userType,
                    email: user?.email,
                    name: `${user?.firstName} ${user?.lastName}`,
                    displayName: user?.firstName,
                    profilePic: user?.primaryUserProfilePicture,
                    business_id: user?.business_id
                }
            } 
            return null;
        } else {
            const {Items} = await getUserFromDynamo(userTokenData?.phoneNumber,userTokenData?.business_id)
            const user = Items[0]
            if (user && (user?.status !== 'deleted' && user?.status !== 'inactive')) {
                return {
                    phoneNumber: user?.phone_number,
                    userType: user?.user_type,
                    email: user?.email,
                    name: user?.name,
                    displayName: user?.name,
                    business_id: user?.api_key,
                    associated_users: user?.api_key ? user?.associated_users || [] : null
                }
            }
            return null;
        }
        return decoded;
    } catch (err) {
        console.log("Decode token error: ", err)
        return null;
    }
}

module.exports = { verifyToken, decodeJWT }
