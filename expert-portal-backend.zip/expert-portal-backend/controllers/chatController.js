const AWS = require("../config/aws");
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();
const dayjs = require('dayjs');
const openai = require('../config/openAi')


const saveUserQuery = async (req, res) => {


  try {

    const { concern, base64Image , filename} = req.body
    const phone_number = req.headers.phonenumber
    const query_timestamp = dayjs().valueOf().toString()
    const buffer = Buffer.from(base64Image, 'base64');


    const pdfParams = {
      Bucket: 'interpretation-ai-attachment',
      Key: `${phone_number}/${filename}.jpg`,
      Body: buffer,
    
      ContentType: 'image/jpeg',
      
    };
    console.log(pdfParams)
    const s3location = await s3.upload(pdfParams).promise()
    console.log(s3location)
    
    const params = {
      TableName: 'interpretation_ai',
      Item: {
        phone_number,
        query_timestamp,
        interpreation_image_url: s3location.Key,
        user_queries: concern
      }
    }
    await dynamodb.put(params).promise();



    

    // const response = await openai.chat.completions.create({
    //   model: "Spandan ECG Nexus",
    //   messages: [
    //     {
    //       role: "user",
    //       content: [
    //         { type: "text", text: "What’s in this image?" },
    //         {
    //           type: "image_url",
    //           image_url: {
    //             "url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg",
    //           },
    //         },
    //       ],
    //     },
    //   ],
    // });
    //   console.log(response.choices[0])

    const getImage = {
      Bucket: 'interpretation-ai-attachment',
      Key: `${phone_number}/${query_timestamp}.jpg`,
    }

    const { Body } = await s3.getObject(getImage).promise();
   
    res.json({ status: 200, success: true, message: "sucessfully updated", data: Buffer.from(Body).toString("base64") });
  }
  catch (error) {
    console.log(error)
    res.json({ status: 200, success: true, message: "sucessfully updated", data: error });
  }

}

module.exports = { saveUserQuery }
