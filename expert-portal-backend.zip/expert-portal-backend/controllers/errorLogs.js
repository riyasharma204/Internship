const AWS = require('../config/aws');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const dayjs = require('dayjs');


async function errorLog(error,functionName,fileName) {

 try { 
    console.log(`Error caught in ${functionName} of ${fileName}`,error)
    const params = {
      TableName: process.env.EXPERT_PORTAL_ERROR_LOGS_TABLE,
      Item: {
        timestamp: dayjs().valueOf().toString(),
        message: error.message || 'Unknown error' ,
        stack: error.stack || 'No stack trace available',
        function_name:functionName,
        file_name:fileName
      },
    };
      await dynamodb.put(params).promise();

    } catch (dbError) {
      console.error('Error catched to errorlogs:', dbError.message);
    }

  };

  
  module.exports={errorLog};


  