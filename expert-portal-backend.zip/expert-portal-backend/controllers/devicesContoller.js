const fs = require('fs')
const path = require('path')
const dayjs = require('dayjs')
const AWS = require('../config/aws')
const s3 = new AWS.S3()
const mongoose = require('mongoose')
const { start } = require('repl')
const dynamoDB = new AWS.DynamoDB.DocumentClient()

const Device = mongoose.model('devices', new mongoose.Schema({}, { strict: false }))

const getDevices = async (masterKey,uniqueDeviceId) => {

    if(uniqueDeviceId){
        return await Device.findOne({ masterKey, uniqueDeviceId, "logData.okTestedAt": { $exists: true } }).select("uniqueDeviceId")
    }
    else{
        return await Device.find({ masterKey, "logData.okTestedAt": { $exists: true } }).select("uniqueDeviceId")
    }
}

const getAllDevices = async (req, res) => {

    const masterKey = req.headers?.user?.business_id

    try {

        const devices = await getDevices(masterKey);
        const promises = devices.map(async (device) => {

            const latestEntryParams = {
                TableName: process.env.ECG_RECORD_DATA_TABLE,
                IndexName: 'device_id-report_timestamp-index',
                KeyConditionExpression: 'device_id = :deviceId',
                ExpressionAttributeValues: { ':deviceId': device.uniqueDeviceId },
                ScanIndexForward: false,
                Limit: 1
            }

            //get status of device
            const getParams = {
                TableName: process.env.BUSINESS_DEVICE_DETAILS,
                Key: {id: device.uniqueDeviceId}
            }
            
            
            const { Item } = await dynamoDB.get(getParams).promise()
            
            const isDisabled = Item?.device_status === "disable" ? true : false

            const { Items } = await dynamoDB.query(latestEntryParams).promise();
            if (Items && Items[0]) { return {...Items[0],isDisabled} } else { return null };
        })

        const latestEntries = await Promise.all(promises);

        res.status(200).json({ status: 200, success: true, data: latestEntries })

    } catch (err) {
        console.error('Error:', err)
        res.status(500).json({ status: 500, success: false, message: 'Internal server error' })
    }
}

const getDeviceReports = async (req, res) => {

    const { device_id } = req.params

    try {

        const params = {
            TableName: process.env.ECG_RECORD_DATA_TABLE,
            IndexName: 'device_id-report_timestamp-index',
            KeyConditionExpression: 'device_id = :deviceId',
            ExpressionAttributeValues: { ':deviceId': device_id },
            ScanIndexForward: false,
        }
        const { Items } = await dynamoDB.query(params).promise()

        res.json({ status: 200, success: true, data: Items })

    } catch (err) {
        console.error('Error:', err)
        res.status(500).json({ status: 500, success: false, message: 'Internal server error' })
    }

}

const downloadReportInJson = async (req, res) => {

    try {

        const { id } = req.query
        //const id = '16548508451724456'
        const params = {
            TableName: process.env.REPORTS_TABLE_NAME,
            Key: { 'id': Number(id) }
        }

        const { Item } = await dynamoDB.get(params).promise()

        const leadData = await readS3BucketLeadFiles(Item.paths, Item.report_type)

        const fileName = `report_${id}.json`
        const buff = Buffer.from(JSON.stringify(leadData));

        res.set('Content-disposition', 'attachment; filename=' + fileName);
        res.set('Content-Type', 'text/json');
        res.send(buff);
    } catch (error) {
        console.error('Error:', error)
        res.status(500).json({ status: 500, success: false, message: 'Internal server error' })
    }
}

const readS3BucketLeadFiles = async (paths, report_type) => {
    if (!paths) return null
    const ecgLeadData = Object.keys(paths)
    const leadsData = {}
    for (const leadData of ecgLeadData) {
        const leadPath = paths[leadData]
        const fileData = bufferToText(await readFileFromS3Bucket(leadPath, report_type))
        const fileDataList = fileData.split(',')
        leadsData[leadData] = fileDataList
    }
    return leadsData
}

const readFileFromS3Bucket = async (path, report_type) => {
    try {
        const bucketName = process.env.S3_BUCKET_NAME;
        const params = {
            Bucket: bucketName,
            Key: `${report_type}/${path.split('/')[0]}/${path.split('/')[1]}`,
        };

        const { Body } = await s3.getObject(params).promise();
        return Body;
    } catch (error) {
        throw error;
    }
};

const bufferToText = (bufferData, encoding = 'utf-8') => {
    const textData = Buffer.from(bufferData).toString(encoding)
    return textData
}


const getDeviceMonthlyCount = async (startDateTime, endDateTime, device_id) => {

    try {
        const params = {
            TableName: process.env.ECG_RECORD_DATA_TABLE,
            IndexName: 'device_id-report_timestamp-index',
            KeyConditionExpression: 'device_id = :deviceId AND report_timestamp BETWEEN :startTimestamp AND :endTimestamp',
            ExpressionAttributeValues: {
                ':deviceId': device_id,
                ':startTimestamp': startDateTime,
                ':endTimestamp': endDateTime
            },
        }
        const { Items } = await dynamoDB.query(params).promise()
        return Items.length
    }
    catch (err) {
        console.log(err)
    }
}

const getMonthlyDataOrPercentages = async (req, res) => {

    //const masterKey = "Y1kA861Ptba891Yr"
    const masterKey = req.headers?.user?.business_id
    const devices = await getDevices(masterKey)

    try {

        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        let totalOverall = 0

        const finalData = devices.map(async (device) => {

            const deviceCounts = Array(months.length).fill(0)
            let total = 0

            for (let index = 0; index < months.length; index++) {

                const startOfMonth = dayjs().month(index).startOf('month').valueOf().toString()
                const endOfMonth = dayjs().month(index).endOf('month').valueOf().toString()

                const count = await getDeviceMonthlyCount(startOfMonth, endOfMonth, device.uniqueDeviceId)
                deviceCounts[index] = count
                total += count
            }

            totalOverall += total

            return {
                name: device.uniqueDeviceId,
                data: deviceCounts,
                total
            }

        })

        let data = await Promise.all(finalData)

        if (req?.getPercentages) {

            data = data.map(device => ({
                name: device.name,
                percentage: ((device.total / totalOverall) * 100).toFixed(2) + '%'
            }))
        }
        res.status(200).json({ status: 200, success: true, data: data })

    } catch (error) {
        console.error(error)
        res.status(500).send('Internal Server Error')
    }
}


const getMonthlyTestsAndTheirCount = async (req, res) => {

    //const masterKey = "Y1kA861Ptba891Yr"
    const masterKey = req.headers?.user?.business_id
    const devices = await getDevices(masterKey)

    try {

        //all CURRENT month reports

        const startDateTime = dayjs().startOf('year').valueOf().toString()
        const endDateTime = dayjs().endOf('month').valueOf().toString()

        const bag = {}

        await Promise.all(devices.map(async (device) => {

            const params = {
                TableName: process.env.ECG_RECORD_DATA_TABLE,
                IndexName: 'device_id-report_timestamp-index',
                KeyConditionExpression: 'device_id = :deviceId AND report_timestamp BETWEEN :startTimestamp AND :endTimestamp',
                ProjectionExpression: "report_type",
                ExpressionAttributeValues: {
                    ':deviceId': device.uniqueDeviceId,
                    ':startTimestamp': startDateTime,
                    ':endTimestamp': endDateTime
                },
            }

            const { Items } = await dynamoDB.query(params).promise()

            Items.forEach(item => {
                const reportType = item.report_type
                bag[reportType] = (bag[reportType] || 0) + 1
            })

        }))

        const data = Object.entries(bag).map(([name, count]) => ({
            name: name,
            count
        }))
        res.status(200).json({ status: 200, success: true, data: data })

    }
    catch (err) {
        res.status(500).send('Internal Server Error')
    }
}

const disableOrEnableDevice = async (req,res) =>{

    const {device_id,status} = req.body.params;

    if(!device_id || !status){
        res.json({ status: 400, success: false, message: "Status and device_id is required"})
    }
    else{
        try{
    
            const masterKey = req.headers?.user?.business_id
            const device = await getDevices(masterKey,device_id)
    
            if(device){
    
                const getParams = {
                    TableName: process.env.BUSINESS_DEVICE_DETAILS,
                    Key: {id: device.uniqueDeviceId}
                }
                
                const { Item } = await dynamoDB.get(getParams).promise()     
                
                if(Item){
                    const updateParams = {
                        TableName: process.env.BUSINESS_DEVICE_DETAILS,
                        Key: { id: device.uniqueDeviceId },
                        UpdateExpression: "SET device_status = :status, #timestamp = :timestamp",
                        ExpressionAttributeValues: {
                            ":status": status,
                            ":timestamp": Date.now()
                        },
                        ExpressionAttributeNames: {
                            "#timestamp": "timestamp"
                        }
                    };
                    await dynamoDB.update(updateParams).promise()
                }
                else{
                    const putParams = {
                        TableName: process.env.BUSINESS_DEVICE_DETAILS,
                        Item: {
                            id: device_id,
                            device_status : status,
                            timestamp: Date.now() 
                        }
                    }
                    await dynamoDB.put(putParams).promise()
                }
                
                res.json({ status: 200, success: true, message: `Device ${status}d`})
            }
            else{
                res.json({ status: 400, success: false, message: "Device does not exist."})
            }
        }
        catch(err){
            console.log(err)
            res.status(500).send('Internal Server Error')
        }
    }


}


module.exports = { getAllDevices, disableOrEnableDevice, getDeviceReports, downloadReportInJson, getMonthlyDataOrPercentages, getMonthlyTestsAndTheirCount }