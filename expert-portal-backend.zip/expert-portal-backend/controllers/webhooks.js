const { validateWebhookSignature } = require('razorpay/dist/utils/razorpay-utils')
const AWS = require('../config/aws')
const { sendToRoom } = require('../utilities/socketEvents')
const { setReportStatus } = require('./ecgController')
const DynamoDB = new AWS.DynamoDB.DocumentClient()
const razorpay = require('../config/razorpay')

const razorpayWebhook = async (req, res) => {
  if (!req?.body?.payload) return res.status(500).json({ Result: "FAILED", Error: "Request validation failed." })

  const event = req?.body?.event
  const payload = req?.body

  try {
    const signature = req.get("x-razorpay-signature")
    let isValidHook = validateWebhookSignature(req?.rawBody, signature, process.env.RAZORPAY_WEBHOOK_SECRET)

    if (isValidHook) {

      const { payment } = payload.payload

      if (event === "payment.authorized") {
        if (payment?.entity?.notes?.idsString) {
          const ids = payment?.entity?.notes.idsString.split(',')

          const putParams = payment ? {
            TableName: process.env?.PAYMENT_LOG_TABLE,
            Item: { ...payment.entity }
          } : {}

          const updateParams = {
            TableName: process.env.INTERPRETATION_REQUEST_ORDER_TABLE,
            Key: { id: payment.entity?.order_id },
            UpdateExpression: `SET order_status = :order_status, payment_id=:payment_id`,
            ExpressionAttributeValues: {
              ':order_status': 'paid',
              ':payment_id': payment.entity.id
            }
          }
          
          const auth = {
            ...payment.entity.notes,
            is_paid: true
          }
          await DynamoDB.update(updateParams).promise()
          await DynamoDB.put(putParams).promise()
          const query = await setReportStatus(ids, "requested", {}, {}, auth, true)
          // Capture the amount
          razorpay.payments.capture(payment.entity.id, payment.entity.amount, payment.entity.currency) 
          // Broadcast new request to experts room  
          sendToRoom('Expert', 'addReport', query)
        }
      }
    }

    res.status(200).json({ success: true })

  } catch (e) {
    res.status(500).json({ success: false })
  }
}

module.exports = { razorpayWebhook }