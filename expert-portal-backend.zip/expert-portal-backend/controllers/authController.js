const AWS = require("../config/aws");
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const jwt = require("jsonwebtoken");
const admin = require("../config/firebase")
const axios = require("axios")
const messages = require('../utils/messages')
const {errorLog} = require('./errorLogs')


async function getUserFromFirebase(phoneNumber) {
  const db = admin.firestore();
  const users = db.collection(process.env.SPANDAN_SERVICE_FIREBASE_USER_TABLE_NAME || 'user');

  const userDoc = await users.where('phoneNumber', '==', phoneNumber).where('masterUser', '==', true).get()

  if (!userDoc.empty) {
    return userDoc.docs[0].data();
  }
}

async function getUserFromDynamo(phoneNumber, business_id) {

  if (business_id) {
      const getParams = {
          TableName: process.env.INTERNAL_USERS_TABLE,
          Key: { api_key: business_id }
      }
      const { Item } = await dynamoDB.get(getParams).promise();
      const items = Item ? [Item] : []
      return { Items: items }
  }
  else {
      const scanParams = {
          TableName: process.env.INTERNAL_USERS_TABLE,
          FilterExpression: "phone_number = :phone_number",
          ExpressionAttributeValues: {
              ":phone_number": phoneNumber,
          },
      }
      return await dynamoDB.scan(scanParams).promise()
  }
}

const login = async (req, res) => {
  const { phoneNumber } = req.body;

  if (!phoneNumber) {
    return res.json({
      success: false,
      status: 400,
      message: messages.login.missingPhoneNumber,
    });
  }

  let user = null;

  try {
    user = await getUserFromDynamo(phoneNumber);

    user = user || await getUserFromFirebase(phoneNumber);

    if (user) {
      if (!process.env?.SPANDAN_SERVICE_IS_OTP || process.env?.SPANDAN_SERVICE_IS_OTP === 'false') return res.json({
        success: true,
        status: 200,
        message: messages.login.otpSentSuccess,
      });

      const url = `https://api.msg91.com/api/v5/otp?template_id=${process.env.MSG91_OTP_TEMPLATE_ID}&mobile=${phoneNumber?.replace("+", "")}&otp_length=6`;

      const headers = {
        accept: "application/json",
        "content-type": "application/json",
        authkey: process.env.MSG91_API_KEY,
      };

      const response = await axios.post(url, {}, { headers });
      if (response.data.type === "success") {
        return res.json({
          success: true,
          status: 200,
          message: messages.login.otpSentSuccess,
        });
      } else {
        return res.json({
          success: false,
          status: 400,
          message: messages.login.somethingWentWrong,
        });
      }
    } else {
      return res.json({
        success: false,
        status: 400,
        message: messages.login.userNotFound,
      });
    }
  }
  catch (err) {
    await errorLog(err,'login','userController.js')
    return res.json({
      success: false,
      status: 400,
      message: messages.login.somethingWentWrong,
      data: err
    });
  }
};

const verify = async (req, res) => {
  const { phoneNumber, otp } = req.body


  if (!phoneNumber || !otp) {
    return res.json({
      success: false,
      status: 400,
      message: messages.verify.missingDetails,
    });
  }

  try {
    if (process.env?.SPANDAN_SERVICE_IS_OTP && process.env?.SPANDAN_SERVICE_IS_OTP === 'true') {
      const options = {
        method: "GET",
        url: `https://control.msg91.com/api/v5/otp/verify?otp=${otp}&mobile=${phoneNumber.replace('+', '')}`,
        headers: {
          accept: "application/json",
          authkey: process.env.MSG91_API_KEY,
        },
      };
      const response = await axios.request(options);

      if (response?.data?.type === "error") {
        return res.json({
          success: false,
          status: 400,
          message: response?.data?.message,
        });
      }
    }

    let {Items} = await getUserFromDynamo(phoneNumber)
    let user = Items[0]

    user = user || await getUserFromFirebase(phoneNumber);
    let userType = (user?.user_type || "user");

    if (user) {
      const data = {
        phoneNumber,
        userType: userType,
        email: user?.email || user?.userEmail,
        name: user?.name || user?.firstName,
        displayName: user?.name || user?.firstName,
        profilePic: user?.primaryUserProfilePicture,
        company_data: user?.company_data,
        business_id: user?.api_key
      };

      const token = jwt.sign(data, process.env.SPANDAN_SERVICE_JWT_SECRET);

      return res.json({ success: true, status: 200, data: { ...data, authorization: token } });
    } else {
      return res.json({
        success: false,
        status: 400,
        message: messages.verify.userNotFound,
      });
    }
  } catch (err) {

    await errorLog(err,'verify','userController.js')
    return res.json({
      success: false,
      status: 500,
      message: messages.verify.somethingWentWrong,
      data: err
    });
  }
};

module.exports = { verify, login, getUserFromFirebase, getUserFromDynamo };
