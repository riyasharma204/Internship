

const OpenAI = require("openai");
const openai = new OpenAI({
    apiKey:"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"
});




module.exports = openai;
