const mongoose = require('mongoose')

async function connectToMongo(){
    
    try{
        
        await mongoose.connect(process.env.MONGO_CONNECTION_URL, {useNewUrlParser: true})
        
        console.log('Connected to MongoDB')

    }
    catch(error){
        console.log(error)
    }
}

connectToMongo()