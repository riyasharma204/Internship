const admin = require("firebase-admin")
var serviceAccount = require(`../spandanecg-firebase-adminsdk-${process.env.SPANDAN_SERVICE_ENVIRONMENT}.json`)
admin.initializeApp({credential: admin.credential.cert(serviceAccount)})

module.exports = admin