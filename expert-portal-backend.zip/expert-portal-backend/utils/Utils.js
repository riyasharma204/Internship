const crypto = require('crypto')

const blobToURL=(blob)=> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = function () {
      const base64data = reader.result;
      resolve(base64data);
    };
  });
}
  

const generateApiKey = () => {
  const buf = crypto.randomBytes(8)
  return buf.toString('hex')
};

const generateVerifierKey = (apiKey) => {
  const salt = crypto.randomBytes(64);
  const hmac = crypto.createHmac('sha256', apiKey);
  hmac.update(salt);
  const verifierToken = hmac.digest('base64');
  return verifierToken;
};

module.exports={ blobToURL, generateApiKey, generateVerifierKey }