// messages.js

const messages = {
    
    login: {
      missingPhoneNumber: "Please provide a phone number",
      otpSentSuccess: "OTP sent successfully",
      otpNotSent: "Something went wrong. OTP not sent",
      userNotFound: "User not found",
      somethingWentWrong: "Something went wrong",
    },

    verify: {
      missingDetails: "Please provide phone number and OTP",
      otpVerificationFailed: "OTP verification failed",
      userNotFound: "User not found",
      somethingWentWrong: "Something went wrong",
    },


    authentication: {
        invalidAccessToken: "Invalid access token.",
    },

    getList: {
        successfullyGotResults: "Successfully got results",
        errorGettingResults: "Error while getting the results",
    },

    saveInterpretationData: {
        idInterpretationFormDataMissing: "ID and interpretation form data are missing.",
        successfullyUpdated: "Successfully updated",
        failedToUpdate: "Failed to update",
    },

    getSpecificReportData: {
        idDoesNotExist: "ID doesn't exist",
        accessingReportDataSuccess: "Successfully accessed ECG report data from S3",
        accessingReportDataError: "Error accessing ECG report data from S3",
    },

    reportsRequestForInterpretation: {
        idDoesNotExist: "ID doesn't exist",
        updateSuccess: "Successfully updated",
        updateFailed: "Failed to update the record",
    },
}
  
module.exports = messages;
  