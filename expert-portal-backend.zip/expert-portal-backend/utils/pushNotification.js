const admin = require('../config/firebase')
const { getUserFromFirebase } = require('../controllers/authController')

const sendPushNotifications = async (phone_number,id,completed_timestamp) => {

    try{

      const user = await getUserFromFirebase(phone_number)
      const token = user?.fcmToken 
      
      const message = {
        data:{
            timestamp: completed_timestamp,
            id: `${id}`
        },
        notification: {
          title: 'Spandan App Manual Review Request',
          body: "Interpretation request completed"
        },
        token
      }
  
      await admin.messaging().send(message)
      return true
  
    }
    catch (error) {
      console.error('Error sending notification:', error)
      return false 
    }
}

  
module.exports = {sendPushNotifications}