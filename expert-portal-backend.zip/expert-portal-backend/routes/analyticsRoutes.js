const express = require('express')
const { get_interpretation_analytics, get_annual_report, get_monthly_report, get_requested_today_count, get_total_completed_group_by_expert_and_report_types, get_completed_count_in_last_30_days, get_completed_today_count, get_pending_count_in_last_30_days } = require('../controllers/analyticsController')

const router = express.Router()

router.get('/get-interpretation-analytics', get_interpretation_analytics)
router.get('/get-annual-analytics', get_annual_report)
router.get('/get-monthly-analytics', get_monthly_report)
router.get('/get-total-completed-group-by-expert-and-report-types', get_total_completed_group_by_expert_and_report_types)
router.get('/get-requested-today-count', get_requested_today_count)
router.get('/get-completed-today-count', get_completed_today_count)
router.get('/get-pending-count-in-last-30-days', get_pending_count_in_last_30_days)
router.get('/get-completed-count-in-last-30-days', get_completed_count_in_last_30_days)

module.exports = router