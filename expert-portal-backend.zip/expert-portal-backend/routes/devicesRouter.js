const express = require('express')
const { getAllDevices, getDeviceReports, downloadReportInJson,getMonthlyDataOrPercentages,getMonthlyTestsAndTheirCount, disableDevice, enableDevice, disableOrEnableDevice } = require('../controllers/devicesContoller')

const router = express.Router()

router.get('/device-tests',getMonthlyDataOrPercentages )
router.get('/device-test-percentages',(req,res,next)=>{
    req.getPercentages = true
    next()
}, getMonthlyDataOrPercentages),
router.get('/monthly-test-counts', getMonthlyTestsAndTheirCount)
router.get('/list/:device_id', getDeviceReports)
router.get('/download', downloadReportInJson)
router.get('/', getAllDevices)
router.patch('/disableEnableDevice',disableOrEnableDevice)

module.exports = router