const express = require('express')
const { verifyToken } = require('../controllers/middleware')
const {saveUserQuery}=require('../controllers/chatController')

const router = express.Router()

router.post('/user-input', saveUserQuery)


module.exports = router