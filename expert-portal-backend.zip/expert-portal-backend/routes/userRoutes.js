const express = require('express')
const { verifyToken } = require('../controllers/middleware')
const { login, verify } = require('../controllers/authController')
const { getB2Busers, saveB2BProfile, addB2BAdminOrAssociatedUsers, removeB2BAdminOrAssociatedUsers, getAssociatedUserDataFromFirebase, getInternalUsers, removeInternalUsers, saveUsers, updateUserProfile } = require('../controllers/userController')

const { invoice, getUserOrder, saveInvoiceDetails, fetchInvoiceData, fetchClientPdf, toCheckInvoiceNumber } = require('../controllers/billController')

const router = express.Router()

router.post('/login', login)
router.post('/verify', verify)

router.get('/get-b2b-users', verifyToken, getB2Busers)
router.get('/get-b2b-admin-users', verifyToken, (req, res, next) => {
    req.headers.user.getB2bAdminUsers = true
    next()
}, getB2Busers)
router.post('/save-b2b-profile', verifyToken, saveB2BProfile)
router.get('/get-associated-users', verifyToken, getAssociatedUserDataFromFirebase)
router.post('/add-associated-users', verifyToken, addB2BAdminOrAssociatedUsers)
router.post('/remove-associated-users', verifyToken, removeB2BAdminOrAssociatedUsers)
router.post('/add-b2b-admins', verifyToken, (req, res, next) => {
    req.body = {
        ...req.body,
        isb2bUser: true
    }
    next();
}, addB2BAdminOrAssociatedUsers)
router.post('/remove-b2b-admin-users', verifyToken, (req, res, next) => {
    req.body = {
        ...req.body,
        removeB2BAdminUser: true
    }
    next();
}, removeB2BAdminOrAssociatedUsers)
router.get('/get-users', verifyToken, getInternalUsers)
router.post('/save-users', verifyToken, saveUsers)
router.post('/remove-users', verifyToken, removeInternalUsers)
router.post('/update-profile', verifyToken, updateUserProfile)

// =================== Bill Controller =================//
router.post('/invoice', invoice)
router.get('/get-order', verifyToken, getUserOrder)
router.post('/save-invoice-details',verifyToken,saveInvoiceDetails)
router.post('/fetch-invoice-data', verifyToken, fetchInvoiceData)
router.post('/check-invoice-number',verifyToken, toCheckInvoiceNumber)
router.post('/fetch-client-pdf', verifyToken, fetchClientPdf)

module.exports = router