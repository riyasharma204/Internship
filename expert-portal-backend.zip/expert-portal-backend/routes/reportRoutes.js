const express = require('express')
// const {changeStatusOnInterpretedClick}=require('../controllers/reportController')

const router = express.Router();



module.exports = router
