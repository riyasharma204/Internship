const express = require('express')
const { getList, saveInterpretationData, getSpecificReportData, reportsRequestForInterpretation, revokeInterpretationRequest, getSpecificInvoiceData } = require('../controllers/ecgController')

const router = express.Router()

router.get('/get-list', getList)
router.post('/request-for-interpretation',reportsRequestForInterpretation)
router.post('/revoke-interpretation-request', revokeInterpretationRequest)
router.patch('/save-interpretation-data', saveInterpretationData)
router.get('/get-ecg-data/:report_id', getSpecificReportData)
router.get('/get-specific-invoice-data', getSpecificInvoiceData)

module.exports = router