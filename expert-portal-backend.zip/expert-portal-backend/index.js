require('dotenv').config({ path: `.env${process.env?.NODE_ENV?.trim() ? `.${process.env.NODE_ENV?.trim()}` : ''}` })
console.log("Env is: " + process.env?.NODE_ENV)
require('./config/aws')
require('./config/mongo')
const cors = require('cors')
const express = require('express')
const http = require('http');
const morgan = require('morgan')
const { spawn } = require('child_process')

const app = express()
const server = http.createServer(app)

app.use(morgan('dev'))
app.use(cors())
app.use(express.json({
  verify: (req, res, buf, encoding) => {
    if (buf && buf.length) {
      req.rawBody = buf.toString(encoding || 'utf8');
    }
  }
}));

process.on('uncaughtException', (err) => {
  if (err) {
    console.log("caughtException but no error msg :: " + err.stack);
    process.exit(1);
  }
});

const { initSocket } = require('./utilities/socket-io')

const ecgRouter = require('./routes/ecgRoutes')
const userRouter = require('./routes/userRoutes')
const analyticsRouter = require('./routes/analyticsRoutes')
const webhookRouter = require('./routes/webhookRoutes')
const devicesRouter = require('./routes/devicesRouter')
const { verifyToken } = require('./controllers/middleware')
const ECGData = require("./ecg-data");

initSocket(server);

app.get('/', (req, res) => {
	console.error("Reached")
	res.send("Working")
})
app.get('/runJar', (req, res) => {
  // Replace 'java' with the path to your Java executable if it's not in the system PATH
  const javaPath = 'java';

  // Path to your .jar file
  const jarPath = '/home/ubuntu/expert-portal-backend/MyClass.jar';
  //console.log(ECGData);
  
  // Parameters to pass to the .jar file
  const parameters = ["1", "2"];

  const className = 'MyClass';

  // Spawn the child process
  const child = spawn(javaPath, ['-cp', jarPath, className, ...parameters]);

  let output = '';

  // Capture output of the child process
  child.stdout.on('data', (data) => {
    console.log(data);
    output += data;
  });

  // Capture errors of the child process
  child.stderr.on('data', (data) => {
    console.error(`stderr: ${data}`);
  });

  // Handle exit of the child process
  child.on('close', (code) => {
    console.log(`child process exited with code ${code}`);
    // Send the output of the .jar file execution as the response
    res.send(output);
  });
});

// Routers
app.use('/user',userRouter)
app.use('/ecg', verifyToken, ecgRouter)
app.use('/analytics', verifyToken, analyticsRouter)
app.use('/webhook', webhookRouter)
app.use('/device',verifyToken,devicesRouter)



const PORT = process.env.SPANDAN_SERVICE_PORT || 3002
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

